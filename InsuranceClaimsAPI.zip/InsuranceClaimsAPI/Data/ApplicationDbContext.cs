﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using InsuranceClaimsAPI.Models;
namespace InsuranceClaimsAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<UserSession> UserSessions { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<UserRoleAssignment> UserRoleAssignments { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure User entity
            builder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            builder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // Configure UserSession entity
            builder.Entity<UserSession>()
                .HasIndex(s => s.SessionToken)
                .IsUnique();

            builder.Entity<UserSession>()
                .HasIndex(s => s.RefreshToken)
                .IsUnique();

            // Configure UserRoleAssignment composite key
            builder.Entity<UserRoleAssignment>()
                .HasKey(ura => new { ura.UserId, ura.RoleId });

            builder.Entity<UserRoleAssignment>()
                .HasOne(ura => ura.User)
                .WithMany(u => u.UserRoleAssignments)
                .HasForeignKey(ura => ura.UserId);

            builder.Entity<UserRoleAssignment>()
                .HasOne(ura => ura.Role)
                .WithMany(r => r.UserRoleAssignments)
                .HasForeignKey(ura => ura.RoleId);
        }


        }
    }
