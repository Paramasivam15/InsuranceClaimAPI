﻿using Microsoft.EntityFrameworkCore;
using InsuranceClaimsAPI.Data;
using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
namespace InsuranceClaimsAPI.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _context;
        private readonly IPasswordService _passwordService;

        public UserService(ApplicationDbContext context, IPasswordService passwordService)
        {
            _context = context;
            _passwordService = passwordService;
        }

        public async Task<User?> GetUserByIdAsync(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<User?> GetUserByUsernameAsync(string username)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username && u.IsActive);
        }

        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email && u.IsActive);
        }

        public async Task<User?> GetUserByUsernameOrEmailAsync(string usernameOrEmail)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => (u.Username == usernameOrEmail || u.Email == usernameOrEmail) && u.IsActive);
        }

        public async Task<bool> UsernameExistsAsync(string username)
        {
            return await _context.Users.AnyAsync(u => u.Username == username);
        }

        public async Task<bool> EmailExistsAsync(string email)
        {
            return await _context.Users.AnyAsync(u => u.Email == email);
        }

        public async Task<User> CreateUserAsync(RegisterDto registerDto)
        {
            var salt = _passwordService.GenerateSalt();
            var passwordHash = _passwordService.HashPassword(registerDto.Password, salt);

            var user = new User
            {
                Username = registerDto.Username,
                Email = registerDto.Email,
                PasswordHash = passwordHash,
                PasswordSalt = salt,
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            // Assign default role
            var userRole = await _context.UserRoles.FirstOrDefaultAsync(r => r.RoleName == "User");
            if (userRole != null)
            {
                var roleAssignment = new UserRoleAssignment
                {
                    UserId = user.Id,
                    RoleId = userRole.Id,
                    AssignedBy = user.Id
                };
                _context.UserRoleAssignments.Add(roleAssignment);
                await _context.SaveChangesAsync();
            }

            return user;
        }

        public async Task<bool> UpdateUserAsync(int userId, User user)
        {
            var existingUser = await _context.Users.FindAsync(userId);
            if (existingUser == null) return false;

            existingUser.FirstName = user.FirstName;
            existingUser.LastName = user.LastName;
            existingUser.Email = user.Email;
            existingUser.ProfileImageUrl = user.ProfileImageUrl;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.IsActive = false;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<string>> GetUserRolesAsync(int userId)
        {
            return await _context.UserRoleAssignments
                .Where(ura => ura.UserId == userId)
                .Include(ura => ura.Role)
                .Select(ura => ura.Role.RoleName)
                .ToListAsync();
        }

        public async Task<bool> ChangePasswordAsync(int userId, ChangePasswordDto changePasswordDto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            // Verify current password
            if (!_passwordService.VerifyPassword(changePasswordDto.CurrentPassword, user.PasswordHash, user.PasswordSalt))
                return false;

            // Set new password
            var newSalt = _passwordService.GenerateSalt();
            var newPasswordHash = _passwordService.HashPassword(changePasswordDto.NewPassword, newSalt);

            user.PasswordHash = newPasswordHash;
            user.PasswordSalt = newSalt;

            // Invalidate all sessions
            var userSessions = await _context.UserSessions
                .Where(s => s.UserId == userId && s.IsActive)
                .ToListAsync();

            foreach (var session in userSessions)
            {
                session.IsActive = false;
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> LockUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.IsLocked = true;
            user.LockoutEndTime = DateTime.UtcNow.AddMinutes(30);

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UnlockUserAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return false;

            user.IsLocked = false;
            user.LockoutEndTime = null;
            user.FailedLoginAttempts = 0;

            await _context.SaveChangesAsync();
            return true;
        }
    }

}

