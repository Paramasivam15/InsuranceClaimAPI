﻿using InsuranceClaimsAPI.Data;
using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
namespace InsuranceClaimsAPI.Services
{
    public class AuthService : IAuthService
    {

        private readonly ApplicationDbContext _context;
        private readonly IUserService _userService;
        private readonly IPasswordService _passwordService;
        private readonly IConfiguration _configuration;

        public AuthService(
         ApplicationDbContext context,
         IUserService userService,
         IPasswordService passwordService,
         IConfiguration configuration
     )
        {
            _context = context;
            _userService = userService;
            _passwordService = passwordService;
            _configuration = configuration;

        }

        public async Task<AuthResponseDto?> LoginAsync(LoginDto loginDto, string? ipAddress = null, string? userAgent = null)
        {
            var user = await _userService.GetUserByUsernameOrEmailAsync(loginDto.UsernameOrEmail);
            if (user == null) return null;

            // Check if account is locked
            if (user.IsLocked && user.LockoutEndTime > DateTime.UtcNow)
                return null;

            // Verify password
            if (!_passwordService.VerifyPassword(loginDto.Password, user.PasswordHash, user.PasswordSalt))
            {
                // Increment failed attempts
                user.FailedLoginAttempts++;
                if (user.FailedLoginAttempts >= 5)
                {
                    user.IsLocked = true;
                    user.LockoutEndTime = DateTime.UtcNow.AddMinutes(30);
                }
                await _context.SaveChangesAsync();

                // Log failed attempt
                await LogAuditAsync(user.Id, "Failed Login - Invalid Password", "Users", user.Id.ToString(), ipAddress, userAgent);
                return null;
            }

            // Reset failed attempts on successful login
            user.FailedLoginAttempts = 0;
            user.IsLocked = false;
            user.LockoutEndTime = null;
            user.LastLoginAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            // Generate tokens
            var jwtToken = GenerateJwtToken(user);
            var refreshToken = _passwordService.GenerateRandomToken();
            var expiresAt = DateTime.UtcNow.AddDays(loginDto.RememberMe ? 30 : 1);

            // Create session
            var userSession = new UserSession
            {
                UserId = user.Id,
                SessionToken = jwtToken,
                RefreshToken = refreshToken,
                ExpiresAt = expiresAt,
                IpAddress = ipAddress,
                UserAgent = userAgent
            };

            _context.UserSessions.Add(userSession);
            await _context.SaveChangesAsync();

            // Get user roles
            var roles = await _userService.GetUserRolesAsync(user.Id);

            // Log successful login
            await LogAuditAsync(user.Id, "Successful Login", "Users", user.Id.ToString(), ipAddress, userAgent);

            return new AuthResponseDto
            {
                UserId = user.Id,
                Username = user.Username,
                Token = jwtToken,
                RefreshToken = refreshToken,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                ProfileImageUrl = user.ProfileImageUrl,
                ExpiresAt = expiresAt,
                Roles = roles
            };
        }

        public async Task<AuthResponseDto?> RegisterAsync(RegisterDto registerDto)
        {
            // Validate input
            if (registerDto.Password != registerDto.ConfirmPassword)
                return null;

            if (await _userService.UsernameExistsAsync(registerDto.Username))
                return null;

            if (await _userService.EmailExistsAsync(registerDto.Email))
                return null;

            // Create user
            var user = await _userService.CreateUserAsync(registerDto);

            // Generate tokens
            var jwtToken = GenerateJwtToken(user);
            var refreshToken = _passwordService.GenerateRandomToken();
            var expiresAt = DateTime.UtcNow.AddDays(1);

            // Create session
            var userSession = new UserSession
            {
                UserId = user.Id,
                SessionToken = jwtToken,
                RefreshToken = refreshToken,
                ExpiresAt = expiresAt,
                IsActive=true,
                UserAgent=string.Empty,
                IpAddress=string.Empty
            };

            _context.UserSessions.Add(userSession);
            await _context.SaveChangesAsync();

            // Get user roles
            var roles = await _userService.GetUserRolesAsync(user.Id);

            // Log registration
            await LogAuditAsync(user.Id, "User Registered", "Users", user.Id.ToString());

            return new AuthResponseDto
            {
                UserId = user.Id,
                Username = user.Username,
                Token = jwtToken,
                RefreshToken = refreshToken,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                ProfileImageUrl = user.ProfileImageUrl,
                ExpiresAt = expiresAt,
                Roles = roles
            };
        }

        public async Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken)
        {
            var session = await _context.UserSessions
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.RefreshToken == refreshToken && s.IsActive && s.ExpiresAt > DateTime.UtcNow);

            if (session == null) return null;

            var user = session.User;
            if (!user.IsActive || user.IsLocked) return null;

            // Generate new tokens
            var newJwtToken = GenerateJwtToken(user);
            var newRefreshToken = _passwordService.GenerateRandomToken();
            var newExpiresAt = DateTime.UtcNow.AddDays(1);

            // Update session
            session.SessionToken = newJwtToken;
            session.RefreshToken = newRefreshToken;
            session.ExpiresAt = newExpiresAt;

            await _context.SaveChangesAsync();

            // Get user roles
            var roles = await _userService.GetUserRolesAsync(user.Id);

            return new AuthResponseDto
            {
                UserId = user.Id,
                Username = user.Username,
                Token = newJwtToken,
                RefreshToken = newRefreshToken,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                ProfileImageUrl = user.ProfileImageUrl,
                ExpiresAt = newExpiresAt,
                Roles = roles
            };
        }

        public async Task<bool> LogoutAsync(string sessionToken)
        {
            var session = await _context.UserSessions
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.IsActive);

            if (session == null) return false;

            session.IsActive = false;
            await _context.SaveChangesAsync();

            // Log logout
            await LogAuditAsync(session.UserId, "User Logout", "UserSessions", session.Id.ToString());

            return true;
        }

        public async Task<bool> ValidateTokenAsync(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!);

                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = _configuration["Jwt:Issuer"],
                    ValidateAudience = true,
                    ValidAudience = _configuration["Jwt:Audience"],
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                // Check if session exists and is active
                var session = await _context.UserSessions
                    .FirstOrDefaultAsync(s => s.SessionToken == token && s.IsActive && s.ExpiresAt > DateTime.UtcNow);

                return session != null;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> ForgotPasswordAsync(ForgotPasswordDto forgotPasswordDto)
        {
            var user = await _userService.GetUserByEmailAsync(forgotPasswordDto.Email);
            if (user == null) return false;

            // Generate reset token
            var resetToken = _passwordService.GenerateRandomToken();
            user.PasswordResetToken = resetToken;
            user.PasswordResetTokenExpiry = DateTime.UtcNow.AddHours(1);

            await _context.SaveChangesAsync();

            // Here you would send an email with the reset token
            // For demo purposes, we'll just log it
            await LogAuditAsync(user.Id, "Password Reset Requested", "Users", user.Id.ToString());

            return true;
        }

        public async Task<bool> ResetPasswordAsync(ResetPasswordDto resetPasswordDto)
        {
            if (resetPasswordDto.NewPassword != resetPasswordDto.ConfirmPassword)
                return false;

            var user = await _userService.GetUserByEmailAsync(resetPasswordDto.Email);
            if (user == null) return false;

            if (user.PasswordResetToken != resetPasswordDto.Token ||
                user.PasswordResetTokenExpiry < DateTime.UtcNow)
                return false;

            // Reset password
            var newSalt = _passwordService.GenerateSalt();
            var newPasswordHash = _passwordService.HashPassword(resetPasswordDto.NewPassword, newSalt);

            user.PasswordHash = newPasswordHash;
            user.PasswordSalt = newSalt;
            user.PasswordResetToken = null;
            user.PasswordResetTokenExpiry = null;

            // Invalidate all sessions
            var userSessions = await _context.UserSessions
                .Where(s => s.UserId == user.Id && s.IsActive)
                .ToListAsync();

            foreach (var session in userSessions)
            {
                session.IsActive = false;
            }

            await _context.SaveChangesAsync();

            await LogAuditAsync(user.Id, "Password Reset", "Users", user.Id.ToString());

            return true;
        }

        private string GenerateJwtToken(User user)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("FirstName", user.FirstName),
                new Claim("LastName", user.LastName)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(24),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private async Task LogAuditAsync(int? userId, string action, string? tableName, string? recordId, string? ipAddress = null, string? userAgent = null)
        {
            var auditLog = new AuditLog
            {
                UserId = userId,
                Action = action,
                TableName = tableName,
                RecordId = recordId,
                IpAddress = ipAddress,
                UserAgent = userAgent
            };

            _context.AuditLogs.Add(auditLog);
            await _context.SaveChangesAsync();
        }


    }
}
