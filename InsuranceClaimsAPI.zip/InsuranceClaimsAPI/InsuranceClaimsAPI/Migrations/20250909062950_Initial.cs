﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace InsuranceClaimsAPI.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Codes",
                columns: table => new
                {
                    CodeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CodeType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CodeValue = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Codes", x => x.CodeID);
                });

            migrationBuilder.CreateTable(
                name: "Zipcodes",
                columns: table => new
                {
                    ZipIntID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ZIPCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    ZIPType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CityName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CityType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    StateName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    StateAbbr = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    AreaCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Latitude = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Longitude = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ZIPExtn = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Zipcodes", x => x.ZipIntID);
                });

            migrationBuilder.CreateTable(
                name: "InsuranceQuestionnaire",
                columns: table => new
                {
                    QuestionnaireId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PaymentMethodId = table.Column<int>(type: "int", nullable: false),
                    OtherPaymentMethod = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CoverangeTypeIds = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAssistanceRequired = table.Column<bool>(type: "bit", nullable: false),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InsuranceQuestionnaire", x => x.QuestionnaireId);
                    table.ForeignKey(
                        name: "FK_InsuranceQuestionnaire_Codes_PaymentMethodId",
                        column: x => x.PaymentMethodId,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RolePermission",
                columns: table => new
                {
                    RolePermissionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    IsViewDashboard = table.Column<bool>(type: "bit", nullable: false),
                    IsViewMemberPotal = table.Column<bool>(type: "bit", nullable: false),
                    IsViewUserManagement = table.Column<bool>(type: "bit", nullable: false),
                    IsAccessReport = table.Column<bool>(type: "bit", nullable: false),
                    IsGeneateBillReview = table.Column<bool>(type: "bit", nullable: false),
                    IsGenerateComplexCaseReports = table.Column<bool>(type: "bit", nullable: false),
                    IsAccessSystemSettings = table.Column<bool>(type: "bit", nullable: false),
                    IsAccessRoleManagement = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RolePermission", x => x.RolePermissionID);
                    table.ForeignKey(
                        name: "FK_RolePermission_Codes_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    UserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailID = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    PasswordSalt = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    MobileNo = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DOB = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    EmailConfirmationToken = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailConfirmationTokenExpiry = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MobileNoConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    MobileConfirmationToken = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MobileConfirmationTokenExpiry = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsPasswordlinkShow = table.Column<bool>(type: "bit", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: true),
                    FaiedLoginAttempt = table.Column<int>(type: "int", nullable: false),
                    ProfilePhoto = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SessionToken = table.Column<string>(type: "nvarchar(700)", maxLength: 700, nullable: false),
                    RefreshToken = table.Column<string>(type: "nvarchar(700)", maxLength: 700, nullable: false),
                    IsLocked = table.Column<bool>(type: "bit", nullable: false),
                    ExpiresAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastLoginDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.UserID);
                    table.ForeignKey(
                        name: "FK_User_Codes_RoleId",
                        column: x => x.RoleId,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Contributions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionnaireId = table.Column<int>(type: "int", nullable: true),
                    BenefitTypeId = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<int>(type: "int", nullable: false),
                    FrequencyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contributions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Contributions_Codes_BenefitTypeId",
                        column: x => x.BenefitTypeId,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contributions_Codes_FrequencyId",
                        column: x => x.FrequencyId,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contributions_InsuranceQuestionnaire_QuestionnaireId",
                        column: x => x.QuestionnaireId,
                        principalTable: "InsuranceQuestionnaire",
                        principalColumn: "QuestionnaireId");
                });

            migrationBuilder.CreateTable(
                name: "Member",
                columns: table => new
                {
                    MemberID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MappedMemberID = table.Column<int>(type: "int", nullable: false),
                    FamilyID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DOB = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MobileNo = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    EmailID = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Address1 = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    Address2 = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    City = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    State = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ZipCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Country = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ZipIntID = table.Column<int>(type: "int", nullable: true),
                    RelationshipTypeID = table.Column<int>(type: "int", nullable: true),
                    IsMemberLinkID = table.Column<int>(type: "int", nullable: true),
                    IsPrimaryMem = table.Column<bool>(type: "bit", nullable: false),
                    HasLogin = table.Column<bool>(type: "bit", nullable: false),
                    MemberPhoto = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Member", x => x.MemberID);
                    table.ForeignKey(
                        name: "FK_Member_Codes_RelationshipTypeID",
                        column: x => x.RelationshipTypeID,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Member_User_IsMemberLinkID",
                        column: x => x.IsMemberLinkID,
                        principalTable: "User",
                        principalColumn: "UserID");
                });

            migrationBuilder.CreateTable(
                name: "MemberInsurance",
                columns: table => new
                {
                    MemInsID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MemberID = table.Column<int>(type: "int", nullable: false),
                    InsFrontImgURL = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    InsBackImgURL = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    BenefitTypeID = table.Column<int>(type: "int", nullable: false),
                    PolicyTypeID = table.Column<int>(type: "int", nullable: false),
                    SubscriberID = table.Column<int>(type: "int", nullable: false),
                    DependentsID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PayerName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PolicyID = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    QuestionnaireId = table.Column<int>(type: "int", nullable: true),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MemberInsurance", x => x.MemInsID);
                    table.ForeignKey(
                        name: "FK_MemberInsurance_Codes_BenefitTypeID",
                        column: x => x.BenefitTypeID,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MemberInsurance_Codes_PolicyTypeID",
                        column: x => x.PolicyTypeID,
                        principalTable: "Codes",
                        principalColumn: "CodeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MemberInsurance_InsuranceQuestionnaire_QuestionnaireId",
                        column: x => x.QuestionnaireId,
                        principalTable: "InsuranceQuestionnaire",
                        principalColumn: "QuestionnaireId");
                    table.ForeignKey(
                        name: "FK_MemberInsurance_Member_MemberID",
                        column: x => x.MemberID,
                        principalTable: "Member",
                        principalColumn: "MemberID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_MemberInsurance_Member_SubscriberID",
                        column: x => x.SubscriberID,
                        principalTable: "Member",
                        principalColumn: "MemberID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MemberInsEligibility",
                columns: table => new
                {
                    MemInsEliID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MemInsID = table.Column<int>(type: "int", nullable: false),
                    IsInsuranceActive = table.Column<bool>(type: "bit", nullable: false),
                    InsActiveDateFrom = table.Column<DateTime>(type: "datetime2", nullable: false),
                    InsActiveDateTo = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PhyCopay = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PhyDeductable = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PhyCoIns = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FacCopay = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FacDeductable = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FacCoIns = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FamilyDeductable = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    OOPIndividual = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    OOPFamily = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    EligibilityChkDate = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AssignedMemeberID = table.Column<int>(type: "int", nullable: false),
                    EligibilityStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AddDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AddedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MemberInsEligibility", x => x.MemInsEliID);
                    table.ForeignKey(
                        name: "FK_MemberInsEligibility_MemberInsurance_MemInsID",
                        column: x => x.MemInsID,
                        principalTable: "MemberInsurance",
                        principalColumn: "MemInsID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Codes",
                columns: new[] { "CodeID", "CodeType", "CodeValue", "IsActive", "IsDelete" },
                values: new object[,]
                {
                    { 1, "Relationship", "Self", true, false },
                    { 2, "Relationship", "Spouse", true, false },
                    { 3, "Relationship", "Son", true, false },
                    { 4, "Relationship", "Daughter", true, false },
                    { 5, "Relationship", "Mom", true, false },
                    { 6, "Relationship", "Dad", true, false },
                    { 7, "Relationship", "MotherInLaw", true, false },
                    { 8, "Relationship", "FatherInLaw", true, false },
                    { 9, "PolicyType", "Primary", true, false },
                    { 10, "PolicyType", "Secondary", true, false },
                    { 11, "PolicyType", "Teritiary", true, false },
                    { 12, "PolicyType", "Other", true, false },
                    { 13, "BenefitType", "Medical", true, false },
                    { 14, "BenefitType", "Dental", true, false },
                    { 15, "BenefitType", "Vision", true, false },
                    { 16, "BenefitType", "Other", true, false },
                    { 17, "Role", "Administrator", true, false },
                    { 18, "Role", "Manager", true, false },
                    { 19, "Role", "Reviewer", true, false },
                    { 20, "Role", "User", true, false },
                    { 21, "PaymentMethod", "direct", true, false },
                    { 22, "PaymentMethod", "paycheck", true, false },
                    { 23, "PaymentMethod", "Other", true, false },
                    { 24, "EligibilityStatus", "Open", true, false },
                    { 25, "EligibilityStatus", "InProgress", true, false },
                    { 26, "EligibilityStatus", "Completed", true, false },
                    { 27, "VaultDocType", "EOB", true, false },
                    { 28, "VaultDocType", "Statement", true, false },
                    { 29, "VaultDocType", "Receipt", true, false },
                    { 30, "Insurance-Coverange-Frequency", "Weekly", true, false },
                    { 31, "Insurance-Coverange-Frequency", "Monthly", true, false }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contributions_BenefitTypeId",
                table: "Contributions",
                column: "BenefitTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Contributions_FrequencyId",
                table: "Contributions",
                column: "FrequencyId");

            migrationBuilder.CreateIndex(
                name: "IX_Contributions_QuestionnaireId",
                table: "Contributions",
                column: "QuestionnaireId",
                unique: true,
                filter: "[QuestionnaireId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_InsuranceQuestionnaire_PaymentMethodId",
                table: "InsuranceQuestionnaire",
                column: "PaymentMethodId");

            migrationBuilder.CreateIndex(
                name: "IX_Member_IsMemberLinkID",
                table: "Member",
                column: "IsMemberLinkID");

            migrationBuilder.CreateIndex(
                name: "IX_Member_MemberID",
                table: "Member",
                column: "MemberID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Member_RelationshipTypeID",
                table: "Member",
                column: "RelationshipTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsEligibility_MemInsEliID",
                table: "MemberInsEligibility",
                column: "MemInsEliID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsEligibility_MemInsID",
                table: "MemberInsEligibility",
                column: "MemInsID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsurance_BenefitTypeID",
                table: "MemberInsurance",
                column: "BenefitTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsurance_MemberID",
                table: "MemberInsurance",
                column: "MemberID");

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsurance_PolicyTypeID",
                table: "MemberInsurance",
                column: "PolicyTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsurance_QuestionnaireId",
                table: "MemberInsurance",
                column: "QuestionnaireId");

            migrationBuilder.CreateIndex(
                name: "IX_MemberInsurance_SubscriberID",
                table: "MemberInsurance",
                column: "SubscriberID");

            migrationBuilder.CreateIndex(
                name: "IX_RolePermission_RoleId",
                table: "RolePermission",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_User_RoleId",
                table: "User",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_User_UserID",
                table: "User",
                column: "UserID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Zipcodes_ZipIntID",
                table: "Zipcodes",
                column: "ZipIntID",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contributions");

            migrationBuilder.DropTable(
                name: "MemberInsEligibility");

            migrationBuilder.DropTable(
                name: "RolePermission");

            migrationBuilder.DropTable(
                name: "Zipcodes");

            migrationBuilder.DropTable(
                name: "MemberInsurance");

            migrationBuilder.DropTable(
                name: "InsuranceQuestionnaire");

            migrationBuilder.DropTable(
                name: "Member");

            migrationBuilder.DropTable(
                name: "User");

            migrationBuilder.DropTable(
                name: "Codes");
        }
    }
}
