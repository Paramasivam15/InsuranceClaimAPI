﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InsuranceClaimsAPI.Models
{
    public class InsuranceQuestionnaire
    {
        [Key]
        public int QuestionnaireId { get; set; }           

        public int PaymentMethodId { get; set; } 

        [MaxLength(50)]
        public string OtherPaymentMethod { get; set; } = string.Empty;

        public string CoverangeTypeIds { get; set; } = string.Empty;

        public bool IsAssistanceRequired { get; set; }

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }

        [ForeignKey("PaymentMethodId")]
        public virtual Codes PaymentMethod { get; set; } = null!;
        
        public virtual Contributions? Contributions { get; set; }// Navigation Property
    }
}
