﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InsuranceClaimsAPI.Models
{
    public class Contributions
    {
        [Key]
        public int Id { get; set; }

        public int? QuestionnaireId { get; set; }

        public int BenefitTypeId { get; set; }

        public int Amount { get; set; }

        public int FrequencyId { get; set; }


        [ForeignKey("BenefitTypeId")]
        public virtual Codes BenefitType { get; set; } = null!;

        [ForeignKey("FrequencyId")]
        public virtual Codes Frequency { get; set; } = null!;

        [ForeignKey("QuestionnaireId")]
        public virtual InsuranceQuestionnaire InsuranceQuestionnaire { get; set; } = null!;//Navigation Prob

    }
}
