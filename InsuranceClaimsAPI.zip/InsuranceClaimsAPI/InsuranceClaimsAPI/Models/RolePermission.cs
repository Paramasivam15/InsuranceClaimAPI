﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Security;

namespace InsuranceClaimsAPI.Models
{
    public class RolePermission
    {
        [Key]
        public int RolePermissionID { get; set; }
        public int RoleId { get; set; }

        public bool IsViewDashboard { get; set; }
        public bool IsViewMemberPotal { get; set; }
        public bool IsViewUserManagement { get; set; }

        public bool IsAccessReport { get; set; }
        public bool IsGeneateBillReview { get; set; }
        public bool IsGenerateComplexCaseReports { get; set; }

        public bool IsAccessSystemSettings { get; set; }
        public bool IsAccessRoleManagement { get; set; }
      

        [ForeignKey("RoleId")]
        public virtual Codes Role { get; set; } = null!;
 
    }
}
