﻿namespace InsuranceClaimsAPI.Models
{
    public class FileStorageOptions
    {
        public string ProfilePhotoPath { get; set; }= string.Empty;
    }
}
