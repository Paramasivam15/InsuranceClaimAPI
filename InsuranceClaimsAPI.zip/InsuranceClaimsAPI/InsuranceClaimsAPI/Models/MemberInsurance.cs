﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Emit;
namespace InsuranceClaimsAPI.Models
{
    public class MemberInsurance
    {
        [Key]
        public int MemInsID { get; set; }            

        public int MemberID { get; set; }

        [MaxLength(100)]
        public string InsFrontImgURL { get; set; } = string.Empty;

        [MaxLength(100)]
        public string InsBackImgURL { get; set; } = string.Empty;

        public int BenefitTypeID { get; set; }

        public int PolicyTypeID { get; set; }

        public int SubscriberID { get; set; }

        public string DependentsID { get; set; } = string.Empty;


        [MaxLength(100)]
        public string PayerName { get; set; } = string.Empty;

        [MaxLength(100)]
        public string PolicyID { get; set; } = string.Empty;

        public int? QuestionnaireId { get; set; }

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }

              
        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;


        [ForeignKey("SubscriberID")]
        public virtual Member Subscriber { get; set; } = null!;



        [ForeignKey("BenefitTypeID")]
        public virtual Codes BenefitType { get; set; } = null!;

        [ForeignKey("PolicyTypeID")]
        public virtual Codes PolicyType { get; set; } = null!;


        public virtual MemberInsEligibility? MemberInsEligibility { get; set; }// Navigation Property

        [ForeignKey("QuestionnaireId")]
        public virtual InsuranceQuestionnaire InsuranceQuestionnaire { get; set; } = null!;//Navigation Prob


    }
}
