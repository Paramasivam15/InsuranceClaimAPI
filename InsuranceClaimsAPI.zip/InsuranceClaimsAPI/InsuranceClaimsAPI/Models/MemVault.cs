﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace InsuranceClaimsAPI.Models
{
    public class MemVault
    {

        [Key]
        public int MemVaultID { get; set; }

        public int MemberID { get; set; }

        public string Documentname { get; set; } = string.Empty;

         public int DocumentTypeID { get; set; } 


        public int BenefitTypeID { get; set; }

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;

        [ForeignKey("BenefitTypeID")]
        public virtual Codes BenefitType { get; set; } = null!;


        [ForeignKey("DocumentTypeID")]
        public virtual Codes DocumentType { get; set; } = null!;
    }
}
