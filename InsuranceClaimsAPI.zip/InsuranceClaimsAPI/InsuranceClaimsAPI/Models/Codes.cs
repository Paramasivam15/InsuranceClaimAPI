﻿using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimsAPI.Models
{
    public class Codes
    {
        [Key]
        public int CodeID { get; set; }

        [MaxLength(50)]
        public string CodeType { get; set; } = string.Empty;

        [MaxLength(50)]
        public string CodeValue { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }

        public ICollection<MemberInsurance> PolicyTypeUsages { get; set; }
        public ICollection<MemberInsurance> BenefitTypeUsages { get; set; }

        public ICollection<Member> RelationshipTypeUsages { get; set; }
        public ICollection<User> RoleUsages { get; set; }

        public ICollection<InsuranceQuestionnaire> InsuranceQuestionnaire { get; set; }

        public ICollection<Contributions> Contribution_BenefitType_Usages { get; set; }
        public ICollection<Contributions> Contributions_Frequency_Usages { get; set; }

        public ICollection<RolePermission> RoleIdUsages { get; set; }



    }
}
