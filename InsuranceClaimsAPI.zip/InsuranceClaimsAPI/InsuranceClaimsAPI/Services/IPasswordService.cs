﻿namespace InsuranceClaimsAPI.Services
{
  
        public interface IPasswordService
        {
            string GenerateSalt();
            string HashPassword(string password, string salt);
            bool VerifyPassword(string password, string hash, string salt);
            string GenerateRandomToken();
        }

    
}
