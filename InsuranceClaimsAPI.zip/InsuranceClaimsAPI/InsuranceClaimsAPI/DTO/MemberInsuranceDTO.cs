﻿using System.ComponentModel.DataAnnotations;
namespace InsuranceClaimsAPI.DTO
{
    public class MemberInsuranceDTO
    {
        public int MemInsID { get; set; }

        public int MemberID { get; set; }

        public int UserID { get; set; }

        public string InsFrontImgURL { get; set; } = string.Empty;
       
        public string InsBackImgURL { get; set; } = string.Empty;

        public IFormFile? FrontImage { get; set; }
        public IFormFile? BackImage { get; set; } 

        public string[] Dependents { get; set; } = Array.Empty<string>();


        public int BenefitTypeID { get; set; }

        public int PolicyTypeID { get; set; }

        public int SubscriberID { get; set; }

        public int? QuestionnaireId { get; set; }

        public string DependentsID { get; set; } = string.Empty;
       
        public string PolicyID { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;


    }
}
