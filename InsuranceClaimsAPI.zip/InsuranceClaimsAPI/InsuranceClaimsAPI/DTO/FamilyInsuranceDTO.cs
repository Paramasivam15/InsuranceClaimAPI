﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace InsuranceClaimsAPI.DTO
{
    public class FamilyInsuranceDTO
    {
        public int MemInsID { get; set; }

        public string InsFrontImgURL { get; set; } = string.Empty;

        public string InsBackImgURL { get; set; } = string.Empty;

        public int BenefitTypeID { get; set; }

        public string BenefitType { get; set; } = string.Empty;

        public int PolicyTypeID { get; set; }

        public string PolicyType { get; set; } = string.Empty;  

        public int SubscriberID { get; set; } 
        public string SubscriberName { get; set; } =string.Empty;

        public string PayerName { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;

        public string strActiveDateFromTo { get; set; } = string.Empty;
      

        public string EligibilityChkDate { get; set; } = string.Empty;
    }
}
