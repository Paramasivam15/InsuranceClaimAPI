﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
namespace InsuranceClaimsAPI.Models
{
    public class ApplicationUser:IdentityUser
    {
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }

        [MaxLength(100)]
        public string? ProfilePicture { get; set; }

        [MaxLength(20)]
        public string? Phonenumber { get; set; }

        [MaxLength(300)]
        public string? Address { get; set; }

        public DateTime CreatedAt { get; set; }=DateTime.Now;

        public DateTime UpdatedAt { get; set; } = DateTime.Now;








    }
}
