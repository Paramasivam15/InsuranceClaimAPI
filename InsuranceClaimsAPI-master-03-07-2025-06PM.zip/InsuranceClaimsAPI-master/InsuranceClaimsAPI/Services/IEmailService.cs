﻿using InsuranceClaimsAPI.Models;
namespace InsuranceClaimsAPI.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(Mailrequest mailrequest);
    }
}
