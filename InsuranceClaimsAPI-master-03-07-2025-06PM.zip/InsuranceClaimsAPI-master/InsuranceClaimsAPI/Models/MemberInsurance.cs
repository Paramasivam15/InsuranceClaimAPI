﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Emit;
namespace InsuranceClaimsAPI.Models
{
    public class MemberInsurance
    {
        [Key]
        public int MemInsID { get; set; }      

        public Guid UserID { get; set; }

        public Guid MemberID { get; set; }

        [MaxLength(50)]
        public string InsFrontImgURL { get; set; } = string.Empty;

        [MaxLength(50)]
        public string InsBackImgURL { get; set; } = string.Empty;

        public int BenefitTypeID { get; set; }

        public int PolicyTypeID { get; set; }

        public int SubscriberID { get; set; }

        public string DependentsID { get; set; } = string.Empty;


        [MaxLength(50)]
        public string PayerName { get; set; } = string.Empty;

        [MaxLength(50)]
        public string PolicyID { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("UserID")]
        public virtual User User { get; set; } = null!;

      
        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;
      

        [ForeignKey("TypeID")]
        public virtual BenefitType BenefitType { get; set; } = null!;

        [ForeignKey("PolicyTypeID")]
        public virtual PolicyType PolicyType { get; set; } = null!;

        

    }
}
