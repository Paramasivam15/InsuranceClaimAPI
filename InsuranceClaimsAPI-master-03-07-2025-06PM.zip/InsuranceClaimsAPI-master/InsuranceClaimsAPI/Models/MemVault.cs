﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace InsuranceClaimsAPI.Models
{
    public class MemVault
    {

        [Key]
        public int MemVaultID { get; set; }

        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }


        [ForeignKey("UserID")]
        public virtual User User { get; set; } = null!;

        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;
    }
}
