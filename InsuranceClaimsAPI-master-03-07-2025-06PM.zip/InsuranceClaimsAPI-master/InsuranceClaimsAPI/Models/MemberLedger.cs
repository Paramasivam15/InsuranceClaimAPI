﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace InsuranceClaimsAPI.Models
{
    public class MemberLedger
    {

        [Key]
        public int MemLedID { get; set; }
        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }

        public int MemInsID { get; set; }
        public string ClaimNo { get; set; } = string.Empty;

        public DateTime DOS { get; set; }

        public string VisitType { get; set; } = string.Empty;

        public string ProviderName { get; set; } = string.Empty;

        public Boolean IsBillReviewReq { get; set; }
        public Boolean IsBillReviewReqDate { get; set; }

        public int ReviewedBy  { get; set; }

        public Boolean IsMemAcceptedBR { get; set; }
        public DateTime IsMemAcceptedBRDate { get; set; }

        public Boolean IsMemPaidForBR { get; set; }
        public DateTime IsMemPaidForBRDate { get; set; }

        public int MemPaidBRAmt { get; set; }

        public string IsBillReviewStatus { get; set; } = string.Empty;

        public DateTime IsBillReviewClosedDate { get; set; }

        public string IsBRScoreCardStatus { get; set; } = string.Empty;

        public DateTime IsBRScoreCardReleaseDate { get; set; }

        public string BRScoreCardMemFeedback { get; set; } = string.Empty;

        public DateTime BRScoreCardMemFeedbackDate { get; set; }

        public string BRScoreCardMemFeedbackReply { get; set; } = string.Empty;

        public DateTime BRScoreCardMemFeedbackReplyDate { get; set; }
        public string BRScoreCardMemFeedbackReplyBy { get; set; } = string.Empty;

        public Boolean IsCaseComplex { get; set; }

        public Boolean IsMemAcceptedBRComplex { get; set; }

        public DateTime IsMemAcceptedBRComplexDate { get; set; }

        public Boolean IsMemPaidForBRComplex { get; set; }

        public DateTime IsMemPaidForBRComplexDate { get; set; }

        public int MemPaidBRComplexAmt { get; set; }

        public int BRComplexReviewerID { get; set; }

        public DateTime BRComplexConCallDateTime { get; set; }


        public string BRComplexConCallDetails { get; set; } = string.Empty;

        public Boolean IsBRCCStatus { get; set; }

        public string BRComplexMemFeedback { get; set; } = string.Empty;

        public DateTime BRComplexMemFeedbackDate { get; set; }

        public DateTime BRComplexMemFeedbackReplyDate { get; set; }

        public string BRComplexMemFeedbackReply { get; set; } = string.Empty;
        public string BRComplexMemFeedbackReplyBy { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("UserID")]
        public virtual User User { get; set; } = null!;

        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;

        [ForeignKey("MemInsID")]
        public virtual MemberInsurance MemberInsurance { get; set; } = null!;

    }
}
