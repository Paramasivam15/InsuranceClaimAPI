﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Emit;
namespace InsuranceClaimsAPI.Models
{
    public class Member
    {
        [Key]
        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }

        [Required]  
        [MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; } = string.Empty;       
       
        public string? Gender { get; set; } 

        
        public DateTime DOB { get; set; }

        [Required]
        [MaxLength(15)]
        public string MobileNo { get; set; } = string.Empty;

        public Boolean EmailConfirmed { get; set; }

        public string EmailConfirmationToken { get; set; } = string.Empty;

        public DateTime EmailConfirmationTokenExpiry { get; set; }


        public Boolean MobileNoConfirmed { get; set; }

        public string MobileConfirmationToken { get; set; } = string.Empty;

        public DateTime MobileConfirmationTokenExpiry { get; set; }


        [Required]
        [MaxLength(100)]
        [EmailAddress]
        public string EmailID { get; set; } = string.Empty;

        [MaxLength(250)]
        public string? Address1 { get; set; } 
    
        [MaxLength(250)]
        public string? Address2 { get; set; }

        [MaxLength(100)]
        public string? City { get; set; }

        [MaxLength(100)]
        public string? State { get; set; } 

        [MaxLength(50)]
        public string? ZipCode { get; set; } 

        [MaxLength(50)]
        public string? Country { get; set; } 
          
        public int? ZipIntID { get; set; }

        public int? RelationshipTypeID { get; set; }


        public Boolean IsPrimaryMem { get; set; }

        public Boolean HasLogin { get; set; }
        
        [MaxLength(100)]
        public string? MemberPhotoURL { get; set; } 

        public DateTime AddDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? AddedBy { get; set; } 
        public string? ModifiedBy { get; set; }

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }
        /*
                [ForeignKey("UserID")]
                public virtual User User { get; set; } = null!;
        */

        [ForeignKey("RelationshipTypeID")]
        public virtual RelationshipType RelationshipType { get; set; } = null!;

        /*

        public virtual ICollection<MemberInsEligibility> MemberInsEligibility { get; set; }= new List<MemberInsEligibility>();

        
        public virtual ICollection<MemberInsurance> MemberInsurance { get; set; } = new List<MemberInsurance>();
        */









    }
}
