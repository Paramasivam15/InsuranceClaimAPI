import { useSearchParams } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { VerifyTokenAPI } from "../services/api";
const VerifyToken = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [status, setstatus] = useState(null);
    const [searchParams, setSearchParams] = useSearchParams();

    // Get a specific query parameter 
    const memberId = searchParams.get('memberId');
    const token = searchParams.get('token');
    const IsMobile = searchParams.get('IsMobile');
    console.log(memberId);
    console.log(token);
    console.log(IsMobile);
  
    const handleSubmit = async (e) => {
            e.preventDefault();
            const res = await VerifyTokenAPI({ memberId, token,IsMobile });
            // console.log(res);
            setstatus(res.status);           
            setData(res.message);
        };
 
    return (
        <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
            <div className="sm:mx-auto sm:w-full sm:max-w-sm">
                <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-gray-900">
                    Active Patient -Token Verification

                </h2>
            </div>

            <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
                <form className="space-y-6" onSubmit={handleSubmit} >
                    <div>
                        <label htmlFor="token" className="block text-sm/6 font-medium text-gray-900">
                            Email Token
                        </label>
                        <div className="mt-2">
                            <input
                                id="token"
                                name="token"
                                value={token || ''}
                                type="token" disabled={true}
                                autoComplete="email"
                                className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                            />
                        </div>
                    </div>



                    <div>
                        <button
                            type="submit"
                            className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        >
                            Verify Token
                        </button>
                    </div>
                </form>

                

                    {(status === 'Success') ? (
                        <div className="text-green-600">
                            <p className="mt-10 text-center text-sm/6 text-green-500">
                            {data}
                            you can 
                                <a href="/login" className="font-semibold text-indigo-600 hover:text-indigo-500"> Sign In </a>
                                to your account.</p>
                        </div>
                    ) : (
                        <div>
                            <p className="mt-10 text-center text-sm/6 text-red-500">
                            {data}</p>
                        </div>
                    )
                    }
               
            </div>
        </div>
    );       
};

export default VerifyToken;
