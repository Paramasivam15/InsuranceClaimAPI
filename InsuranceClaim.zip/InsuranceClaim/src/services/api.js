const API_URL = "https://localhost:7233/api";
//const API_URL = process.env.REACT_APP_API_URL;
import axios from "axios";

export async function login(data) {
  const res = await fetch(`${API_URL}/Users/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
 return await res.json();
}

export async function register(data) {
  const res = await fetch(`${API_URL}/Users/Register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
   const response = await res.json();
   return { status: response.status, message: response.message };
}

export async function SaveMember(data) {
  console.log("Call from SaveMember")
  const res = await fetch(`${API_URL}/Users/SaveMember`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
   const response = await res.json();
   console.log("member result",response);
   return { status: response.status, message: response.message,memberID: response.memberID};
}

export async function ChangePasswordAPI(data) {
  const res = await fetch(`${API_URL}/Users/ChangePassword`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
  
}

export async function forgotPassword(data) {
    try {
  console.log("Forgot Password API called with data:", data.email);
  console.log("API URL:", `${API_URL}/Users/ForgotPassword?email=${data.email}`);
  const res = await fetch(`${API_URL}/Users/ForgotPassword?email=${data.email}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },    
  });
  return await res.json();
  } catch (err) {   
    console.error("Error in forgotPassword API:", err);
    return { message: "Failed to send reset password email. Please try again." };
  } finally {

  } 
}

export async function VerifyTokenAPI(data) {
  try {
    console.log(`${API_URL}/Users/${data.IsMobile=="1"? "Verify-Mobile":"Verify-Email"}`);
    const res = await fetch(`${API_URL}/Users/${data.IsMobile=="1"? "Verify-Mobile":"Verify-Email"}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
  
    const response = await res.json();
      if (!res.ok) {
      return { status: "Error", message: "Token is not verified successfully. Please try again." };
    }else
    {    
    return { status: response.status, message: response.message };
    }
  } catch (err) {   
       return { status: "Error", message: "Token is not verified successfully. Please try again." };
  } finally {

  }  
}

export async function GetRelationshipType() 
{
 const res = await fetch(`${API_URL}/Users/GetRelationshipType`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },  
  });
  return await res.json();
}

export async function GetDistinctState() 
{
 const res = await fetch(`${API_URL}/Users/GetDistinctState`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },  
  });
  return await res.json();
}

export async function GetDistinctZipbyState(data) 
{

 const res = await fetch(`${API_URL}/Users/GetDistinctZipbyState?State=${data}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },  
  });
  return await res.json();
}

export async function GetZipDatabyCode(data) 
{

 const res = await fetch(`${API_URL}/Users/GetZipDatabyCode?zipcode=${data}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },  
  });
  return await res.json();
}




export async function getProfile(token) {
  const res = await fetch(`${API_URL}/Users/profile`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return await res.json();
}

export async function GetFamilyDepedentFormattedData(token) {
  const res = await fetch(`${API_URL}/Users/GetFamilyDepedentFormattedData`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return await res.json();
}

export async function GetFamilyDepedent(token) {
  const res = await fetch(`${API_URL}/Users/GetFamilyDepedent`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return await res.json();
}

export async function GetMemberById(data) 
{

 const res = await fetch(`${API_URL}/Users/GetMemberById?memberId=${data}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },  
  });
  return await res.json();
}

export async function uploadfile(formData) {
  try {
    console.log("axios",formData);
    const response = await axios.post(`${API_URL}/Users/Uploadfile`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    console.log('Upload successful: ' + response.data.fileName);
    setselectedFile(null);
  } catch (error) {
    console.log('Upload failed',error);
  }

}


export async function DeleteMemeber(data) {
    try {

  console.log("API URL:", `${API_URL}/Users/DeleteMember?MemberId=${data}`);
  const res = await fetch(`${API_URL}/Users/DeleteMember?MemberId=${data}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },    
  });
  return await res.json();
  } catch (err) {   
    console.error("Error in DeleteMemeber API:", err);
    return { message: "Error in DeleteMemeber API:" };
  } finally {

  } 
}

export async function UpdateMemberPasswordLinkShow(data) {
    try {

  console.log("API URL:", `${API_URL}/Users/UpdateMemberPasswordLinkShow?MemberId=${data}`);
  const res = await fetch(`${API_URL}/Users/UpdateMemberPasswordLinkShow?MemberID=${data}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },    
  });
  return await res.json();
  } catch (err) {   
    console.error("Error in UpdateMemberPasswordLinkShow API:", err);
    return { message: "Error in UpdateMemberPasswordLinkShow API:" };
  } finally {

  } 
}
