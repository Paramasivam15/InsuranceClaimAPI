import Header from "../components/Header";
import Footer from "../components/Footer";

import * as React from 'react';

import { Grid, TextField, Button, IconButton } from "@mui/material";
import { Search, FilterList, InfoOutlined } from "@mui/icons-material";

const members = [
  {
    familyId: "FAM-1001",
    name: "Robert Johnson",
    mobile: "(555) 123-4567",
    membersCount: 3,
    billReviews: 5,
  },
  {
    familyId: "FAM-1002",
    name: "Jennifer Lee",
    mobile: "(555) 987-6543",
    membersCount: 1,
    billReviews: 2,
  },
];

export default function Timeline() {
  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="Timeline" />
      <div className="p-4">
        <h2>Welcome to Timeline!</h2>
        {/* Actual dashboard content */}

         <h2>Grid Work!</h2>
      </div>
      <div className="bg-purple-50 min-h-screen p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">Member Management</h1>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <input
              type="search"
              placeholder="Search..."
              className="rounded-md border border-gray-300 px-3 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
            <Search className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <div className="relative cursor-pointer">
            <div className="bg-red-600 text-white rounded-full text-xs w-5 h-5 flex justify-center items-center absolute -top-2 -right-2">
              3
            </div>
            <img
              src="https://i.pravatar.cc/40?img=12"
              alt="User"
              className="w-10 h-10 rounded-full"
            />
          </div>
        </div>
      </div>

      {/* Search Filters */}
      <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Name
            </label>
            <input
              type="text"
              placeholder="e.g. John Doe"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Family ID
            </label>
            <input
              type="text"
              placeholder="e.g. F-12345"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Mobile #
            </label>
            <input
              type="text"
              placeholder="e.g. 555-1234"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date From</label>
            <input
              type="date"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date To</label>
            <input
              type="date"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={12} md={1}>
            <Button
              variant="contained"
              color="primary"
              className="h-full w-full capitalize flex items-center justify-center space-x-1"
              startIcon={<FilterList />}
            >
              Apply
            </Button>
          </Grid>
        </Grid>
      </div>

      {/* Member List */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <h2 className="font-semibold text-gray-700 mb-4">Member List</h2>

        <table className="w-full table-fixed border-collapse text-sm text-gray-600">
          <thead className="bg-purple-100 text-gray-600 font-semibold text-left">
            <tr>
              <th className="p-3 w-1/6">FAMILY ID</th>
              <th className="p-3 w-1/4">NAME</th>
              <th className="p-3 w-1/5">MOBILE #</th>
              <th className="p-3 w-1/12"># OF MEMBERS</th>
              <th className="p-3 w-1/12"># OF BILL REVIEWS</th>
              <th className="p-3 w-1/4">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr
                key={m.familyId}
                className="border-t border-purple-200 hover:bg-purple-50"
              >
                <td className="p-3">{m.familyId}</td>
                <td className="p-3">{m.name}</td>
                <td className="p-3">{m.mobile}</td>
                <td className="p-3 flex items-center space-x-1">
                  <span>{m.membersCount}</span>
                  <InfoOutlined className="text-gray-500 text-xs cursor-pointer" />
                </td>
                <td className="p-3">{m.billReviews}</td>
                <td className="p-3 space-x-2 text-indigo-600 text-sm">
                  <button className="hover:underline">Insurance</button>|
                  <button className="hover:underline">Vault</button>|
                  <button className="hover:underline">Ledger</button>|
                  <button className="hover:underline">Bill Review</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>


      <Footer />
    </div>
  );
}
