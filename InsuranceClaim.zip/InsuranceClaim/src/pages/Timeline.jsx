import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Timeline() {
  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="Timeline" />
      <div className="p-4">
        <h2>Welcome to Timeline!</h2>
        {/* Actual dashboard content */}
      </div>
      <Footer />
    </div>
  );
}
