import React, { useState } from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useNavigate } from "react-router-dom";


const Unauthorized = () => {
  
  return (
       <div className="pt-16 pb-16 h-screen overflow-y-scroll">
       
       <div className="p-4">
      <h1></h1>
      <h2 className="text-2xl font-bold">Unauthorized access</h2>  
        <a href="/admin-dashboard" className="font-semibold text-indigo-600 hover:text-indigo-500">Admin Dashboard </a>  
    </div>  
    
  </div>    
  );
};

export default Unauthorized;
