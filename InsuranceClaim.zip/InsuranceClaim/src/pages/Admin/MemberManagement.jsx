import React, { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { Grid, TextField, Button, IconButton } from "@mui/material";
import { Search, FilterList, InfoOutlined } from "@mui/icons-material";
import { useAuth } from '../../components/authContext';

export default function MemberManagement() {

      const { user,rolePermission, canViewDashboard} = useAuth();
  
    const member = [
  {
    familyId: "FAM-1001",
    name: "Robert Johnson",
    mobile: "(555) 123-4567",
    membersCount: 3,
    billReviews: 5,
  },
  {
    familyId: "FAM-1002",
    name: "Jennifer Lee",
    mobile: "(555) 987-6543",
    membersCount: 1,
    billReviews: 2,
  },
];

 // Search state
  const [searchParams, setSearchParams] = useState({
    name: "",
    familyId: "",
    mobile: "",
    dateFrom: "",
    dateTo: "",
  });

  // Members state
  const [members, setMembers] = useState(member);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchParams((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Submit search to API
  const handleSearch = async () => {
    try {
      const response = await fetch("/api/members/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(searchParams),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch members");
      }

      const data = await response.json();
      setMembers(data);
    } catch (error) {
      console.error("Search error:", error);
      setMembers([]); // Clear on error or optionally show a message
    }
  };

  return (
    <Layout title="Member Management">
       <div className="bg-#FAF7FF-50 ">
        <div>Welcome, {user.role}</div>
          <div>canViewDashboard, {rolePermission.canViewDashboard}</div>

      {/* Search Filters */}
      <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Name
            </label>
            <input
              type="text"
              name="name"
              value={searchParams.name}
              onChange={handleChange}
              placeholder="e.g. John Doe"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Family ID
            </label>
            <input
              type="text"
              name="familyId"
              value={searchParams.familyId}
              onChange={handleChange}
              placeholder="e.g. F-12345"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={6} md={2.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">
              Search By Mobile #
            </label>
            <input
              type="text"
              name="mobile"
              value={searchParams.mobile}
              onChange={handleChange}
              placeholder="e.g. 555-1234"
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date From</label>
            <input
              type="date"
              name="dateFrom"
              value={searchParams.dateFrom}
              onChange={handleChange}
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">Date To</label>
            <input
              type="date"
              name="dateTo"
              value={searchParams.dateTo}
              onChange={handleChange}
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={12} md={1}>
            <Button
              variant="contained"
              color="primary"
              className="h-full w-full capitalize flex items-center justify-center space-x-1"
              startIcon={<FilterList />}
              onClick={handleSearch}
            >
              Apply
            </Button>
          </Grid>
        </Grid>
      </div>

      {/* Member List */}
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <h2 className="font-semibold text-gray-700 mb-4">Member List</h2>

        <table className="w-full table-fixed border-collapse text-sm text-gray-600">
          <thead className="bg-purple-50 text-gray-600 font-semibold text-left">
            <tr>
              <th className="p-3 w-1/6">FAMILY ID</th>
              <th className="p-3 w-1/4">NAME</th>
              <th className="p-3 w-1/5">MOBILE #</th>
              <th className="p-3 w-1/12"># OF MEMBERS</th>
              <th className="p-3 w-1/12"># OF BILL REVIEWS</th>
              <th className="p-3 w-1/4">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {members.length > 0 ? (
              members.map((m) => (
                <tr
                  key={m.familyId}
                  className="border-t border-purple-200 hover:bg-purple-50"
                >
                  <td className="p-3">{m.familyId}</td>
                  <td className="p-3">{m.name}</td>
                  <td className="p-3">{m.mobile}</td>
                  <td className="p-3 flex items-center space-x-1">
                    <span>{m.membersCount}</span>
                    <InfoOutlined className="text-gray-500 text-xs cursor-pointer" />
                  </td>
                  <td className="p-3">{m.billReviews}</td>
                  <td className="p-3 space-x-2 text-indigo-600 text-sm">
                    <button className="hover:underline">Insurance</button>|
                    <button className="hover:underline">Vault</button>|
                    <button className="hover:underline">Ledger</button>|
                    <button className="hover:underline">Bill Review</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="text-center p-6 text-gray-400">
                  No members found. Please use the search above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>

    </Layout>
  );
}
