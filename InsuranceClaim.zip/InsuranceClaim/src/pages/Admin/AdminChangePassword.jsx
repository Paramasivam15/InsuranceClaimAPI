import React, { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { Grid, TextField, Button, IconButton } from "@mui/material";
import { Search, FilterList, InfoOutlined } from "@mui/icons-material";


export default function AdminChangePassword() {
  

  return (
    <Layout title="Change Password">
       <div className="bg-#FAF7FF-50 ">
   

      </div>
    </Layout>
  );
}
