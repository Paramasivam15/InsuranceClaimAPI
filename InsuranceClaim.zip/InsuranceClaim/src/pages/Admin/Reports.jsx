import React, { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { Grid, TextField, Button, IconButton } from "@mui/material";
import { Search, FilterList, InfoOutlined } from "@mui/icons-material";
import { Tabs, Tab, Box, Typography } from '@mui/material';

export default function Reports() {

 // Search state
  const [searchParams, setSearchParams] = useState({   
    dateFrom: "",
    dateTo: "",
  });

 // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchParams((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

   // Submit search to API
  const handleSearch = async () => {
    try {
      const response = await fetch("/api/members/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(searchParams),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch members");
      }

      const data = await response.json();
      setMembers(data);
    } catch (error) {
      console.error("Search error:", error);
      setMembers([]); // Clear on error or optionally show a message
    }
  };


  function a11yProps(index) {
    return {
      id: `settings-tab-${index}`,
      'aria-controls': `settings-tabpanel-${index}`,
    };
  }
  
  function TabPanel({ children, value, index, ...other }) {
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`reports-tabpanel-${index}`}
        aria-labelledby={`settings-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            {children}
          </Box>
        )}
      </div>
    );
  }

   const [tabValue, setTabValue] = React.useState(0);
  
    const handleTabChange = (event, newVal) => {
      setTabValue(newVal);
    };

  return (
    <Layout title="Reports">
       <div className="bg-#FAF7FF-50 ">
        <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">From Date</label>
            <input
              type="date"
              name="dateFrom"
              value={searchParams.dateFrom}
              onChange={handleChange}
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={6} sm={3} md={1.5}>
            <label className="block mb-1 text-sm font-medium text-gray-700">To Date</label>
            <input
              type="date"
              name="dateTo"
              value={searchParams.dateTo}
              onChange={handleChange}
              className="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />
          </Grid>

          <Grid item xs={12} sm={12} md={1}>
            <Button
              variant="contained"
              color="primary"
              className="h-full w-full capitalize flex items-center justify-center space-x-1"
              startIcon={<FilterList />}
              onClick={handleSearch}
            >
              Apply Filters
            </Button>
          </Grid>

           <Grid item xs={12} sm={12} md={1}>
            <Button
              variant="contained"           
              className="h-full w-full  flex items-center justify-center space-x-1"
            >
              Export All
            </Button>
          </Grid>
        </Grid>
      </div>

       <Box sx={{ width: '100%' }}>
            {/* Tab headers */}
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                aria-label="Settings Tabs"
              >
                <Tab label="Non-Active Members" {...a11yProps(0)} />
                <Tab label="Eligibility Check" {...a11yProps(1)} />
                <Tab label="Bill Review Cases" {...a11yProps(0)} />
                <Tab label="Eligibility Check" {...a11yProps(1)} />
              </Tabs>
            </Box>
      
            {/* Tab panels */}
            <TabPanel value={tabValue} index={0}>
             
            <Typography variant="h6">Non-Active Members Report</Typography>
            </TabPanel>
            <TabPanel value={tabValue} index={1}>
           
              <Typography variant="h6">Eligibility Check</Typography>
             
            </TabPanel>
             <TabPanel value={tabValue} index={2}>
           
              <Typography variant="h6">Bill Review Cases</Typography>
             
            </TabPanel>
             <TabPanel value={tabValue} index={3}>
           
              <Typography variant="h6">Eligibility Check</Typography>
             
            </TabPanel>
          </Box>

      </div>
    </Layout>
  );
}
