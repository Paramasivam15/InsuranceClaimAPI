import React, { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { Grid, TextField, Button, IconButton } from "@mui/material";
import { Search, FilterList, InfoOutlined } from "@mui/icons-material";
import { useAuth } from '../../components/authContext';

export default function AdminDashboard() {
  
  const { user } = useAuth();
  return (
    <Layout title="Dashboard">
       <div className="bg-#FAF7FF-50 ">
           <div>Welcome, {user.role}</div>

      </div>
    </Layout>
  );
}
