import React, { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { Tabs, Tab, Box, Typography } from '@mui/material';
import RolePermission from '../../components/Role-Management/RolePermission';
function a11yProps(index) {
  return {
    id: `settings-tab-${index}`,
    'aria-controls': `settings-tabpanel-${index}`,
  };
}

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`settings-tabpanel-${index}`}
      aria-labelledby={`settings-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}
export default function Settings() {
  
 const [tabValue, setTabValue] = React.useState(0);

  const handleTabChange = (event, newVal) => {
    setTabValue(newVal);
  };
  return (
    <Layout title="Settings">
       <div className="bg-#FAF7FF-50 ">
       <Box sx={{ width: '100%' }}>
      {/* Tab headers */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          aria-label="Settings Tabs"
        >
          <Tab label="System Settings" {...a11yProps(0)} />
          <Tab label="Role Management" {...a11yProps(1)} />
        </Tabs>
      </Box>

      {/* Tab panels */}
      <TabPanel value={tabValue} index={0}>
       
      <Typography variant="h6">System Settings</Typography>
      </TabPanel>
      <TabPanel value={tabValue} index={1}>
     
      <Typography variant="h6">Role Management Content</Typography>
       <RolePermission/>
      </TabPanel>
    </Box>

      </div>
    </Layout>
  );
}
