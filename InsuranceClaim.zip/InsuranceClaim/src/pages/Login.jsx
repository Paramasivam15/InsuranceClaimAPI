import { useState,useEffect  } from "react";
import { loginAPI } from "../services/api";
import { useNavigate,useSearchParams  } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import { useAuth } from "../components/authContext";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function Login() {

    
    const { login } = useAuth();
    const [message, setmessage] = useState(null);
     const [isLoading, setIsLoading] = useState(false);
    const [status, setstatus] = useState(null);
    const [email, setEmail] = useState("");
    const [mobile, setmobile] = useState("");
    const [otp, setotp] = useState("");
    const [password, setPassword] = useState("");
    const [selectedTab, setSelectedTab] = useState("web");
    const navigate = useNavigate();
     const [searchParams, setSearchParams] = useSearchParams();
     const [Ismobile, setIsmobile] = useState("");
    const [userId, setuserId] = useState("");
    
    

  useEffect(() => {
    
     if (searchParams !== null && searchParams.size > 0) {
    const IsMobile = searchParams.get('IsMobile');
    const userId = searchParams.get('userId'); 
    const token = searchParams.get('token'); 
    const useremail = searchParams.get('useremail');
    setIsmobile(IsMobile);
    setuserId(userId);
 
    
    console.log("userId:", userId); console.log("token:", token);console.log("IsMobile:", IsMobile);
     if (IsMobile === '1') {
        console.log("IsMobile:", IsMobile);
        setSelectedTab("mobile");   
        setmobile(useremail); // Set mobile from useremail     
        setotp(token); // Set OTP from token  
        console.log("Mobile",mobile); console.log("OTP:", otp);
      } else {      
         setSelectedTab("web");
         setEmail(useremail); // Set email from useremail        
         setPassword(token); // Set password from token
         console.log("Password",password); console.log("Email:", useremail);
      }

    }
  }, [Ismobile]);

    const handleSocialAuth = (provider) => {
      alert('Integration with social authentication providers is not implemented yet.');
    // Simulate social authentication
    //console.log(`Authenticating with ${provider}`);
    //localStorage.setItem('authToken', `${provider}-token`);
    //setIsAuthenticated(true);
    //setCurrentUser(mockUser);
  };


    const handleSubmit = async (e) => {
        e.preventDefault();
         setIsLoading(true); // Show loader
        const credentials = selectedTab === "web" ? password : otp;
        console.log("Selected Tab:", selectedTab);     
        const res = await loginAPI({ mobile,email, password ,otp,selectedTab,userId});
        console.log ("Login Response:", res);
        console.log("Login Response Message:", res.message);
        if (res.status==='Success') {
          console.log(res.token);  console.log(typeof res.userId);  
           toast.success(res.message);    
           setIsLoading(false); // Hide loader   
            login({
            token: res.token,
            role: res.role,
            fname: res.firstName,
            lname: res.lastName,
            Mid:res.memberId,
            LoginUserId:res.userId,
            email:res.email,
            Profilephoto:res.profileImageUrl,
            isAuthenticated:true,           
            isPasswordlinkShow:res.isPasswordlinkShow,
            rolePermission:res.permissions
          });  
           if(res.role === "User")        
           navigate("/Dashboard");
          else
          navigate("/member-portal");
        } else {
            setstatus(res.status);           
            setmessage(res.message);
             toast.error(res.message);  
            setIsLoading(false); // Hide loader
            //alert("Login failed");
        }
    };

    return (
     <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="mb-6 text-center">
       
        <h1 className="text-3xl font-bold text-blue-700">Active Patient</h1>
       
      </div>
      
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-md p-6">
        <div className="flex mb-6 border-b border-gray-200">
          <button
            className={`flex-1 py-2 text-center font-semibold ${
              selectedTab === "web"
                ? "border-b-2 border-blue-500 text-blue-600"
                : "text-gray-500"
            }`}
            onClick={() => setSelectedTab("web")}
          >
            Web
          </button>
          <button
            className={`flex-1 py-2 text-center font-semibold ${
              selectedTab === "mobile"
                ? "border-b-2 border-blue-500 text-blue-600"
                : "text-gray-500"
            }`}
            onClick={() => setSelectedTab("mobile")}
          >
            Mobile
          </button>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
          {selectedTab === "web" && (
            <>
              <div>
                <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                Email address
              </label>

                  <div className="mt-2">
                <input
                  id="email"
                  name="email"
                  type="email"    
                  value={email || ''}             
                  required
                   onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
              </div>
                        <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">
                  Password
                </label>
                <div className="text-sm">
                  <a href="/forgotpassword" className="font-semibold text-indigo-600 hover:text-indigo-500">
                    Forgot password?
                  </a>
                </div>
              </div>
              <div className="mt-2">
                <input
                  id="password"
                  name="password"
                  type="password"
                  value={password || ''}
                  required
                  onChange={(e) => setPassword(e.target.value)} 
                  autoComplete="current-password"
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>
            </>
          )}

          {selectedTab === "mobile" && (
            <>
               <div>
                <label htmlFor="mobile" className="block text-sm/6 font-medium text-gray-900">
                Mobile Number
              </label>

                  <div className="mt-2">
                <input
                  id="mobile"
                  name="mobile"    
                  value={mobile || ''}                           
                  required
                   onChange={(e) => setmobile(e.target.value)}
                  autoComplete="mobile"
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
              </div>
                        <div>
              <div className="flex items-center justify-between">
                <label htmlFor="otp" className="block text-sm/6 font-medium text-gray-900">
                  One-Time Password (OTP)
                </label>
                <div className="text-sm">
                  <a href="/forgotpassword" className="font-semibold text-indigo-600 hover:text-indigo-500">
                    Forgot password?
                  </a>
                </div>
              </div>
              <div className="mt-2">
                <input
                  id="otp"
                  name="otp"  
                  value={otp || ''}               
                  required
                  onChange={(e) => setotp(e.target.value)}                  
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>
            </>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
          >
            Login
          </button>
          
        </form>

        <div className="mt-7">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Or continue with</span>
            </div>
          </div>
          </div>

            <div className="mt-6 grid grid-cols-3 gap-3 text-center">
            <button
              onClick={() => handleSocialAuth('google')}
               className="w-full inline-flex justify-center py-3 px-4 border border-gray-300 rounded-lg bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"

            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
            
            </button>

            <button
              onClick={() => handleSocialAuth('linkedin')}
              className="w-full inline-flex justify-center py-3 px-4 border border-gray-300 rounded-lg bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"

            >
              <svg className="w-5 h-5" fill="#0077B5" viewBox="0 0 24 24">
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
              </svg>
             
            </button>

            <button
              onClick={() => handleSocialAuth('Twitter')}
               className="w-full inline-flex justify-center py-3 px-4 border border-gray-300 rounded-lg bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"

            >
             <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path fill="#000000" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path>
                    </svg>
             
            </button>
          </div>
        
         {/* Display message based on login status */}
          {(status === 'Success') ? (
            <div className="text-green-600">
              <p className="mt-10 text-center text-sm/6 text-green-500">
                {message}
            </p>
            </div>
          ) : (
            <div>
              <p className="mt-10 text-center text-sm/6 text-red-500">
                {message}</p>
            </div>
          )          
          }
          
          <p className="mt-10 text-center text-sm/6 text-gray-500">
            Not a member?{' '}             
             <a href="/register" className="font-semibold text-indigo-600 hover:text-indigo-500">Create Account</a>  
                
          </p>
          <div className="mb-6 text-center">
           {isLoading ? (
                <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
              ) : null}    
          </div>
           <ToastContainer />
      </div>
    </div>
    );
}