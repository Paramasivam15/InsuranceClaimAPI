import React, { useState } from 'react';
import axios from 'axios';
import Avatar from '@mui/material/Avatar';
import { useAuth } from '../components/authContext';


const Vault = () => {
   const { user } = useAuth();
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [IsProfileFileType, setIsProfileFileType]=useState(true);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

const handleUpload = async () => {
    if (!selectedFile) return;
    const memberID = user.Mid;

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('memberID', memberID);
    formData.append('IsProfileFileType', IsProfileFileType);
    try {

      const response = await axios.post('https://localhost:7233/api/Users/Uploadfile', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert('Upload successful: ' + response.data.fileName);
    } catch (error) {
      alert('Upload failed');
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">Vault</h1>
      <p>Welcome to the Vault Module..Testing purpose</p>
      {previewUrl && (
        <div>
          <h3>Preview:</h3>        
          <Avatar alt="User Avatar" src={previewUrl} />  
        </div>
      )}
  
      <input type="file" accept="image/*" onChange={handleFileChange} />
      
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default Vault;
