import { useState } from "react";
import { forgotPassword } from "../services/api";
import { ClipLoader } from 'react-spinners'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function Forgotpassword() {
    const [email, setEmail] = useState("");  
    const [data, setData] = useState(null);
   const [isLoading, setIsLoading] = useState(false);


    const handleSubmit = async (e) => {
        e.preventDefault();

              setIsLoading(true); // Show loader
        const res = await forgotPassword({ email });
        if (res.message) 
            setData(res.message);
            toast.message(res.message);  
               setIsLoading(false); // Hide loader       
    };

    return (
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">         
          <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-gray-900">
            Reset Your Password
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                Email address:
              </label>
              <div className="mt-2">
                <input
                  id="email"
                  name="email"
                  type="email"                 
                  required
                   onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>           

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Send
              </button>
            </div>
                    <div className="text-green-600">
                        <p className="mt-10 text-center text-sm/6 text-green-500">
                            {data}
                        </p>
           </div>
            <p className="mt-10 text-center text-sm/6 text-gray-500">
            You are a  member?{' '}
           
              <a href="/login" className="font-semibold text-indigo-600 hover:text-indigo-500">Sign In </a>   
               {isLoading ? (
                <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
              ) : null}                  
          </p>
          </form>

         
        </div>
      </div>
    );
}