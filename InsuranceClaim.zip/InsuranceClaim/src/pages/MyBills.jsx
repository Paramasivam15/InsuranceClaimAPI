import Header from "../components/Header";
import Footer from "../components/Footer";

export default function MyBills() {
  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="My Bills" />
      <div className="p-4">
        <h2>Welcome to My Bills!</h2>
        {/* Actual dashboard content */}
      </div>
      <Footer />
    </div>
  );
}