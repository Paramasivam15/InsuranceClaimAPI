import React, { useState, useEffect } from 'react';
import { useNavigate,useParams } from "react-router-dom";
import {
  Box
} from '@mui/material';

import Header from "../components/Header";
import Footer from "../components/Footer";
import { GetFamilyDepedent } from '../services/api';
import { useAuth } from '../components/authContext';
export default function MyBills() {
  const navigate = useNavigate();
   const { user } = useAuth();
  const [memberId, setmemberId] = useState(user.Mid);
  const [depedent, setdepedent] = useState([]);
  const [dob, setdob] = useState({ startDate: null, endDate: null });
  const [startDate, setStartDate] = useState(new Date('2024-01-01'));
  const [endDate, setEndDate] = useState(new Date('2024-12-31'));

  const handleChange = (e) => {
    setmemberId(e.target.value)
    console.log('Selected member Id:', e.target.value);

    const selectedmember = depedent.filter(item => item.memberID === e.target.value);
    //  setmember(selectedmember);
    console.log('Selected member:', selectedmember);
  };

  const handleAddBills = () => {
  //  navigate("/upload_Bills");
  }

  useEffect(() => {

    const userID = user.Mid;

    async function fetchFamilyDepedentData() {
      const token = user.token;
      const res = await GetFamilyDepedent(token);
      setdepedent(res);
      console.log("Depedent", res);
    }

    fetchFamilyDepedentData();

  }, []);

  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="My Bills" />
      <div className="p-4">
        <h2>Welcome to My Bills!</h2>
        {/* Actual dashboard content */}
          <header className="top-0 w-full bg-white  z-50 p-4 flex ">
            <h1 className="text-xl font-semibold  flex-grow "></h1>
            <div className="flex space-x-4 items-center">
              <button
                type="submit"
                onClick={() => handleAddBills()}
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Upload
              </button>
            </div>
          </header>
        <div className="bg-white-100 p-2">
          <div className="bg-white  w-full max-w p-4"></div>
          <Box className="flex gap-4 mb-4">

            <input
              id="startDate"
              name="startDate"
              type="date"
              value={startDate}
              required
              min={'1975-01-01'}
              onChange={(e) => setStartDate(e.target.value)}
              className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
            />

            <input
              id="endDate"
              name="endDate"
              type="date"
              value={endDate}
              required
              min={'1975-01-01'}
              onChange={(e) => setEndDate(e.target.value)}
              className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
            />


          </Box>
          <div className="bg-white  w-full max-w">
            <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
              id="viewmembers"
              name="viewmembers"
              required
              value={memberId}
              onChange={handleChange}
            >
              {
                depedent.map((mem) => (
                  <option key={mem.memberID} value={mem.memberID}
                  >
                    {mem.firstName}
                  </option>
                ))
              }

            </select>
          </div>

        </div>
      </div>
      <Footer />
    </div>
  );
}