import Header from "../components/Header";
import Footer from "../components/Footer";
import React, { use } from "react";
import { useState, useEffect } from "react";
import {
  Tabs,
  TabsHeader,
  TabsBody,
  Tab,
  TabPanel,
} from "@material-tailwind/react";
import { useNavigate,useParams } from "react-router-dom";

import FamilyGroup from "../components/family/FamilyGroup";
import { GetFamilyDepedentFormattedData, GetMemberInsuranceByMemberID,GetPolicyType } from "../services/api";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ClipLoader } from 'react-spinners'
import Insurance from "../components/family/Insurance";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa";
import { useAuth } from "../components/authContext";

export default function MyFamily() {
  const navigate = useNavigate();
  const { action } = useParams();
   const { user } = useAuth();
  const [message, setmessage] = useState(null);
  const [status, setstatus] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const [activeTab, setActiveTab] = React.useState((action==="member")?"tab1":"tab2");
  const [depedent, setdepedent] = useState([]);

  //Insurance

  const [insurance, setinsurance] = useState([]);
  const [LoginUserinsurance, setLoginUserinsurance] = useState([]);
  const [memberId, setmemberId] = useState(user.Mid);    
  const [policyType, setPolicyType] = useState([]);
//localStorage.getItem("Mid")

  useEffect(() => {
    console.log("Action", action);
  
    async function fetchdepedentData() {
      const token = user.token;
      const res = await GetFamilyDepedentFormattedData(token);
      console.log("Family_Depedent_Formatted_data", res);
      setdepedent(res);
      const policyTypes = await GetPolicyType();
      console.log("Policy Types", policyTypes);
      setPolicyType(policyTypes);
      const res1 = await GetMemberInsuranceByMemberID(user.Mid);
      if (res1 != null) {
        setinsurance(res1);
        console.log("GetMemberInsuranceByMemberID", res1);
        setLoginUserinsurance(res1);
      }
    }
    fetchdepedentData();  
    
    console.log("Active Tab",activeTab);
    console.log("mem ID",memberId);
    if(activeTab=="tab2" && action==insurance)
    {
       console.log("Reset memID as Login user mem ID",insurance);       
     console.log("LoginUserinsurance",LoginUserinsurance);
   //  if(LoginUserinsurance.length>0)
   //   setinsurance(LoginUserinsurance);  
    }
  
  }, [activeTab]);

 
  const handleAddMember = () => {
    navigate("/AddMember/0");
  }
  const handleAddInsurance = () => {
    navigate("/insurance/add/0/1");
  }

   const navigateToAddInsurance = (policyType) => {
    navigate("/insurance/add/" + memberId + "/" + policyType);
  };



  const handleInsuranceChange = async (e) => {
    setmemberId(e.target.value)
    console.log('Selected member Id from Insurance Tab:', e.target.value);
    const res = await GetMemberInsuranceByMemberID(e.target.value);
    if(res!=null)
    {
    setinsurance(res);
    console.log('Selected member insurance:', res);
    }

  };

  const relationOrder = {
    'Self': 1,
    'Spouse': 2,
    'Son': 3,
    'Daughter': 4,
    'Dad': 5,
    'Mom': 6,
    'FatherInLaw': 7,
    'MotherInLaw': 8
  };

  const grouped = {
  'HEAD OF HOUSEHOLD': Array.isArray(depedent)
    ? depedent
        .filter(m => ['Self', 'Spouse'].includes(m.relation))
        .sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation])
    : [],
  CHILDREN: Array.isArray(depedent)
    ? depedent
        .filter(m => ['Son', 'Daughter'].includes(m.relation))
        .sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation])
    : [],
  PARENTS: Array.isArray(depedent)
    ? depedent
        .filter(m => ['Mom', 'Dad'].includes(m.relation))
        .sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation])
    : [],
  'IN-LAW': Array.isArray(depedent)
    ? depedent
        .filter(m => ['MotherInLaw', 'FatherInLaw'].includes(m.relation))
        .sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation])
    : [],
};

  /*
  const grouped = {
    'HEAD OF HOUSEHOLD': depedent.filter(m => ['Self', 'Spouse'].includes(m.relation)).sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation]),
    CHILDREN: depedent.filter(m => ['Son', 'Daughter'].includes(m.relation)).sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation]),
    PARENTS: depedent.filter(m => ['Mom', 'Dad'].includes(m.relation)).sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation]),
    'IN-LAW': depedent.filter(m => ['MotherInLaw', 'FatherInLaw'].includes(m.relation)).sort((a, b) => relationOrder[a.relation] - relationOrder[b.relation]),
  };
  */

  const handleNotificationParent = async (dataFromChild) => {
    // alert(`Child says: ${dataFromChild}`);

    const token = user.token;
    const res = await GetFamilyDepedentFormattedData(token);
    setdepedent(res);
  };

  const onNotifyFamilyInsuranceGroup = async (message) => {
   // alert(`Child Insurancesays: ${message}`);
     const isSuccess = message.includes('success');
     console.log("isSuccess",isSuccess);
    if(isSuccess)
    {
      toast.success(message); 
     const res1 = await GetMemberInsuranceByMemberID(user.Mid);
     setinsurance(res1);
    }
    else
    {
      toast.error(message); 
    }
  };

  const data = [
    {
      label: "My Family",
      value: "tab1",
      content: (
        <div>

          <header className="top-0 w-full bg-white  z-50 p-4 flex ">
            <h1 className="text-xl font-semibold  flex-grow "></h1>
            <div className="flex space-x-4 items-center">
              <button
                type="submit"
                onClick={() => handleAddMember()}
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Add Member
              </button>
            </div>
          </header>
          <div className="p-6 max-w-full-7xl mx-auto">

            {Object.entries(grouped).map(([title, members]) => (
              members.length > 0 ? (
                <FamilyGroup key={title} title={title} members={members} onNotifyFamilyGroup={handleNotificationParent} />
              ) : null
            ))}
          </div>
        </div>
      ),
    },
    {
      label: "My Insurance",
      value: "tab2",
      content: (
        <div>

          <header className="top-0 w-full bg-white  z-50 p-4 flex ">
            <h1 className="text-xl font-semibold  flex-grow ">Insurance</h1>
            <div className="flex space-x-4 items-center">
              <button
                type="submit"
                onClick={() => handleAddInsurance()}
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Add Insurance
              </button>
            </div>
          </header>
               <div className="rounded-2xl border p-2 mt-1">
                              <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                                  Viewing For
                              </label>
                              <div className="mt-2">
                                  <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      id="viewmember"
                                      name="viewmember"
                                      value={memberId}
                                      required
                                      onChange={handleInsuranceChange}
                                  >
                                      {
                                          depedent.map((mem) => (
                                              <option key={mem.id} value={mem.id}
                                              >
                                                  {mem.name}
                                              </option>
                                          ))
                                      }
          
                                  </select>
                              </div>
             </div>

         
          <div className="p-6 max-w-full-7xl mx-auto">
            {policyType.map((policyType) => {
              // Filter insurances by current policyType.id
              const policyInsurances = insurance.filter(ins => ins.policyTypeID === policyType.id);

              return (
                <div key={policyType.id} className="max mx-auto">
                  <h2 className="text-sm font-semibold text-gray-700 uppercase mb-2">{policyType.type}</h2>

                  {policyInsurances.length === 0 ? (
                    <div
                      className="flex items-center justify-center border p-4 mb-4 rounded-2xl hover:bg-gray-50 cursor-pointer border-dashed border-violet-500 bg-violet-100"
                      onClick={() => navigateToAddInsurance(policyType.id)}
                    >
                      <svg width='18px' height='18px' stroke-width='2' fill='none'stroke='Blue' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                    </div>
                  ) : (
                    <div className="bg-white rounded-2xl border p-1">
                       <Insurance Memberinsurance={policyInsurances} memberId={memberId} onNotifyFamilyGroup={onNotifyFamilyInsuranceGroup} />  
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="Family Hub" />
      <div className="p-4">
     
      </div>
      {/* Actual Family content */}
      <div >
        <Tabs value={activeTab} className="max-w-[120rem]" >
          <TabsHeader
            className="bg-transparent"
            indicatorProps={{
              className: "bg-gray-900/10 shadow-none !text-gray-900",
            }}
          >
            {data.map(({ label, value }) => (
              <Tab
                key={value}
                value={value}
                onClick={() => setActiveTab(value)}
              >
                {label}
              </Tab>
            ))}
          </TabsHeader>
          <TabsBody>
            {data.map(({ value, content }) => (
              <TabPanel key={value} value={value}>
                {content}
              </TabPanel>
            ))}
          </TabsBody>
        </Tabs>

      </div>
      <div className="mb-6 text-center">
        {isLoading ? (
          <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
        ) : null}
      </div>
      <ToastContainer />

      <Footer />
    </div>
  );
}