import Header from "../components/Header";
import Footer from "../components/Footer";
import React from "react";
import { useState,useEffect } from "react";
import AddMember from "../components/family/AddMember";
import {
  Tabs,
  TabsHeader,
  TabsBody,
  Tab,
  TabPanel,
} from "@material-tailwind/react";
import { useNavigate  } from "react-router-dom";

import FamilyGroup from "../components/family/FamilyGroup";
import { GetFamilyDepedentFormattedData } from "../services/api";


export default function MyFamily() {
  const navigate = useNavigate();
const handleAddMember = () => {
     navigate("/AddMember");
}
  
  const [activeTab, setActiveTab] = React.useState("tab1");
  const [depedent, setdepedent] = useState([]);

    useEffect(() => {
    async function fetchdepedentData() {
       const token = localStorage.getItem("token");
       const res = await GetFamilyDepedentFormattedData(token);
       console.log(res);

      const family = [
  { id: 1, name: 'Param1', relation: 'Self', imageUrl: 'https://i.pravatar.cc/150?u=alexgreen' },
  { id: 2, name: 'Bhuv Param', relation: 'Spouse', imageUrl: 'https://i.pravatar.cc/150?u=janegreen' },
  { id: 3, name: 'Keerthi Param', relation: 'Daughter', imageUrl: 'https://i.pravatar.cc/150?u=leogreen' },
  { id: 4, name: 'Navaneethan Param', relation: 'Son', imageUrl: 'https://i.pravatar.cc/150?u=oliviagreen' },

];
    console.log(family);
setdepedent(res);

    }
    fetchdepedentData();
  }, [activeTab]);
  

   const grouped = {
    'HEAD OF HOUSEHOLD': depedent.filter(m => ['Self', 'Spouse'].includes(m.relation)),
    CHILDREN: depedent.filter(m => ['Son', 'Daughter'].includes(m.relation)),
    PARENTS: depedent.filter(m => ['Mother', 'Father'].includes(m.relation)),
  };

   const data = [
    {
      label: "My Family",
      value: "tab1",
      content: (
        <div>

          <header className="top-0 w-full bg-white  z-50 p-4 flex ">
            <h1 className="text-xl font-semibold  flex-grow "></h1>
            <div className="flex space-x-4 items-center">
              <button
                type="submit"
                onClick={() => handleAddMember()}
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Add Member
              </button>
            </div>
          </header>
          <div className="p-6 max-w-full-7xl mx-auto">
        
            {Object.entries(grouped).map(([title, members]) => (
             members.length > 0 ? (
              <FamilyGroup key={title} title={title} members={members} />
                ) : null
            ))}
          </div>
        </div>
      ),
    },
    {
      label: "My Insurance",
      value: "tab2",
      content: (
        <div>
         
            <header className="top-0 w-full bg-white  z-50 p-4 flex ">
            <h1 className="text-xl font-semibold  flex-grow ">Insurance</h1>
            <div className="flex space-x-4 items-center">
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Add Insurance
              </button>
            </div>
          </header>
        </div>
      ),
    },
  ];

  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="Family Hub" />
      <div className="p-4">
        <h2>Welcome to MyFamily!</h2>
        </div>
        {/* Actual Family content */}   
     <div >
       <Tabs value={activeTab} className="max-w-[120rem]" >
        <TabsHeader 
          className="bg-transparent" 
           indicatorProps={{
          className: "bg-gray-900/10 shadow-none !text-gray-900",
        }}
        >
          {data.map(({ label, value }) => (
            <Tab
              key={value}
              value={value}
              onClick={() => setActiveTab(value)}
            >
              {label}
            </Tab>
          ))}
        </TabsHeader>
        <TabsBody>
          {data.map(({ value, content }) => (
            <TabPanel key={value} value={value}>
              {content}
            </TabPanel>
          ))}
        </TabsBody>
      </Tabs>
    
      </div>
      
      <Footer />
    </div>
  );
}