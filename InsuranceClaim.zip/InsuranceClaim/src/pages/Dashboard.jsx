import { useEffect, useState } from "react";
import { getProfile } from "../services/api";
import Tree from 'react-d3-tree';

export default function Dashboard() {
  const [profile, setProfile] = useState({});

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    getProfile(token).then(setProfile);
  }, []);


  const AddInsurance = () => {
    alert("Add Insurance");
  }

   const AddFamilyMember= () => {
    alert("Add Family Member");
  }


const familyData = {
     name: "Parent 1",
          relationship: "Mother",
          children: [
            { name: "Child 1", relationship: "Daughter" },
            { name: "Child 2", relationship: "Son" },
          ]
    };

  return (
   
            <div className="container mx-auto mt-12">
                <div className="grid grid-cols-1 gap-6 mb-6 lg:grid-cols-3">
                    <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                        <div className="text-sm font-medium text-gray-500 truncate">
                            Member
                        </div>
                        <div className="mt-1 text-3xl font-semibold text-gray-900">
                           Welcome, {profile.firstName}
                        </div>
                    </div>
                    <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                        <div className="text-sm font-medium text-gray-500 truncate">
                            Email
                        </div>
                        <div className="mt-1 text-3xl font-semibold text-gray-900">
                           Email: {profile.emailID}
                        </div>
                    </div>
                    <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                      
                           <button className="flex justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600" onClick={AddFamilyMember}>Add Family Member</button>
                       
                    </div>
             
                  
                </div>
                <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Family Tree</h2>
                    <div style={{ width: '100%', height: '500px' }}>
                        <Tree data={familyData}  />
                    </div>
                    </div>
            </div>      
            
  );
}