
import { useState,useEffect  } from "react";
import { getProfile,UpdateMemberPasswordLinkShow } from "../services/api";
import Header from "../components/Header";
import Footer from "../components/Footer";
import WelcomeModule from "../components/Dashboard/WelcomeModule";
import UpcomingRenewals from "../components/Dashboard/UpcomingRenewals";
import RecentActivity from "../components/Dashboard/RecentActivity";
import TotalOwedChart from "../components/Dashboard/TotalOwedChart"; 
import OwedByTypeChart from "../components/Dashboard/OwedByTypeChart";
import DueVsPaidChart from "../components/Dashboard/DueVsPaidChart";
import FamilySpending from "../components/Dashboard/FamilySpending";
import DeductibleProgress from "../components/Dashboard/DeductibleProgress";
import TaxDeductionTracker from "../components/Dashboard/TaxDeductionTracker";
import CostBreakdown from "../components/Dashboard/CostBreakdown";
import Credit_Balances from "../components/Dashboard/Credit_Balances";
import RiskAnalysis from "../components/Dashboard/RiskAnalysis";

export default function Dashboard() {

  const [profile, setProfile] = useState({});
  const [isAddMode, setisAddMode] = useState(false);

 useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    getProfile(token).then(setProfile);  
    const memberID = localStorage.getItem("Mid");  
    UpdateMemberPasswordLinkShow(memberID);
  }, []);

 const chartData = [
    { label: 'Category A', value: 30 },
    { label: 'Category B', value: 20 },
    { label: 'Category C', value: 50 },
  ];

    const DuevsPaiddata = [
    { name: 'Member A', due: 1200, paid: 800 },
    { name: 'Member B', due: 1500, paid: 1500 },
    { name: 'Member C', due: 1000, paid: 400 },
  ];

  return (
    <div className="pt-16 pb-16 h-screen overflow-y-scroll">
      <Header title="Dashboard" />
      <div className="p-4">
     
        {/* Actual dashboard content */}
        <div className="mb-4">
        <WelcomeModule paramprofile={profile} />
        </div>
         { isAddMode && (
            <>
         <div className="mb-4">
        <UpcomingRenewals paramUpcomingRenewals={profile} />
        </div>
        <div className="mb-4">
        <RecentActivity paramRecentActivity={profile} />
        </div>
        <div className="mb-4">
        <TotalOwedChart data={chartData} width={200} height={200} />
        </div>
         <div className="mb-4">
        <OwedByTypeChart data={chartData} width={200} height={200} />
        </div>
         <div className="mb-4">
        <DueVsPaidChart data={DuevsPaiddata} width={400} height={300} />
        </div>
        <div className="mb-4">
         <FamilySpending />
        </div>
        <div className="mb-4">
         <DeductibleProgress />
        </div>
         <div className="mb-4">
         <TaxDeductionTracker />
        </div>
          <div className="mb-4">
         <CostBreakdown />
        </div>
        <div className="mb-4">
         <Credit_Balances />
        </div>
         <div className="mb-4">
         <RiskAnalysis />
        </div>
         </>
          )}      
      </div>
      <Footer />
    </div>
  );
}