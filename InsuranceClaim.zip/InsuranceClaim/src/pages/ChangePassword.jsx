import { useState } from "react";
import { ChangePasswordAPI } from "../services/api";
import { useNavigate  } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import Header from "../components/Header";
import Footer from "../components/Footer";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from "../components/authContext";


export default function ChangePassword() {
   const { user } = useAuth();
    const [message, setmessage] = useState(null);
  const [status, setstatus] = useState(null);
     const [isLoading, setIsLoading] = useState(false);
    const [CurrentPassword, setCurrentPassword] = useState("");
    const [NewPassword, setNewPassword] = useState("");
     const [ConfirmPassword, setConfirmPassword] = useState("");
     const [passwordMatchError, setPasswordMatchError] = useState('');
     const email = user.email
      const [data, setData] = useState(null);   
    const navigate = useNavigate();

    const handlePasswordChange = (e) => {
    setNewPassword(e.target.value);
    validatePasswords(e.target.value, ConfirmPassword);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
    validatePasswords(NewPassword, e.target.value);
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true); // Show loader
    if (NewPassword === ConfirmPassword && CurrentPassword !== '') {
      const res = await ChangePasswordAPI({ email, CurrentPassword, NewPassword, ConfirmPassword });
      setstatus(res.status);
      setmessage(res.message);
      if (res.status === 'Success')
        toast.success(res.message);
      else
        toast.error(res.message);


      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } else {
      // Handle submission error if passwords don't match or are empty
      console.log('Please ensure passwords match and are not empty.');
    }
    setIsLoading(false); // Hide loader        
  };

     const validatePasswords = (pwd, confirmPwd) => {
    if (pwd !== confirmPwd) {
      setPasswordMatchError('Passwords do not match');
    } else {
      setPasswordMatchError('');
    }
  };
    return (
        <div className="pt-16 pb-16 h-screen overflow-y-scroll">
            <Header title="" />
       <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="mb-6 text-center">
       
        <h1 className="text-3xl font-bold text-blue-700">Change Password</h1>
       
      </div>
       <div className="bg-white rounded-2xl shadow-lg w-full max-w-md p-6">

          <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                  Current Password
                </label>
                <div className="mt-2">
                  <input
                    id="currentPwd"
                    name="currentPwd"
                    type="password"
                    required
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">
                    New Password
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="newpassword"
                    name="newpassword"
                    type="password"
                    required
                    onChange={handlePasswordChange}
                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">
                    Confirm Password
                  </label>
                </div>
                <div className="mt-2">
                  <input
                    id="confirmpassword"
                    name="confirmpassword"
                    type="password"
                    required
                    onChange={handleConfirmPasswordChange}
                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                  />
                  {passwordMatchError && <p style={{ color: 'red' }}>{passwordMatchError}</p>}
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  Submit
                </button>
              </div>
            </form>

            <div className="text-green-600">
              <p className="mt-10 text-center text-sm/6 text-green-500">
               
                you can
                <a href="/login" className="font-semibold text-indigo-600 hover:text-indigo-500"> Sign In </a>
                to your account.              
              </p>
                {(status === 'Success') ? (
                  <div className="text-green-600">
                    <p className="mt-10 text-center text-sm/6 text-green-500">
                      {message}
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="mt-10 text-center text-sm/6 text-red-500">
                      {message}</p>
                  </div>
                )
                }
                 <div className="mb-6 text-center">
                {isLoading ? (
                <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
              ) : null}    
          </div>
            <ToastContainer />
            </div>
          </div>
        </div>
        </div>
        <Footer />
          </div>
    );
}