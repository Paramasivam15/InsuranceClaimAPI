import { useState } from "react";
import { ChangePasswordAPI } from "../services/api";
import { useNavigate  } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
export default function ChangePassword() {
     const [isLoading, setIsLoading] = useState(false);
    const [CurrentPassword, setCurrentPassword] = useState("");
    const [NewPassword, setNewPassword] = useState("");
     const [ConfirmPassword, setConfirmPassword] = useState("");
     const [passwordMatchError, setPasswordMatchError] = useState('');
     const email = localStorage.getItem("email");
      const [data, setData] = useState(null);   
    const navigate = useNavigate();

    const handlePasswordChange = (e) => {
    setNewPassword(e.target.value);
    validatePasswords(e.target.value, ConfirmPassword);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);
    validatePasswords(NewPassword, e.target.value);
  };


    const handleSubmit = async (e) => {
        e.preventDefault();
             setIsLoading(true); // Show loader
         if (NewPassword === ConfirmPassword && CurrentPassword !== '') {
        const res = await ChangePasswordAPI({ email, CurrentPassword, NewPassword, ConfirmPassword });      
           if (res.message) 
            setData(res.message);   
         }else {
      // Handle submission error if passwords don't match or are empty
      console.log('Please ensure passwords match and are not empty.');
    }
       setIsLoading(false); // Hide loader        
    };

     const validatePasswords = (pwd, confirmPwd) => {
    if (pwd !== confirmPwd) {
      setPasswordMatchError('Passwords do not match');
    } else {
      setPasswordMatchError('');
    }
  };
    return (
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">         
          <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-gray-900">
            Change Password
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                Current Password
              </label>
              <div className="mt-2">
                <input
                  id="currentPwd"
                  name="currentPwd"
                  type="password"                 
                  required
                   onChange={(e) => setCurrentPassword(e.target.value)}                     
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">
                  New Password
                </label>               
              </div>
              <div className="mt-2">
                <input
                  id="newpassword"
                  name="newpassword"
                  type="password"
                  required
                  onChange={handlePasswordChange}                
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>

             <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm/6 font-medium text-gray-900">
                  Confirm Password
                </label>               
              </div>
              <div className="mt-2">
                <input
                  id="confirmpassword"
                  name="confirmpassword"
                  type="password"
                  required
                  onChange={handleConfirmPasswordChange}             
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
                  {passwordMatchError && <p style={{ color: 'red' }}>{passwordMatchError}</p>}
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Submit
              </button>
            </div>
          </form>

       <div className="text-green-600">
                            <p className="mt-10 text-center text-sm/6 text-green-500">
                            {data}
                            you can 
                                <a href="/login" className="font-semibold text-indigo-600 hover:text-indigo-500"> Sign In </a>
                                to your account.
                              {isLoading ? (
                                <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
                              ) : null}       
                                </p>
       </div>
        </div>
      </div>
    );
}