import {  Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from './pages/Register';
import ChangePassword from './pages/ChangePassword';
import Forgotpassword from './pages/forgotpassword';
import Dashboard from "./pages/Dashboard";
import MyFamily from "./pages/MyFamily";
import MyBills from "./pages/MyBills";
import Timeline from "./pages/Timeline";
import Vault from "./pages/Vault";

import AddMember from "./components/family/AddMember";

const App = () => {
  return (
        <>

        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgotpassword" element={<Forgotpassword />} />
          <Route path="/changePassword" element={<ChangePassword />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/family" element={<MyFamily />} />
          <Route path="/bills" element={<MyBills />} />
          <Route path="/timeline" element={<Timeline />} />       
           <Route path="/vault" element={<Vault />} />   
          <Route path="/addMember/:editmemberId" element={<AddMember />} />
        </Routes>
      </>


  );
};

export default App;
