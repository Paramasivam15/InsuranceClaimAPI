import {  Routes, Route } from "react-router-dom";
import { Suspense, lazy } from 'react';
import ProtectedRoute from "./components/ProtectedRoute";


import Login from "./pages/Login";
import Register from './pages/Register';
import ChangePassword from './pages/ChangePassword';
import Forgotpassword from './pages/forgotpassword';
import Dashboard from "./pages/Dashboard";
import MyFamily from "./pages/MyFamily";
import MyBills from "./pages/MyBills";
import Timeline from "./pages/Timeline";
import Vault from "./pages/Vault";
import Unauthorized from "./pages/Unauthorized";
import { useAuth } from "./components/authContext";

import AddMember from "./components/family/AddMember";
import AddInsurance from "./components/family/AddInsurance";

//import MemberManagement from "./pages/Admin/MemberManagement";
const MemberManagement = lazy(() => import('./pages/Admin/MemberManagement'));
import UserManagement from "./pages/Admin/UserManagement";
import AdminDashboard from "./pages/Admin/AdminDashboard";
import Reports from "./pages/Admin/Reports";
import Settings from "./pages/Admin/Settings";
import AdminChangePassword from "./pages/Admin/AdminChangePassword";

const App = () => {
      const { canViewDashboard,canViewUserManagement ,canViewMemberPortal,canAccessReports,canAccessSystemSettings} = useAuth();
  return (
    
        <>

        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgotpassword" element={<Forgotpassword />} />
          <Route path="/changePassword" element={<ChangePassword />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/family/:action" element={<MyFamily />} />
          <Route path="/bills" element={<MyBills />} />
           <Route path="/unauthorized" element={<Unauthorized />} />
        
          <Route path="/timeline" element={<Timeline />} />       
           <Route path="/vault" element={<Vault />} />   
          <Route path="/addMember/:editmemberId" element={<AddMember />} />
          <Route path="/insurance/:action/:memberIds/:policyTypes" element={<AddInsurance />} />

          <Route path="/member-portal" 
          element={
            <ProtectedRoute allowedRoles={['Administrator']} permission={canViewMemberPortal}>
              <MemberManagement />
            </ProtectedRoute>
          }
          />
          <Route path="/user-portal" 
          element={
            <ProtectedRoute allowedRoles={['Administrator']} permission={canViewUserManagement}>
              <UserManagement />
            </ProtectedRoute>
          } 
          />
           <Route path="/admin-dashboard" 
           element={
            <ProtectedRoute allowedRoles={['Administrator']} permission={canViewDashboard}>
              <AdminDashboard />
            </ProtectedRoute>
          }
           />
          <Route path="/reports" 
           element={
            <ProtectedRoute allowedRoles={['Administrator']} permission={canAccessReports}>
              <Reports />
            </ProtectedRoute>
          }
          />
          <Route path="/settings" 
            element={
            <ProtectedRoute allowedRoles={['Administrator']} permission={canAccessSystemSettings}>
              <Settings />
            </ProtectedRoute>
          }
          />
          <Route path="/AdminchangePassword" 
          element={
            <ProtectedRoute allowedRoles={['Administrator']}>
              <AdminChangePassword />
            </ProtectedRoute>
          }
          />

        </Routes>
      </>


  );
};

export default App;
