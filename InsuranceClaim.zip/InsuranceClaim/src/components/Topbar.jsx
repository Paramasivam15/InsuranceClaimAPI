import React, { useState } from 'react';
import {
    AppBar,
    Toolbar,
    Typography,
    Box,
    Button,
    IconButton,
    Avatar,
    Menu,
    MenuItem,
    Divider,
    ListItemIcon,
} from '@mui/material';
import {
    Dashboard as DashboardIcon,
    People as PeopleIcon,
    Book as ReportsIcon,
    Settings as SettingsIcon,
    Lock as LockIcon,
} from '@mui/icons-material';
import Logout from '@mui/icons-material/Logout';
import { useNavigate, NavLink } from "react-router-dom";
import { UpdatePasswordLinkShow } from "../services/api";
import { useAuth } from './authContext';
import { getImageBaseUrl } from '../services/api';

export default function Topbar({ title }) {
    const navigate = useNavigate();
    const { user,logout,canViewDashboard,canViewUserManagement,canViewMemberPortal,canAccessReports,canAccessSystemSettings } = useAuth();
    const [anchorEl, setAnchorEl] = useState(null);
     const baseUrl = getImageBaseUrl(user.Profilephoto);
    const [Profilephoto, setProfilephoto] = useState(baseUrl|| null);
    const open = Boolean(anchorEl);

    const links = [
        { name: 'Dashboard', to: '/admin-dashboard', icon: <DashboardIcon />, visible: canViewDashboard },
        { name: 'User Management', to: '/user-portal', icon: <PeopleIcon /> ,visible: canViewUserManagement},
        { name: 'Member Portal', to: '/member-portal', icon: <PeopleIcon />,visible: canViewMemberPortal },
        { name: 'Reports', to: '/reports', icon: <ReportsIcon /> ,visible: canAccessReports},
        { name: 'System Settings', to: '/settings', icon: <SettingsIcon /> ,visible: canAccessSystemSettings }
    ];

     const visibleLinks = links.filter(link => link.visible);

    const navItems = [
        { label: 'Dashboard', href: '/admin-dashboard' },
        { label: 'User Management', href: '/user-portal' },
        { label: 'Member Portal', href: '/member-portal' },
        { label: 'Reports', href: '/reports' },
        { label: 'System Settings', href: '/settings' },
    ];
    const handleMenuOpen = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };
    const handleLogout = () => {
        // Implement your logout logic here (e.g., clear tokens, redirect)
        console.log('Logout clicked');

        try {

            const memberID = user.Mid;
            UpdatePasswordLinkShow(memberID);
            logout();
        } catch (error) {
            console.error('Logout error:', error);
        } finally {

        }
        handleClose();
        navigate("/login");
    };


    return (
        <AppBar position="static" color="inherit" elevation={1}>
            <Toolbar sx={{ justifyContent: 'space-between' }}>
                {/* Left: Logo */}
                <Typography variant="h6" color="primary" sx={{ fontWeight: 'bold' }}>
                    AP Admin
                </Typography>

                {/* Center: Navigation */}
                <Box sx={{ display: 'flex', gap: 4 }}>
                    {visibleLinks.map((link) => (
                        <NavLink
                            key={link.name}
                            to={link.to}
                          
                            style={({ isActive }) => ({
                            color: isActive ? 'blue' : 'gray',
                            fontWeight: isActive ? 'bold' : 'normal',
                            textDecoration: isActive ? 'underline' : 'none',
                            })}
                        >
                            <span className="mr-3">{link.icon}</span>
                            {link.name}
                        </NavLink>
                    ))}
                </Box>

                {/* Right: Avatar + Dropdown */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>

                    <IconButton onClick={handleMenuOpen} sx={{ p: 0 }}>
                        <Avatar src={Profilephoto} alt={user.name } />
                        <Typography>{user.fname} {user.lname}</Typography>
                    </IconButton>
                    <Menu
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleMenuClose}
                        onClick={handleMenuClose}
                        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                    >
                        <MenuItem>My Profile</MenuItem>
                        <MenuItem>Account Settings</MenuItem>
                        <MenuItem>Change Password</MenuItem>
                        <Divider />

                        <MenuItem sx={{ color: 'error.main' }} onClick={handleLogout}>
                            <ListItemIcon>
                                <Logout fontSize="small" color='Red' />
                            </ListItemIcon>
                            Logout
                        </MenuItem>
                    </Menu>
                </Box>
            </Toolbar>
        </AppBar>
    );
}
