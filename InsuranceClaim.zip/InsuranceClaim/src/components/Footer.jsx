import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="fixed bottom-0 w-full bg-white shadow z-50 p-2 flex justify-around">
      
       <div>
      <Link className="items-center justify-center" to="/dashboard"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg><span text-align='center' font-size='.7rem' font-weight='500'>Home</span></Link>
      </div>

       <div>
      <Link  className="items-center justify-center" to="/family"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg><span text-align='center' font-size='.7rem' font-weight='500'>My family</span></Link>  
      </div>

     <div>
      <Link  className="items-center justify-center" to="/bills"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg><span text-align='center' font-size='.7rem' font-weight='500'>My Bills</span></Link>  
      </div>

      <div>
      <Link  className="items-center justify-center" to="/timeline"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg><span text-align='center' font-size='.7rem' font-weight='500'>My Bills</span></Link>  
      </div>
    
    </footer>
  );
}