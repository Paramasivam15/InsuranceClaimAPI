import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="fixed bottom-0 w-full bg-white shadow z-50 p-2 flex justify-around">
      <Link to="/dashboard">🏠</Link>
      <Link to="/family">👪</Link>
      <Link to="/bills">💰</Link>
      <Link to="/timeline">🕒</Link>
    </footer>
  );
}