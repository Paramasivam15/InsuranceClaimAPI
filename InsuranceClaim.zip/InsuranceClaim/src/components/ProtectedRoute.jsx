import { Navigate } from 'react-router-dom';
import { useAuth } from './authContext';

export default function ProtectedRoute({ children, allowedRoles }) {
  const { user } = useAuth();


  if (user== null || !user.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/member-portal" replace />;
  }

  return children;
}
