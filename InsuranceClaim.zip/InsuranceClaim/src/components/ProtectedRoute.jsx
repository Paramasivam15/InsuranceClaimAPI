import { Navigate } from 'react-router-dom';
import { useAuth } from './authContext';
import Unauthorized from '../pages/Unauthorized';

export default function ProtectedRoute({permission, children, allowedRoles,fallback = null }) {
  const { user } = useAuth();
   
  if (user== null || !user.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/member-portal" replace />;
  }

   let hasPermission = true; 
    if (permission !== undefined) {
    // If permission is a function
    if (typeof permission === 'function') {
      hasPermission = permission(user.rolePermission);
    } else {
      // If permission is just a boolean flag
      hasPermission = Boolean(permission);
    }
  }

   if (!hasPermission) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
}
