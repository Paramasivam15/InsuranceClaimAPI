import React, { useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Paper,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';

const initialRoles = [
  { id: 'admin', name: 'Administrator', active: true },
  { id: 'manager', name: 'Manager', active: true },
  { id: 'reviewer', name: 'Reviewer', active: false },
];

const permissionsByCategory = {
  'Core Modules': [
    { id: 'view_dashboard', label: 'View Dashboard' },
    { id: 'view_member_portal', label: 'View Member Portal' },
    { id: 'view_user_mgmt', label: 'View User Management' },
  ],
  'Reports': [
    { id: 'access_reports', label: 'Access Reports Module' },
    { id: 'gen_bill_review', label: 'Generate Bill Review Reports' },
    { id: 'gen_complex_reports', label: 'Generate Complex Case Reports' },
  ],
  'Settings': [
    { id: 'access_system_settings', label: 'Access System Settings' },
    { id: 'access_role_mgmt', label: 'Access Role Management (Admin only)', disabled: true },
  ],
};

export default function RolePermission() {
  const [roles, setRoles] = useState(initialRoles);
  const [selectedRole, setSelectedRole] = useState(roles[0].id);
  const [permissions, setPermissions] = useState({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState('add');
  const [roleNameInput, setRoleNameInput] = useState('');
  const [confirmDelete, setConfirmDelete] = useState({ open: false, roleId: null });

  const openAddDialog = () => {
    setDialogMode('add');
    setRoleNameInput('');
    setIsDialogOpen(true);
  };

  const openEditDialog = (role) => {
    setDialogMode('edit');
    setRoleNameInput(role.name);
    setSelectedRole(role.id);
    setIsDialogOpen(true);
  };

  const handleDialogSave = () => {
    if (dialogMode === 'add') {
      const newRole = { id: roleNameInput.toLowerCase(), name: roleNameInput, active: true };
      setRoles((prev) => [...prev, newRole]);
      setSelectedRole(newRole.id);
    } else {
      setRoles((prev) =>
        prev.map((r) => (r.id === selectedRole ? { ...r, name: roleNameInput } : r))
      );
    }
    setIsDialogOpen(false);
  };

  const requestDeleteRole = (roleId) => {
    setConfirmDelete({ open: true, roleId });
  };

  const confirmDeletion = () => {
    setRoles((prev) => prev.filter((r) => r.id !== confirmDelete.roleId));
    setConfirmDelete({ open: false, roleId: null });
    if (selectedRole === confirmDelete.roleId && roles.length > 1) {
      setSelectedRole(roles[0].id);
    }
  };

  const handleToggle = (permId) => {
    setPermissions((prev) => ({ ...prev, [permId]: !prev[permId] }));
  };

  const handleSave = () => {
    console.log('Saving permissions for', selectedRole, permissions);
    // Integrate API calls here
  };

  return (
    <Box p={3}>
      
      <Box display="flex" gap={3}>
        {/* Sidebar */}
        <Paper variant="outlined" sx={{ width: '25%', p: 2 }}>
          <Box display="flex" justifyContent="space-between" mb={2}>
            <Typography variant="h6">User Roles</Typography>
            <Button variant="contained" onClick={openAddDialog}>
              Add Role
            </Button>
          </Box>
          <List>
            {roles.map((role) => (
              <ListItem
                key={role.id}
                selected={selectedRole === role.id}
                sx={{ cursor: 'pointer' }}
                onClick={() => setSelectedRole(role.id)}
                secondaryAction={
                  <>
                    <IconButton edge="end" onClick={() => openEditDialog(role)}>
                      <EditIcon />
                    </IconButton>
                    <IconButton edge="end" onClick={() => requestDeleteRole(role.id)}>
                      <DeleteIcon />
                    </IconButton>
                  </>
                }
              >
                <ListItemText
                  primary={role.name}
                  secondary={role.active ? 'Active' : 'Inactive'}
                />
              </ListItem>
            ))}
          </List>
        </Paper>

        {/* Permissions Panel */}
        <Paper variant="outlined" sx={{ flex: 1, p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box mb={2}>
            <Typography variant="h6">
              Set Page Access for:{' '}
              <Typography component="span" fontWeight="bold">
                {roles.find((r) => r.id === selectedRole)?.name}
              </Typography>
            </Typography>
          </Box>
          <Box flex={1} overflow="auto">
            {Object.entries(permissionsByCategory).map(([category, perms]) => (
              <Box key={category} mb={2}>
                <Typography variant="subtitle1">{category}</Typography>
                <Box ml={2}>
                  {perms.map((perm) => (
                    <FormControlLabel
                      key={perm.id}
                      control={
                        <Checkbox
                          checked={!!permissions[perm.id]}
                          onChange={() => !perm.disabled && handleToggle(perm.id)}
                          disabled={perm.disabled}
                        />
                      }
                      label={perm.label}
                    />
                  ))}
                </Box>
              </Box>
            ))}
          </Box>
          <Box textAlign="right" mt={2}>
            <Button variant="contained" onClick={handleSave}>
              Save Permissions
            </Button>
          </Box>
        </Paper>
      </Box>

      {/* Add/Edit Role Dialog */}
      <Dialog open={isDialogOpen} onClose={() => setIsDialogOpen(false)}>
        <DialogTitle>{dialogMode === 'add' ? 'Add New Role' : 'Edit Role'}</DialogTitle>
        <DialogContent>
          <Text
            field
            label="Role Name"
            fullWidth
            variant="outlined"
            margin="dense"
            value={roleNameInput}
            onChange={(e) => setRoleNameInput(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleDialogSave}>
            {dialogMode === 'add' ? 'Add' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={confirmDelete.open}
        onClose={() => setConfirmDelete({ open: false, roleId: null })}
      >
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this role?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete({ open: false, roleId: null })}>
            Cancel
          </Button>
          <Button color="error" variant="contained" onClick={confirmDeletion}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
