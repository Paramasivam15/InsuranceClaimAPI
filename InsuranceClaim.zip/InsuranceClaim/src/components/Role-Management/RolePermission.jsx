import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Paper,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { GetUserRole ,SaveRole,SaveRolePermission,GetRolePermissionByRoleId} from '../../services/api';
import { ClipLoader } from 'react-spinners'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { FiEdit2 } from 'react-icons/fi';
import { set } from 'react-hook-form';

/*
const initialRoles = [
  { id: 17, type: 'Administrator', isActive: true },
  { id: 18, type: 'Manager', isActive: true },
  { id: 19, type: 'Reviewer', isActive: false },
];
*/


/*
const permissionsByCategory = {
  'Core Modules': [
    {  Id:1,Permissionid: 32, label: 'View Dashboard',IsActive:true },
    { Id:2,Permissionid: 33, label: 'View Member Portal',IsActive:true },
    { Id:3,Permissionid: 34, label: 'View User Management',IsActive:true },
  ],
  'Reports': [
    { Id:4,Permissionid: 35, label: 'Access Reports Module' ,IsActive:true},
    { Id:5,Permissionid: 36, label: 'Generate Bill Review Reports' ,IsActive:true},
    { Id:6,Permissionid: 37, label: 'Generate Complex Case Reports',IsActive:true },
  ],
  'Settings': [
    { Id:7,Permissionid: 38, label: 'Access System Settings',IsActive:true },
    { Id:8,Permissionid: 39, label: 'Access Role Management',IsActive:true },
  ],
};
*/

export default function RolePermission() {

  const [message, setmessage] = useState(null);
  const [status, setstatus] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const [roles, setRoles] = useState([]);
  const [selectedRole, setSelectedRole] = useState(0);
  const [currentRole, setcurrentRole] = useState({});
 const [permissions, setPermissions] = useState({});
 const [adminRoleId, setadminRoleId] = useState(0);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState('add');
  const [confirmDelete, setConfirmDelete] = useState({ open: false, roleId: null });

  const [permissionsByCategory, setPermissionsByCategory] = useState({
  'Core Modules': [
    { Id: 1, Permissionid: 32, label: 'View Dashboard', IsActive: true },
    { Id: 2, Permissionid: 33, label: 'View Member Portal', IsActive: true },
    { Id: 3, Permissionid: 34, label: 'View User Management', IsActive: true },
  ],
  'Reports': [
    { Id: 4, Permissionid: 35, label: 'Access Reports Module', IsActive: true },
    { Id: 5, Permissionid: 36, label: 'Generate Bill Review Reports', IsActive: true },
    { Id: 6, Permissionid: 37, label: 'Generate Complex Case Reports', IsActive: true },
  ],
  'Settings': [
    { Id: 7, Permissionid: 38, label: 'Access System Settings', IsActive: true },
    { Id: 8, Permissionid: 39, label: 'Access Role Management', IsActive: true },
  ],
});

  const [id, setid] = useState(0);
  const [type, settype] = useState('');
  const [isActive, setisActive] = useState(true);


  useEffect(() => {
    async function fetchRoles() {

      const res = await GetUserRole();
      setRoles(res);
      if (res.length > 0) {
        if(selectedRole===0)
        {
        setSelectedRole(res[0].id);
        setadminRoleId(res.find(r => r.type === 'Administrator')?.id || 0);
        setcurrentRole(res[0]);
        fetchRolePermissions(res[0].id);
        }
      }
      console.log("Roles from API", res);
    }
    fetchRoles();
  }, []);
  
  async function fetchRolePermissions(roleId) {
     const res = await GetRolePermissionByRoleId(roleId);
     setPermissions(res);
     console.log("Permissions for role", roleId, res);
  }

  const openAddDialog = () => {
    setDialogMode('add');
    settype('');
    setid(0);
    setisActive(true);
    setSelectedRole(0);
    console.log("Add new role");
    setIsDialogOpen(true);
  };

  const openEditDialog = (role) => {
    setDialogMode('edit');
    setcurrentRole(role);
    console.log("Edit role", role);
    settype(role.type);
    setid(role.id);
    setisActive(role.isActive);
    console.log("Edit role id", role.id);
    setSelectedRole(role.id);
    setIsDialogOpen(true);
  };

  const handleDialogSaveRole =async () => {
    
    //Call API to save role   
    console.log("Role to save", id, type, isActive);
    setIsLoading(true); // Show loader
    const res = await SaveRole(id, type, isActive);
    console.log("Save role response", res);
    if (res != null) {
      console.log("Saved role id", res.id);
      setid(res.id);
      setstatus(res.status);
      setmessage(res.message);
      if (res.status === 'Success')
        toast.success(res.message);
      else
        toast.error(res.message);     
      setSelectedRole(res.id);
      setcurrentRole(res.roles.find(r => r.id === res.id) || {});
      setRoles(res.roles);
      fetchRolePermissions(res.id);
      setIsLoading(false); // Hide loader      
    }
    setIsDialogOpen(false);
  };

  const handleSelectedRole = (role) => {
    setSelectedRole(role.id)
    setcurrentRole(role);
    console.log("Selected role", role);
     fetchRolePermissions(role.id);
  };

  const requestDeleteRole = (roleId) => {
    setConfirmDelete({ open: true, roleId });
  };

  const confirmDeletion = () => {
    setRoles((prev) => prev.filter((r) => r.id !== confirmDelete.roleId));
    setConfirmDelete({ open: false, roleId: null });
    if (selectedRole === confirmDelete.roleId && roles.length > 1) {
      setSelectedRole(roles[0].id);
    }
  };

  const handleToggle = (permissionId) => {
  //  setPermissions((prev) => ({ ...prev, [permId]: !prev[permId] }));
 // Deep clone the state to avoid mutation
  const updated = Object.fromEntries(
    Object.entries(permissionsByCategory).map(([category, perms]) => [
      category,
      perms.map((perm) =>
        perm.Permissionid === permissionId
          ? { ...perm, IsActive: !perm.IsActive }
          : perm
      ),
    ])
  );

  setPermissionsByCategory(updated);
  };
    const handleChange = (key) => {
    setPermissions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setIsLoading(true); // Show loader
    console.log('Saving permissions for', selectedRole, permissions);
    const res = await SaveRolePermission(permissions);
    console.log("Save permissions response", res);
    setPermissions(res);
    setstatus(res.status);
    setmessage(res.message);
    if (res.status === 'Success')
      toast.success(res.message);
    else
      toast.error(res.message);
    setIsLoading(false); // hide loader
  };

  return (
     <div>
    <Box display="flex"   >
      <Box gap={3} flex={1} height="auto">

        <div className="w-[360px] bg-white p-6 rounded-2xl shadow-lg font-sans">
          {/* Header */}
          <div className="flex justify-between items-center mb-4 ">
            <h3 className="text-lg font-semibold text-gray-800">User Roles</h3>
            <button className="bg-indigo-600  hover:bg-indigo-500  text-white text-sm px-4 py-2 rounded-lg shadow" onClick={openAddDialog}>
              + Add Role
            </button>
          </div>

          {/* Role Cards */}
          {roles.map((role, index) => {
            return (
              <div
                key={index}
                className={`
              flex items-center justify-between px-4 py-3 mb-3 rounded-xl transition-all
              border border-gray-300 bg-gray-50
              hover:border-violet-500 hover:bg-violet-50
              cursor-pointer
            `}
                onClick={() => handleSelectedRole(role)}
              >
                <span
                  className={`text-sm font-medium`}
                >
                  {role.type}
                </span>

                <span
                  className={`text-xs px-2 py-1 rounded-full font-medium
                ${role.isActive
                      ? 'bg-green-100 text-green-600'
                      : 'bg-red-100 text-red-500'}
              `}
                >
                  {role.isActive ? 'Active' : 'Inactive'}
                </span>

                <FiEdit2 className="text-violet-600 text-lg cursor-pointer" onClick={() => openEditDialog(role)} />
              </div>
            );
          })}
        </div>
      </Box>
      <Box flex={4} height="auto">
         <form className="space-y-6" onSubmit={handleSave}>
     
        {/* Permissions Panel */}
       <div className="bg-white p-6 rounded shadow flex-1">
      <h2 className="text-lg font-bold mb-6">Set Page Access for:  {roles.find((r) => r.id === selectedRole)?.type}</h2>

      {/* Core Modules */}
      <div className="mb-6">
        <h3 className="font-semibold text-gray-700 mb-2">Core Modules</h3>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isViewDashboard || false} onChange={() => handleChange('isViewDashboard')} />
          <span>View Dashboard</span>
        </label>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isViewMemberPotal || false} onChange={() => handleChange('isViewMemberPotal')} />
          <span>View Member Portal</span>
        </label>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isViewUserManagement || false} onChange={() => handleChange('isViewUserManagement')} />
          <span>View User Management</span>
        </label>
      </div>

      {/* Reports */}
      <div className="mb-6">
        <h3 className="font-semibold text-gray-700 mb-2">Reports</h3>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isAccessReport || false} onChange={() => handleChange('isAccessReport')} />
          <span>Access Reports Module</span>
        </label>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isGeneateBillReview || false} onChange={() => handleChange('isGeneateBillReview')} />
          <span>Generate Bill Review Reports</span>
        </label>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isGenerateComplexCaseReports || false} onChange={() => handleChange('isGenerateComplexCaseReports')} />
          <span>Generate Complex Case Reports</span>
        </label>
      </div>

      {/* Settings */}
      <div className="mb-6">
        <h3 className="font-semibold text-gray-700 mb-2">Settings</h3>
        <label className="flex items-center space-x-2 mb-2">
          <input type="checkbox" checked={permissions.isAccessSystemSettings || false} onChange={() => handleChange('isAccessSystemSettings')} />
          <span>Access System Settings</span>
        </label>
        <label className="flex items-center space-x-2 mb-2 text-gray-400">
          <input type="checkbox" checked={permissions.isAccessRoleManagement || false} onChange={() => handleChange('isAccessRoleManagement')} style={{visibility: permissions.roleId != adminRoleId  ? 'hidden' : 'visible' }} />
          <span style={{visibility: permissions.roleId != adminRoleId  ? 'hidden' : 'visible' }} >🔒 Access Role Management</span>
        </label>
      </div>

      <button
         type="submit"       
        className="mt-4 bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded"
      >
       Save Permissions
      </button>
    </div>
       </form>
      </Box>


      {/* Add/Edit Role Dialog */}
      <Dialog open={isDialogOpen} onClose={() => setIsDialogOpen(false)}>
        <DialogTitle>{dialogMode === 'add' ? 'Add New Role' : 'Edit Role'}</DialogTitle>
        <DialogContent>
          <div>
            <label htmlFor="rolename" className="block text-sm/6 font-medium text-gray-900">
              Role Name
            </label>
            <div className="mt-2">
              <input
                id="rolename"
                name="rolename"
                type="text"
                value={type}
                required
                onChange={(e) => settype(e.target.value)}
                className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
              />
            </div>
          </div>

          <div>
            <label htmlFor="genter" className="block text-sm/6 font-medium text-gray-900">
              Status
            </label>
            <div className="mt-2">
              <select
                value={isActive}
                onChange={e => setisActive(e.target.value === 'true')}
                className="border rounded px-2 py-1"
                disabled={dialogMode === 'add'}
              >
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>           
          </div>
        
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setIsDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleDialogSaveRole}>
            Save Role
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={confirmDelete.open}
        onClose={() => setConfirmDelete({ open: false, roleId: null })}
      >
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this role?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete({ open: false, roleId: null })}>
            Cancel
          </Button>
          <Button color="error" variant="contained" onClick={confirmDeletion}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
      
  
    </Box>
       <div className="mb-6 text-center">
        {isLoading ? (
          <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
        ) : null}
      </div>
        <ToastContainer />
    </div>
  );
}
