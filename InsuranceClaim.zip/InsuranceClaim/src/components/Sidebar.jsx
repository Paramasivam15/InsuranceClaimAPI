import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  Book as ReportsIcon,
  Settings as SettingsIcon,
  Lock as LockIcon,
} from '@mui/icons-material';

const links = [
  { name: 'Dashboard', to: '/admin-dashboard', icon: <DashboardIcon /> },
  { name: 'User Management', to: '/user-portal', icon: <PeopleIcon /> },
  { name: 'Member Portal', to: '/member-portal', icon: <PeopleIcon /> },
  { name: 'Reports', to: '/reports', icon: <ReportsIcon /> },
  { name: 'System Settings', to: '/settings', icon: <SettingsIcon /> },
  { name: 'Change Password', to: '/AdminchangePassword', icon: <LockIcon /> },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white ">
      <div className="p-6 font-bold text-xl">AP Admin</div>
      <nav className="flex flex-col space-y-2">
        {links.map((link) => (
          <NavLink
            key={link.name}
            to={link.to}
            className={({ isActive }) =>
              `flex items-center px-6 py-3 text-gray-700 hover:bg-gray-200 ${
                isActive ? 'bg-purple-50 font-medium' : ''
              }`
            }
          >
            <span className="mr-3">{link.icon}</span>
            {link.name}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
