import React from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

export default function Layout({ children,title  }) {
  return (
    <div className="flex h-screen">    
      <div className="flex-1 flex flex-col bg-purple-50">
        <Topbar title={title}  />
        <main className="p-6 bg-purple-50 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
