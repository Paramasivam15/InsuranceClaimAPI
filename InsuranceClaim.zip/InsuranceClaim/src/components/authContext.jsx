import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  /*
  const [user, setUser] = useState({
    isAuthenticated: true,
    role: 'admin', // 'user' or 'admin'
  });
  */

   const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('authUser');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const login = (userData) => {
    console.log("Auth User called",userData);
    localStorage.setItem('authUser', JSON.stringify(userData));
    setUser(userData);
  };

    const logout = () => {
    console.log("Auth User logged out");
    localStorage.removeItem('authUser');
    setUser(null);
  };


  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
