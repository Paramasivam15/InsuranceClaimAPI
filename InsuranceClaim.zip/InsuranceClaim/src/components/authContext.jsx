import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  /*
  const [user, setUser] = useState({
    isAuthenticated: true,
    role: 'admin', // 'user' or 'admin'
  });
  */

  const defaultPermissions = {
  isViewDashboard: false,
  isViewMemberPotal: false,
  isViewUserManagement: false,
  isAccessReport: false,
  isGeneateBillReview: false,
  isGenerateComplexCaseReports: false,
  isAccessSystemSettings: false,
  isAccessRoleManagement: false,
};

   const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('authUser');
    return savedUser ? JSON.parse(savedUser) : null;
  });

    const rolePermission = user?.rolePermission ?? defaultPermissions;

  const canViewDashboard = Boolean(rolePermission.isViewDashboard);
  const canViewMemberPortal = Boolean(rolePermission.isViewMemberPotal);
  const canViewUserManagement = Boolean(rolePermission.isViewUserManagement);
  const canAccessReports = Boolean(rolePermission.isAccessReport);
  const canGenerateBillReview = Boolean(rolePermission.isGeneateBillReview);
  const canGenerateComplexCaseReports = Boolean(rolePermission.isGenerateComplexCaseReports);
  const canAccessSystemSettings = Boolean(rolePermission.isAccessSystemSettings);
  const canAccessRoleManagement = Boolean(rolePermission.isAccessRoleManagement);

  const login = (userData) => {
    console.log("Auth User called",userData);
    localStorage.setItem('authUser', JSON.stringify(userData));
    setUser(userData);
  };

    const logout = () => {
    console.log("Auth User logged out");
    localStorage.removeItem('authUser');
    setUser(null);
  };


  return (
    <AuthContext.Provider value={{ user, login, logout,
        rolePermission,
        canViewDashboard,
        canViewMemberPortal,
        canViewUserManagement,
        canAccessReports,
        canGenerateBillReview,
        canGenerateComplexCaseReports,
        canAccessSystemSettings,
        canAccessRoleManagement
     }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
