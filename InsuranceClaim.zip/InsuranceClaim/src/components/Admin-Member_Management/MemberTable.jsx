import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableRow, IconButton, Tooltip } from '@mui/material';

export default function MemberTable({ data }) {
  return (
    <div className="bg-white rounded shadow overflow-auto">
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Family ID</TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Mobile #</TableCell>
            <TableCell># of Members</TableCell>
            <TableCell># of Bill Reviews</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row) => (
            <TableRow key={row.familyId}>
              <TableCell>{row.familyId}</TableCell>
              <TableCell>{row.name}</TableCell>
              <TableCell>{row.mobile}</TableCell>
              <TableCell>
                {row.memberCount}
                <Tooltip title=" ?" arrow>
                  <IconButton size="small">i</IconButton>
                </Tooltip>
              </TableCell>
              <TableCell>{row.billReviews}</TableCell>
              <TableCell align="right" className="space-x-2">
                <ButtonLink to={`/insurance/edit/${row.familyId}/...`}>
                  Insurance
                </ButtonLink>
                <ButtonLink to={`/vault`}>Vault</ButtonLink>
                <ButtonLink to={`/ledger`}>Ledger</ButtonLink>
                <ButtonLink to={`/billreview`}>Bill Review</ButtonLink>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function ButtonLink({ to, children }) {
  return (
    <Tooltip title={children} arrow>
      <span className="text-blue-600 cursor-pointer hover:underline">{children}</span>
    </Tooltip>
  );
}
