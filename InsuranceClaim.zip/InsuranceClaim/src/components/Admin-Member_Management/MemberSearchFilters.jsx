import React from 'react';
import { TextField, Button } from '@mui/material';

export default function MemberSearchFilters({ onSearch }) {
  return (
    <div className="bg-white p-4 mb-4 rounded shadow">
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <TextField label="Search by Name" name="name" size="small" />
        <TextField label="Search by Family ID" name="familyId" size="small" />
        <TextField label="Search by Mobile #" name="mobile" size="small" />
        <TextField
          label="Date From"
          name="dateFrom"
          type="date"
          size="small"
          InputLabelProps={{ shrink: true }}
        />
        <TextField
          label="Date To"
          name="dateTo"
          type="date"
          size="small"
          InputLabelProps={{ shrink: true }}
        />
        <Button variant="contained" color="primary" onClick={onSearch}>
          Apply
        </Button>
      </div>
    </div>
  );
}
