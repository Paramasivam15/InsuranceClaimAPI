import React, { useState } from 'react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import { useNavigate  } from "react-router-dom";
import { UpdatePasswordLinkShow } from "../services/api";
import { useAuth } from './authContext';

export default function Header({ title }) {
  const { user,logout } = useAuth();
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const[Profilephoto, setProfilephoto]=useState(localStorage.getItem("profilephoto")||null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChangePassword = () => {
    // Implement your change password logic here
    console.log('Change Password clicked');
     navigate("/changePassword");
    handleClose();
  };

  const handleLogout = () => {
    // Implement your logout logic here (e.g., clear tokens, redirect)
    console.log('Logout clicked');

    try {

       const userID = user.LoginUserId; 
       UpdatePasswordLinkShow(userID);
       logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {

    }    
    handleClose();
     navigate("/login");
  };
  return (
    <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
        <div className="flex items-center">
    <img
      src="https://www.clipartmax.com/png/middle/54-546012_health-care-healthcare-png-icon.png" // Replace with your actual image path
      alt="Healthcare Logo"
      className="h-10 w-auto" // Adjust height/width as needed
    />
  </div>
      <h1 className="text-xl font-semibold text-center flex-grow text-center">{title}</h1>
      <div className="flex space-x-4 items-center">
        <span>🔔</span>
        <div className="relative group">
        
           <div>
      <Button
        aria-controls={open ? 'user-settings-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
       
      >
         <Avatar alt="User Avatar" src={Profilephoto} />    
      </Button>
      <Menu
        id="user-settings-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'user-settings-button',
        }}
      >
        <MenuItem onClick={handleChangePassword}>Change Password</MenuItem>
        <MenuItem onClick={handleLogout}>Logout</MenuItem>
      </Menu>
    </div>
        </div>
      </div>
    </header>
  );
}   
