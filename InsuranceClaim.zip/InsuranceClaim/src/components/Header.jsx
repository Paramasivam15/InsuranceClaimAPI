import React, { useState } from 'react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import { useNavigate  } from "react-router-dom";


export default function Header({ title }) {
 const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleChangePassword = () => {
    // Implement your change password logic here
    console.log('Change Password clicked');
     navigate("/changePassword");
    handleClose();
  };

  const handleLogout = () => {
    // Implement your logout logic here (e.g., clear tokens, redirect)
    console.log('Logout clicked');
    try {
      localStorage.removeItem('token');
      localStorage.removeItem('fname');
      localStorage.removeItem('lname');
      localStorage.removeItem('email');
      localStorage.removeItem('uid');
      localStorage.removeItem('Mid');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {

    }    
    handleClose();
     navigate("/login");
  };
  return (
    <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
      <div></div>
      <h1 className="text-xl font-semibold text-center flex-grow text-center">{title}</h1>
      <div className="flex space-x-4 items-center">
        <span>🔔</span>
        <div className="relative group">
        
           <div>
      <Button
        aria-controls={open ? 'user-settings-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
       
      >
         <Avatar alt="User Avatar" src="https://i.pravatar.cc/150?u=alexgreen" />   
      </Button>
      <Menu
        id="user-settings-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'user-settings-button',
        }}
      >
        <MenuItem onClick={handleChangePassword}>Change Password</MenuItem>
        <MenuItem onClick={handleLogout}>Logout</MenuItem>
      </Menu>
    </div>
        </div>
      </div>
    </header>
  );
}   
