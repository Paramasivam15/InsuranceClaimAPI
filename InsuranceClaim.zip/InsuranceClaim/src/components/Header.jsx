export default function Header({ title }) {
  return (
    <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
      <div></div>
      <h1 className="text-xl font-semibold text-center flex-grow text-center">{title}</h1>
      <div className="flex space-x-4 items-center">
        <span>🔔</span>
        <div className="relative group">
          <span>👤</span>
          <div className="absolute hidden group-hover:block right-0 bg-white border mt-2">
            <a href="/settings" className="block p-2 hover:bg-gray-100">Settings</a>
            <a href="/" className="block p-2 hover:bg-gray-100">Logout</a>
          </div>
        </div>
      </div>
    </header>
  );
}   
