import React from 'react';
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa";
import { DeleteMemeberInsurance } from '../../services/api';
import { FaShieldAlt, FaUser } from 'react-icons/fa';
import { MdDateRange } from 'react-icons/md';
import { BsCheckCircle } from 'react-icons/bs';
import { FiEdit2, FiTrash2 } from 'react-icons/fi';
import ConfirmationDialog from '../ConfirmationDialog';
import '../ConfirmationDialog.css';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from '../authContext';


const Insurance = ({ Memberinsurance, memberId, onNotifyFamilyGroup }) => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [showConfirmation, setShowConfirmation] = useState(false);
    const [message, setmessage] = useState(null);
    const [status, setstatus] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [deleteMemInsId, setdeleteMemInsId] = useState(0);

    const onNotify = (validationmessage) => {

        console.log("Notify Parent", validationmessage);
        onNotifyFamilyGroup(validationmessage);
    };

    const navigateToAddInsurance = (policyType) => {
        navigate("/insurance/add/" + memberId + "/" + policyType);
    };

    const handleConfirm = async () => {
        // Perform the actual delete operation here
        console.log('Item deleted!');
        setIsLoading(true); // Show loader         
        setShowConfirmation(false); // Hide the confirmation dialog       
        const memberId = user.Mid;//localStorage.getItem("Mid");
        console.log("deleteMemInsId", deleteMemInsId);
        console.log("memId", memberId);
        const res = await DeleteMemeberInsurance(deleteMemInsId, memberId);
        console.log(res);

        setstatus(res.status);
        setmessage(res.message);
        if (res.status === 'Success') {

            console.log(res.message);
            //  toast.success(res.message);               
            setIsLoading(false); // Hide loader
            onNotify(res.message);
        }
        else {
            //    toast.error(res.message);  
            setIsLoading(false); // Hide loader
            onNotify(res.message);
        };


    };

    const handleCancel = () => {
        console.log('Delete operation cancelled.');
        setShowConfirmation(false); // Hide the confirmation dialog
        setdeleteMemInsId(0); // Reset delete ID
    };


    const handleDeleteClick = (param) => {
        console.log("delete event", param);
        setdeleteMemInsId(param)
        setShowConfirmation(true); // Show the confirmation dialog
    }

    useEffect(() => {
        if (Memberinsurance != null && Memberinsurance.length > 0) {
            console.log("ParaminsuranceData", Memberinsurance);
        }

    }, [Memberinsurance]);

    return (

        <div className="p-2 max-w-full-7xl mx-auto">

            <div>

                {Memberinsurance != null && Memberinsurance.map((ins) => (
                    <div key={ins.id} className="max mx-auto ">
                       


                        <div className="bg-white rounded-2xl   p-1  ">
                            {/* Edit and Delete Icons */}

                            <header className="top-0 w-full bg-white  z-50 p-4 flex ">
                                <h1 className="text-xl font-semibold  flex-grow ">{ins.benefitType}</h1>
                                <div className="flex space-x-4 items-center">
                                    <div>
                                        <Link className="items-center justify-center" to={`/insurance/edit/${ins.memInsID}/${ins.policyType}`}><svg width='24px' height='24px' stroke-width='2' fill='none' stroke='currentColor' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></Link>
                                    </div>
                                    <div>
                                        <Link className="items-center justify-center" onClick={() => handleDeleteClick(ins.memInsID)}  ><svg width='24px' height='24px' stroke-width='2' fill='none' stroke='currentColor' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></Link>
                                    </div>

                                </div>
                            </header>

                            {/* Images */}
                            <div className="grid grid-cols-2 gap-2 mb-4">
                                <div className="flex flex-col items-center">
                                    <img
                                        src={ins.insFrontImgURL}
                                        alt="Front"
                                        className="w-full h-32 object-contain rounded-md bg-blue-100 border"
                                    />
                                    <span className="text-xs mt-1 text-gray-600">Front</span>
                                </div>
                                <div className="flex flex-col items-center">
                                    <img
                                        src={ins.insBackImgURL}
                                        alt="Back"
                                        className="w-full h-32 object-contain rounded-md bg-blue-100 border"
                                    />
                                    <span className="text-xs mt-1 text-gray-600">Back</span>
                                </div>
                            </div>

                            {/* Info Section */}
                            <div className="grid grid-cols-2 gap-4 text-sm text-gray-700">
                                <div className="flex items-center gap-2">
                                    <svg width='18px' height='18px' stroke-width='2' fill='none' stroke='Blue' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                                    <span>Status</span>
                                </div>
                                <div className="text-right font-medium">
                                    <span>{ins.status}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <svg width='18px' height='18px' stroke-width='2' fill='none' stroke='Blue' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2z"></path></svg>
                                    <span>From/To Date</span>
                                </div>
                                <div className="text-right font-medium">

                                    <span> {ins.strActiveDateFromTo}</span>
                                </div>
                                {ins.status !== 'Inactive' && (
                                    <>
                                        <div className="flex items-center gap-2">
                                            <svg width='18px' height='18px' stroke-width='2' fill='none' stroke='Blue' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                            <span>Validated On</span>
                                        </div>
                                        <div className="text-right font-medium">

                                            <span>{ins.eligibilityChkDate}</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <svg width='18px' height='18px' stroke-width='2' fill='none' stroke='Blue' stroke-linejoin='round' stroke-linecap='round' viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                            <span>Subscriber</span>
                                        </div>
                                        <div className="text-right font-medium">

                                            <span>{ins.subscriberName}</span>
                                        </div>
                                    </>
                                )}
                            </div>

                        </div>


                    </div>
                ))
                }
                {showConfirmation && (
                    <ConfirmationDialog
                        message="Are you sure you want to delete this item?"
                        onConfirm={handleConfirm}
                        onCancel={handleCancel}
                    />
                )}
                <ToastContainer />

            </div>
        </div>


    );
};

export default Insurance;