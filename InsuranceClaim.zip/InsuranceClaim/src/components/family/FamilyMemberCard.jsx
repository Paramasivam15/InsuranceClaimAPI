import { FaEdit, FaTrash, FaShieldAlt, FaLock } from 'react-icons/fa';
import { Link } from "react-router-dom";

const FamilyMemberCard = ({ name, relation, imageUrl }) => {
  return (
    <div className="bg-white border shadow-sm p-4 rounded-md flex items-center space-x-4 w-full">
      {/* Left: Profile Image */}
      <img
        src={imageUrl || 'https://via.placeholder.com/60'}
        alt={name}
        className="w-16 h-16 rounded-full object-cover border"
      />

      {/* Right: Name, Relation, Icons */}
      <div className="flex flex-col justify-between flex-grow">
        {/* Name and Relation */}
        <div>
          <h3 className="text-lg font-semibold">{name}</h3>
          <p className="text-gray-600">{relation}</p>
        </div>

        {/* Action Icons */}
        {/* <div className="flex space-x-6 mt-3 text-blue-600 text-lg">*/}
         <footer className="bottom-0 w-full bg-white z-50 p-2 flex justify-around">
          <FaEdit title="Edit" className="cursor-pointer hover:text-blue-800" />
          <FaTrash title="Delete" className="cursor-pointer hover:text-red-600" />
          <FaShieldAlt title="Insurance" className="cursor-pointer hover:text-green-600" />
          <FaLock title="Vault" className="cursor-pointer hover:text-purple-600" />
          </footer>
       {/* </div> */}
      </div>
    </div>
  );
};

export default FamilyMemberCard;