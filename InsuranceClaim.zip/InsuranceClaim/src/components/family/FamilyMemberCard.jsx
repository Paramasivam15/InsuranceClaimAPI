import { FaEdit, FaTrash, FaShieldAlt, FaLock } from 'react-icons/fa';
import { Link } from "react-router-dom";
import ConfirmationDialog from '../ConfirmationDialog';
import  '../ConfirmationDialog.css';
import { useState,useEffect } from "react";
import { ClipLoader } from 'react-spinners'
import { DeleteMemeber } from '../../services/api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Avatar from '@mui/material/Avatar';
import { useAuth } from '../authContext';
const FamilyMemberCard = ({ member,name, relation, imageUrl,onNotify  }) => {

    const { user } = useAuth();
    const [message, setmessage] = useState(null);
    const [status, setstatus] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
  

   const [showConfirmation, setShowConfirmation] = useState(false);
   console.log("key",member);

   const handleDeleteClick = () => {
 
     const loginMemberId = user.Mid;//localStorage.getItem("Mid");
    if(relation != "Self" & loginMemberId!=member)
    setShowConfirmation(true); // Show the confirmation dialog
  
  }

   const notifyParent = () => {
    
    //console.log("Notify Parent");
    onNotify('Call_From_FamilyMemberCard');
  };

  const handleConfirm = async () => {
    // Perform the actual delete operation here
    console.log('Item deleted!');
   // setActionMessage('Item successfully deleted!');
      setIsLoading(true); // Show loader  
     console.log("deleted memeber",member);
      setShowConfirmation(false); // Hide the confirmation dialog
     
     const res = await DeleteMemeber(member);
     console.log(res);
      
        setstatus(res.status);
        setmessage(res.message);
           if (res.status==='Success') 
           {
              notifyParent();
             console.log(res.message);
               toast.success(res.message);   
          //  onChange('true');  
           setIsLoading(false); // Hide loader
           }
           else
           {
               toast.error(res.message);  
              setIsLoading(false); // Hide loader
          };
    
     
  };

    const handleCancel = () => {
    console.log('Delete operation cancelled.');
   // setActionMessage('Delete operation cancelled.');  
    setShowConfirmation(false); // Hide the confirmation dialog

  };


  return (
   
    <div className="bg-white border shadow-sm p-4 rounded-md flex items-center space-x-4 w-full">
      {/* Left: Profile Image */}
    
       <Avatar alt="User Avatar" src={imageUrl} />  

      {/* Right: Name, Relation, Icons */}
      <div className="flex flex-col justify-between flex-grow">
        {/* Name and Relation */}
        <div>
          <h3 className="text-lg font-semibold">{name}</h3>
          <p className="text-gray-600">{relation}</p>
        </div>

        {/* Action Icons */}
        {/* <div className="flex space-x-6 mt-3 text-blue-600 text-lg">*/}
          <footer className="w-full  z-50 p-2 flex justify-around">
      
       <div>
      <Link className="items-center justify-center" to={`/AddMember/${member}`}><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg></Link>
      </div>

       <div>
      <Link  className="items-center justify-center" onClick={handleDeleteClick} ><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></Link>  
      </div>

     <div>
      <Link  className="items-center justify-center" to="/bills"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg></Link>  
      </div>

      <div>
      <Link  className="items-center justify-center" to="/timeline"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg></Link>  
      </div>

      <div>
      <Link  className="items-center justify-center" to="/timeline"><svg width='24px' height='24px' stroke-width='2' fill='none'stroke='currentColor' stroke-linejoin='round' stroke-linecap= 'round' viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg></Link>  
      </div>
      
      {showConfirmation && (
        <ConfirmationDialog
          message="Are you sure you want to delete this item?"
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}
        <div className="mb-6 text-center">
                              {isLoading ? (
                                  <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
                              ) : null}
                          </div>
       
    
    </footer>
       {/* </div> */}
      </div>
        <ToastContainer />
    </div>
  );
};

export default FamilyMemberCard;