import React from 'react';
import { useState,useEffect } from "react";
import { useNavigate,useParams  } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import Footer from '../Footer';
import { GetFamilyDepedent ,GetMemberById} from '../../services/api';
import Member from './Member';

export default function AddMember({ paramMember }) {

     const navigate = useNavigate();     
    let { editmemberId } = useParams();
  const [message, setmessage] = useState(null);
  const [status, setstatus] = useState(null);
   const [isLoading, setIsLoading] = useState(false);

 const [depedent, setdepedent] = useState([]);
const [memberId, setmemberId] = useState("");
const [member, setmember] = useState("");
   


    useEffect(() => {
   console.log(editmemberId);
  async function fetchFamilyDepedentData() {
     const token = localStorage.getItem("token");
     const res = await GetFamilyDepedent(token);
          setdepedent(res);
          console.log("Depedent",res);
    if(editmemberId!=null)
    {
        setmemberId(editmemberId);
         const selectedmember = res.filter(item => item.memberID === editmemberId);
         console.log(selectedmember);
        setmember(selectedmember); 
    }
  }

  fetchFamilyDepedentData();

}, []);

  const handleChange = (e) => {
    setmemberId(e.target.value)
    console.log('Selected member Id:', e.target.value);

    const selectedmember = depedent.filter(item => item.memberID === e.target.value);
      setmember(selectedmember); 
     console.log('Selected member:', selectedmember);

  };

  const handleControlChange = async (updatedState) => {
   console.log("Dependent Refresh",updatedState); // Keep updated state from UserControl
      const token = localStorage.getItem("token");
     const res = await GetFamilyDepedent(token);
          setdepedent(res);
  };


const handleMyfamily = () => {
        navigate("/family");
   } 

    return (
        <div className="pt-16 pb-16 h-screen overflow-y-scroll">
            <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
                <div></div>
                <div className="flex space-x-4 items-Left">
                    <button
                        type="submit"
                         onClick={() => handleMyfamily()}
                        className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Cancel
                    </button>
                </div>
                <h1 className="text-xl font-semibold text-center flex-grow text-center">Add Member</h1>
            </header>

            <div className="flex flex-col items-center justify-center bg-gray-100 p-2">
                <div className="bg-white shadow-lg w-full max-w-md p-4">
                    
                  

                        <div>
                            <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                                View Member
                            </label>
                            <div className="mt-2">
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                        id="viewmember"
                                        name="viewmember"
                                        required
                                        value={memberId}
                                        onChange={handleChange}                                       
                                    >
                                         <option value="">-- Select a memeber to view --</option>
                                        {
                                        depedent.map((mem) => (
                                        <option key={mem.memberID} value={mem.memberID}
                                        >
                                        {mem.firstName}
                                        </option>
                                        ))
                                        }
                                        
                                    </select>
                            </div>
                        </div>
                    </div>
           
                </div>

            <Member paramMember={member}  onChange={handleControlChange}/>
            <Footer />
        </div>

    );
} 