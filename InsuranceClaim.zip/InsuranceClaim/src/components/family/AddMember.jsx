import React from 'react';
import { useState,useEffect } from "react";
import { SaveMember } from '../../services/api';
import { useNavigate } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import Footer from '../Footer';
import { GetRelationshipType,GetDistinctState,GetDistinctZipbyState } from '../../services/api';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function AddMember({ paramMember }) {

     const navigate = useNavigate();

  const [message, setmessage] = useState(null);
  const [status, setstatus] = useState(null);
   const [isLoading, setIsLoading] = useState(false);
   const [relationship, setrelationship] = useState([]);
    const [States, setStates] = useState([]);
    const [zip, setzip] = useState([]);

     const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [gender, setgender] = useState("M");
    const [dob, setdob] = useState({ startDate: null, endDate: null });
    const [mobileno, setmobileno] = useState("");
    const [RelationshipTypeID, setRelationshipTypeID] = useState("");
    const [email, setEmail] = useState("");
    const [State, setState] = useState(null);
    const [Address1, setAddress1] = useState("");
    const [Address2, setAddress2] = useState("");
    const [City, setCity] = useState("");
    const [ZipCode, setZipCode] = useState(null);
    const [HasLogin, setHasLogin] = useState(false);

    useEffect(() => {

  async function fetchRelationshipData() {
     const res = await GetRelationshipType();
          setrelationship(res);
      const st = await GetDistinctState();
          setStates(st);
  }

  fetchRelationshipData();

}, []);

 const handleStateChange = async (event, newValue) => {
    setState(newValue);
    const selecedstate=newValue;
    console.log(selecedstate);
    setZipCode(null); // Reset setZipCode
     const res = await GetDistinctZipbyState(selecedstate);
          setzip(res);
  };

const handleMyfamily = () => {
        navigate("/family");
   } 
 
  const handleSaveMemberSubmit = async (e) => {
     e.preventDefault();
       setIsLoading(true); // Show loader
      //  const MemberID = localStorage.getItem("Mid");
         const UserID = localStorage.getItem("Mid");
     console.log("Member details:", { UserID,firstName, lastName, gender, dob, mobileno, RelationshipTypeID, email,State,Address1,Address2,City,ZipCode,HasLogin});
     // Call the register function from the API service
     const res = await SaveMember({ UserID,firstName, lastName, gender, dob, mobileno, RelationshipTypeID, email,State,Address1,Address2,City,ZipCode,HasLogin});
     console.log("Response from register API:", res);
     setstatus(res.status);
     setmessage(res.message);
    if (res.status==='Success') 
        toast.success(res.message);    
    else
        toast.error(res.message);  
       setIsLoading(false); // Hide loader
   };
    return (
        <div className="pt-16 pb-16 h-screen overflow-y-scroll">
            <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
                <div></div>
                <div className="flex space-x-4 items-Left">
                    <button
                        type="submit"
                         onClick={() => handleMyfamily()}
                        className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Cancel
                    </button>
                </div>
                <h1 className="text-xl font-semibold text-center flex-grow text-center">Add Member</h1>
            </header>

            <form className="space-y-6" onSubmit={handleSaveMemberSubmit}>

                <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
                    <div className="bg-white shadow-lg w-full max-w-md p-6">
                        <div >
                            <h1 className="text-xl font-semibold flex-grow ">Member Details</h1>

                        </div>
                        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">

                            <div>
                                <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                                    First Name
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="firstName"
                                        name="firstName"
                                        type="text"
                                        required
                                        onChange={(e) => setfirstName(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="lastName" className="block text-sm/6 font-medium text-gray-900">
                                    Last Name
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="lastName"
                                        name="lastName"
                                        type="text"
                                        required
                                        onChange={(e) => setlastName(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="genter" className="block text-sm/6 font-medium text-gray-900">
                                    Gender
                                </label>
                                <div className="mt-2">
                                    <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                        id="genter"
                                        name="genter"
                                        required
                                        value={gender}
                                        onChange={e => setgender(e.target.value)}
                                    >
                                        <option value="M">Male</option>
                                        <option value="F">Female</option>
                                        <option value="O">Others</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <div className="flex items-center justify-between">
                                    <label htmlFor="dob" className="block text-sm/6 font-medium text-gray-900">
                                        Date of Birth
                                    </label>
                                </div>
                                <div className="mt-2">
                                    <input
                                        id="dob"
                                        name="dob"
                                        type="date"
                                        required
                                        onChange={(e) => setdob(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>


                            <div>
                                <label htmlFor="Relationship" className="block text-sm/6 font-medium text-gray-900">
                                    Relationship
                                </label>
                                <div className="mt-2">
                                    <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                        id="Relationship"
                                        name="Relationship"
                                        required
                                        value={RelationshipTypeID}
                                        onChange={e => setRelationshipTypeID(e.target.value)}
                                    >
                                         <option value="">-- Choose Relationship --</option>
                                        {
                                        relationship.map((relation) => (
                                        <option key={relation.id} value={relation.id}>
                                        {relation.type}
                                        </option>
                                        ))
                                        }
                                        
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                                    Email address
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        required
                                        onChange={(e) => setEmail(e.target.value)}
                                        autoComplete="email"
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="mobileno" className="block text-sm/6 font-medium text-gray-900">
                                    US Mobile #
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="mobileno"
                                        name="mobileno"
                                        type="text"
                                        required
                                        onChange={(e) => setmobileno(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>



                        </div>
                    </div>


                    <div className="bg-white shadow-lg w-full max-w-md p-10">
                        <div >
                            <h1 className="text-xl font-semibold flex-grow ">Address Details</h1>

                        </div>
                        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">

                            <div>
                                <label htmlFor="address1" className="block text-sm/6 font-medium text-gray-900">
                                    Address Line 1
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="address1"
                                        name="address1"
                                        type="text"
                                       
                                        onChange={(e) => setAddress1(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>


                            <div>
                                <label htmlFor="address2" className="block text-sm/6 font-medium text-gray-900">
                                    Address Line 2 (Apt, Suite, etc.)
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="address2"
                                        name="address2"
                                        type="text"
                                     
                                        onChange={(e) => setAddress2(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="city" className="block text-sm/6 font-medium text-gray-900">
                                    City
                                </label>
                                <div className="mt-2">
                                    <input
                                        id="city"
                                        name="city"
                                        type="text"
                                      
                                        onChange={(e) => setCity(e.target.value)}
                                        className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="state" className="block text-sm/6 font-medium text-gray-900">
                                    State
                                </label>
                                <div className="mt-2">
                                  
                                     <Autocomplete
                                        disablePortal
                                        options={States}
                                        value={State}
                                       onChange={handleStateChange}
                                        sx={{ width: 350 }}
                                        renderInput={(params) => <TextField {...params} />}
                                        />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="zipcode" className="block text-sm/6 font-medium text-gray-900">
                                    Zip Code
                                </label>
                                <div className="mt-2">                                  
                                     <Autocomplete
                                        disablePortal
                                        options={zip}                                      
                                        onChange={(event, newValue) => setZipCode(newValue)}
                                        sx={{ width: 350 }}
                                        renderInput={(params) => <TextField {...params} />}
                                        />
                                </div>
                            </div>
                            <div>

                                <div className="mt-2">
                                    <label htmlFor="haslogin" className="block text-sm/6 font-medium text-gray-900"> Do You Need Login
                                        <input
                                            id="haslogin"
                                            name="haslogin"
                                            type="checkbox"                                            
                                            onChange={(e) => setHasLogin(e.target.value)}
                                        >
                                        </input>


                                    </label>
                                </div>

                            </div>


                        </div>
                    </div>
                    <div>
                        <button
                            type="submit"
                            className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        >
                            Save Member
                        </button>
                    </div>
                    {(status === 'Success') ? (
                        <div className="text-green-600">
                            <p className="mt-10 text-center text-sm/6 text-green-500">
                                {message}
                            </p>
                            
                        </div>
                    ) : (
                        <div>
                            <p className="mt-10 text-center text-sm/6 text-red-500">
                                {message}</p>
                        </div>
                    )
                    }
                    <div className="mb-6 text-center">
                        {isLoading ? (
                            <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
                        ) : null}
                    </div>
                     <ToastContainer />
                </div>
            </form>
            <Footer />
        </div>

    );
} 