import React from 'react';
import { useState, useEffect } from "react";
import { useForm } from 'react-hook-form';
import { useAuth } from '../authContext';
import { useDropzone } from 'react-dropzone';
import { useNavigate, useParams } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import Footer from '../Footer';
import { GetFamilyDepedent, GetMemberInsuranceById, GetBenifitType, GetPolicyType } from '../../services/api';
import Member from './Member';
import { Table, TableBody, TableCell, TableHead, TableRow, Select, MenuItem } from "@mui/material";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  Radio,
  RadioGroup,
  FormControl,
  FormControlLabel,
  FormLabel,
  Box,
  Paper
} from '@mui/material';


function ImageUploadBox({ label, fileState, setFileState, maxSizeMB = 2 }) {
    const { file, preview, error } = fileState;

    const validator = (f) => {
        if (!f.type.startsWith('image/')) {
            return { code: 'file-invalid-type', message: 'Only images are allowed' };
        }
        if (f.size > maxSizeMB * 1024 * 1024) {
            return { code: 'file-too-large', message: `Max size is ${maxSizeMB} MB` };
        }
        return null;
    };

    const onDrop = (accepted, rejected) => {
        if (accepted.length) {
            const f = accepted[0];
            setFileState({ file: f, preview: URL.createObjectURL(f), error: null });
        } else if (rejected.length) {
            setFileState(s => ({ ...s, error: rejected[0].errors[0].message }));
        }
    };

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        validator,
        multiple: false,
        accept: {
            'image/png': ['.png'],
            'image/jpeg': ['.jpg', '.jpeg']
        },
    });

    useEffect(() => {
        return () => {
            if (preview) URL.revokeObjectURL(preview);
        };
    }, [preview]);

    return (
        <div className="w-full sm:w-1/2 flex flex-col space-y-1">
            <label className="text-sm font-medium text-gray-700">{label}</label>
            <div
                {...getRootProps()}
                className={`
          relative h-40 border-2 border-dashed rounded-lg flex items-center justify-center
          text-center p-2 cursor-pointer transition
          ${isDragActive ? 'border-blue-400 bg-blue-50' : 'border-gray-300 bg-white'}
        `}
            >
                <input {...getInputProps()} />
                {preview ? (
                    <img src={preview} alt={label} className="max-h-full object-contain" />
                ) : (
                    <div className="text-gray-500 whitespace-pre-wrap">
                        {isDragActive ? 'Drop image here' : `Tap or drag to upload\n(${label})`}
                    </div>
                )}
                {error && (
                    <p className="absolute bottom-2 text-xs text-red-600">{error}</p>
                )}
            </div>
        </div>
    );
}


const frequencyOptions = ['Weekly', 'Monthly'];
const insuranceTypes = ['Medical', 'Dental', 'Vision'];

export default function AddInsurance({ paramMember }) {
    const { user } = useAuth();
    const navigate = useNavigate();
      const { action, memberIds, policyTypes } = useParams();
    const { handleSubmit } = useForm();

    const [message, setmessage] = useState(null);
    const [status, setstatus] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const [isdisable, setisdisable] = useState(false);
    const [title, settitle] = useState("Add Insurance");

    const [depedent, setdepedent] = useState([]);
    const [memberId, setmemberId] = useState(user.Mid);
    const [member, setmember] = useState("");

    const [memInsID, setmemInsID] = useState(0);


    const [front, setFront] = useState({ file: null, preview: null, error: null });
    const [back, setBack] = useState({ file: null, preview: null, error: null });
    const [frontPreview, setFrontPreview] = useState(null);
    const [backPreview, setBackPreview] = useState(null);
  
    const [policyType, setPolicyType] = useState([]);
    const [policyTypeId, setpolicyTypeId] = useState(0);   
    const [benefitType, setbenefitType] = useState([]);
    const [benefitTypeID, setbenefitTypeID] = useState(0);
    const [subscriberId, setsubscriberId] = useState(user.Mid);
    const [selectedDepedents, setselectedDepedents] = useState([]);

    const [paymentMethod, setPaymentMethod] = useState('');
    const [otherPayment, setOtherPayment] = useState('');
    const [coverageTypes, setCoverageTypes] = useState([]);
    const [employeeContribution, setEmployeeContribution] = useState({});
    const [employerContribution, setEmployerContribution] = useState({});
    const [dontKnow, setDontKnow] = useState(false);
    const isNumeric = (val) => !isNaN(val) && !isNaN(parseFloat(val));

    const handleSelectionChange = (e) => {
        const selected = Array.from(e.target.selectedOptions, (option) => option.value);
        setselectedDepedents(selected);
    };


    const [employeecontribute, setemployeecontribute] = useState([
        { type: "Medical", amount: "", frequency: "" },
        { type: "Dental", amount: "", frequency: "" },
        { type: "Vision", amount: "", frequency: "" },
    ]);

    const handleemployeeContributionChange = (index, key, value) => {
        const updated = [...employeecontribute];
        updated[index][key] = value;
        setemployeecontribute(updated);
    };

    const [employercontribute, setemployercontribute] = useState([
        { type: "Medical", amount: "", frequency: "" },
        { type: "Dental", amount: "", frequency: "" },
        { type: "Vision", amount: "", frequency: "" },
    ]);

    const handleemployerContributionChange = (index, key, value) => {
        const updated = [...employercontribute];
        updated[index][key] = value;
        setemployercontribute(updated);
    };

    const handleCoverageChange = (type) => {
        setCoverageTypes((prev) =>
            prev.includes(type)
                ? prev.filter((item) => item !== type)
                : [...prev, type]
        );
    };

    const handleEmployeeChange = (type, key, value) => {
        setEmployeeContribution((prev) => ({
            ...prev,
            [type]: {
                ...prev[type],
                [key]: value,
            },
        }));
    };

    const handleEmployerChange = (type, key, value) => {
        setEmployerContribution((prev) => ({
            ...prev,
            [type]: {
                ...prev[type],
                [key]: value,
            },
        }));
    };

     async function GetMemberInsurance(data) {
            const insurance = await GetMemberInsuranceById(data);
            console.log("GetMemberInsuranceById", insurance);
              if(insurance!=null )
            {
              
                setmemInsID(insurance.memInsID);
                setpolicyTypeId(insurance.policyTypeID);
                setbenefitTypeID(insurance.benefitTypeID);
                setsubscriberId(insurance.subscriberID);
                setmemberId(insurance.memberID);
                if(insurance.dependentsID != null  && insurance.dependentsID !== "")
                {
                setselectedDepedents(insurance.dependentsID.split(","));
                console.log("Selected Dependent", insurance.dependentsID.split(","));
                }
                if (insurance.insFrontImgURL != null) {
                    setFront({ file: null, preview: insurance.insFrontImgURL, error: null });
                }
                if (insurance.insBackImgURL != null) {
                    setBack({ file: null, preview: insurance.insBackImgURL, error: null });
                }
            }
               //   setselectedDepedents(["382503f3-3173-42ca-accd-06c72e2722e8", "0d3f50ea-6b74-43c4-97be-e8d71a1f2fcb"]); // Replace with actual memberID values
      
          
        }


    useEffect(() => {
        console.log("Action Insurance", action);
          console.log("MemIds",memberIds);
          console.log("policyTypes",policyTypes);
        const userID = user.Mid;
        
        async function fetchFamilyDepedentData() {
            const token = user.token;
            const res = await GetFamilyDepedent(token);
            setdepedent(res);
            console.log("Depedent", res);     
        }

        fetchFamilyDepedentData();

        async function fetchBenefitType() {
            const res = await GetBenifitType();
            console.log("Benefit Type", res);
            if (res && Array.isArray(res))
            {
                setbenefitType(res);
                 const defaultBenefitType=res.filter(item => item.type === "Medical");
                if(defaultBenefitType!=null && defaultBenefitType.length>0)
                {
                console.log("defaultBenefitType",defaultBenefitType[0].id);
                setbenefitTypeID(defaultBenefitType[0].id);
                }
            }
            else
                console.error("Invalid response format for benefit types:", res);

        }

        fetchBenefitType();
        async function fetchPolicyType() {
            const res = await GetPolicyType();
            console.log("Policy Type", res);
            if (res && Array.isArray(res))
            {
                setPolicyType(res);              
                const primarypolicy=(action==="add" && policyTypes!="1")? res.filter(item => item.id === Number(policyTypes)): res.filter(item => item.type === "Primary");
                if(primarypolicy!=null && primarypolicy.length>0)
                {
                console.log("primarypolicy",primarypolicy[0].id);
                setpolicyTypeId(primarypolicy[0].id);
                }
                 if(action==="add")
                 {
                      console.log("fetchPolicyType add mode:", policyTypes);
                 }
            }                
            else
                console.error("Invalid response format for policy types:", res);
        }
        fetchPolicyType();

         
         if(action==="add")
          {
            console.log("memberId in add mode:", memberIds);
            console.log(typeof memberIds );
            if (memberIds !=null){              
                if (memberIds==0) {   //value is 0         
                    setmemberId(userID); 
                      console.log("NUmeric memberId:", memberIds);                    
                 }
                 else
                 {
                    setmemberId(memberIds)
                    setisdisable(true);                   
                 }
                setsubscriberId(userID);
                settitle("Add");
                setmemInsID(0);
                setFront({ file: null, preview: null, error: null });
                console.log("Add Insurance for userID:", userID);
                console.log("Default SubscriberId ", subscriberId);
                
            }          
        }
        else {
            settitle("Edit");
            setisdisable(true); 
            console.log("Get memeber Insurance called") ;      
            GetMemberInsurance(memberIds);              
         
        }
    }, []);

    const handleMyfamily = () => {
        navigate("/family/insurance");
    }

    const handleChange = (e) => {
        setmemberId(e.target.value)
        console.log('Selected member Id:', e.target.value);

        const selectedmember = depedent.filter(item => item.memberID === e.target.value);
        setmember(selectedmember);
        console.log('Selected member:', selectedmember);

    };

    const filehandleChange = (file, setter, previewSetter) => {
        setter(file);
        previewSetter(URL.createObjectURL(file));
    };

    const RadioBoxhandleChange = (id) => {
    setpolicyTypeId(id);
    console.log("Selected Policy Type ID:", id);
  };

    const onSubmit = async (e) => {
        e.preventDefault();

        console.log("employeeContribution",employeeContribution);
        console.log("employeer contriution",employerContribution);
        console.log("paymentMethod",paymentMethod);
        console.log("other payment",otherPayment);
        console.log("coverageTypes",coverageTypes);
        
         const userID = user.Mid;
        console.log('PolicyTypeID', policyTypeId);
        console.log(front, back);
        console.log('frontImage',(front==="undefined")? null: front.file);
        console.log('backImage', (back==="undefined")? null: back.file);
        console.log('BenefitTypeID', benefitTypeID);
        console.log('SubscriberID', subscriberId);
        console.log('MemberID', memberId);
        if (typeof memInsID === "undefined") 
            setmemInsID(0);
        else
            setmemInsID(memInsID);

        console.log('memInsID', memInsID);
    

        const formData = new FormData();
        formData.append('PolicyTypeID', policyTypeId);    
        if (front && front.file)
             formData.append('frontImage', front.file); 
        if (back && back.file)
            formData.append('backImage', back.file);
       // formData.append('frontImage', (front==null)? null: front.file);      
        //formData.append('backImage', (back==null)? null: back.file);
        formData.append('BenefitTypeID', benefitTypeID);
        formData.append('SubscriberID', subscriberId);
        formData.append('MemberID', memberId);
        formData.append('memInsID', memInsID);        
        formData.append('DependentsID', selectedDepedents.join(","));
        formData.append('UserID', userID);
        setIsLoading(true); // Show loader
        try {
            const res = await fetch('https://localhost:7233/api/Users/SaveInsuranceAsync', {
                method: 'POST',
                body: formData,
            });
            console.log(res);
            const data = await res.json(); // parse the JSON body
            console.log("Response from API:", data);           
            setstatus(data.status);
            setmessage(data.message);           
            if (data.status === 'Success') {
            toast.success(data.message);
            setmemInsID(data.insuranceId);
            if(data.frontImgURL!=null)
            setFront({ file:null,  preview: data.frontImgURL, error: null });
            if(data.backImgURL!=null)
            setBack({  file:null,preview: data.backImgURL, error: null });
            }
            else
            toast.error(data.message);

            if (!res.ok) throw new Error('Upload failed');
          //  alert('Policy uploaded successfully!');
        } catch {
             setIsLoading(false); // Hide loader
           // alert('Submission failed. Please try again.');
        }

      
        setIsLoading(false); // Hide loader

    };


    return (

        <div className="pt-16 pb-16 h-screen overflow-y-scroll">
            <header className="fixed top-0 w-full bg-white shadow z-50 p-4 flex justify-between items-center">
                <div></div>
                <div className="flex space-x-4 items-Left">
                    <button
                        type="submit"
                        onClick={() => handleMyfamily()}
                        className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Cancel
                    </button>
                </div>
                <h1 className="text-xl font-semibold text-center flex-grow text-center">{title}&nbsp;Insurance</h1>
            </header>
            <div className="bg-white-100 p-2">
                <div className="bg-white  w-full max-w p-4">



                     <div className="rounded-2xl border p-2 mt-1">   
                        <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                            {title} For
                        </label>
                        <div className="mt-2">
                            <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                id="viewmembers"
                                name="viewmembers"
                                required
                                disabled={isdisable}
                                value={memberId}
                                onChange={handleChange}
                            >
                                {
                                    depedent.map((mem) => (
                                        <option key={mem.memberID} value={mem.memberID}
                                        >
                                            {mem.firstName}
                                        </option>
                                    ))
                                }

                            </select>
                        </div>
                    </div>
                </div>
                             
                <div className="max-w-mx-auto p-4 space-y-6 font-sans rounded-md ">

                    <form onSubmit={onSubmit} >
                          <div className="rounded-2xl shadow-md border p-6 mt-2">   
                        <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-4 sm:space-y-0">
                            <ImageUploadBox label="Front Image" fileState={front} setFileState={setFront} />
                            <ImageUploadBox label="Back Image" fileState={back} setFileState={setBack} />

                        </div>                       

                        <div className="space-y-4">
                            <label className="text-sm font-medium text-gray-700 inline-flex items-center">Policy Type</label>
                            <div className="flex space-x-4">

                                    <FormControl component="fieldset" disabled={isdisable}>                                    
                                        <RadioGroup
                                            name="policyType"
                                            value={policyTypeId}
                                            onChange={(e) => RadioBoxhandleChange(e.target.value)}
                                            row                                           
                                        >
                                            {policyType.map((policytype) => {
                                                const isSelected = policyTypeId === policytype.id;
                                                return (
                                                    <div
                                                        key={policytype.id}
                                                        style={{
                                                            margin: '8px',
                                                            padding: '16px',
                                                            borderRadius: '12px',
                                                            border: `1px solid ${isSelected ? '#8b5cf6' : '#d1d5db'}`, // violet or gray-300
                                                            backgroundColor: isSelected ? '#ede9fe' : '#ffffff', // violet-100 or white
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                        }}
                                                    >
                                                        <FormControlLabel
                                                            value={policytype.id}
                                                            control={
                                                                <Radio
                                                                    sx={{
                                                                        color: '#8b5cf6',
                                                                        '&.Mui-checked': {
                                                                            color: '#8b5cf6',
                                                                        },
                                                                    }}
                                                                />
                                                            }
                                                            label={policytype.type}
                                                        />
                                                    </div>
                                                );
                                            })}
                                        </RadioGroup>
                                    </FormControl>
                            </div>
                        </div>

                        <div className="space-y-4">



                            <div>
                                <label className="text-sm font-medium text-gray-700">Benefit Type</label>
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    id="BenefitType"
                                    name="BenefitType"
                                    required
                                    value={benefitTypeID}
                                    onChange={e => setbenefitTypeID(e.target.value)}
                                >
                                    {
                                        benefitType.map((benefit) => (
                                            <option key={benefit.id} value={benefit.id}>
                                                {benefit.type}
                                            </option>
                                        ))
                                    }
                                </select>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-700">Subscriber</label>
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    id="Subscriber"
                                    name="Subscriber"
                                    required
                                    value={subscriberId}
                                    onChange={e => setsubscriberId(e.target.value)}

                                >
                                    {
                                        depedent.filter(m => ['Self','Spouse'].includes(m.relationshipType)).map((mem) => (
                                            <option key={mem.memberID} value={mem.memberID}
                                            >
                                                {mem.firstName}
                                            </option>
                                        ))
                                    }

                                </select>
                            </div>
                            <div>
                                <label className="text-sm font-medium text-gray-700">Dependents</label>
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    id="viewmember"
                                    name="viewmember"
                                    required
                                    multiple
                                    value={selectedDepedents}
                                    onChange={handleSelectionChange}
                                >
                                    {
                                        depedent.map((mem) => (
                                            <option key={mem.memberID} value={mem.memberID}
                                            >
                                                {mem.firstName}
                                            </option>
                                        ))
                                    }

                                </select>

                            </div>
                        </div>
                         <div className="rounded-2xl shadow-md border p-6 mt-10 ">              
                        <h2 className="text-xl font-bold mb-4">Insurance Coverage Questionnaire</h2>
                        {/* Section 1 */}
                        <h3 className="font-semibold mb-2">Section 1: Payment Method & Coverage Types</h3>
                        <p>1. Are your insurance premiums paid directly by you or through your paycheck?</p>
                        <div className="space-y-1 my-2">
                            <div className={`p-4 border rounded-xl ${paymentMethod === "direct" ? "border-violet-500 bg-violet-100" : "border-gray-300 bg-white"}`}>
                                <label className="flex items-center space-x-2">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="direct"
                                        checked={paymentMethod === "direct"}
                                        onChange={() => setPaymentMethod("direct")}
                                    />
                                    <span>Directly by me</span>
                                </label>
                            </div>
                            <div className={`p-4 border rounded-xl ${paymentMethod === "paycheck" ? "border-violet-500 bg-violet-100" : "border-gray-300 bg-white"}`}>
                                <label className="flex items-center space-x-2">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="paycheck"
                                        checked={paymentMethod === "paycheck"}
                                        onChange={() => setPaymentMethod("paycheck")}
                                    />
                                    <span>Through my paycheck</span>
                                </label>
                            </div>
                            <div className={`p-4 border rounded-xl ${paymentMethod === "Other" ? "border-violet-500 bg-violet-100" : "border-gray-300 bg-white"}`}>
                                <label className="flex items-center space-x-2">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="Other"
                                        checked={paymentMethod === 'Other'}
                                        onChange={() => setPaymentMethod('Other')}
                                    />{' '}
                                    <span>Other:</span>
                                    {paymentMethod === 'Other' && (
                                        <input
                                            type="text"
                                            className="ml-2 border p-1 rounded bg-white"
                                            value={otherPayment}
                                            onChange={(e) => setOtherPayment(e.target.value)}
                                            placeholder="Please specify"
                                        />
                                    )}
                                </label>
                            </div>
                        </div>

                        <p className="mt-4">2. Which types of insurance do you currently have?</p>
                        <div className="space-y-1 my-2">
                            {insuranceTypes.map((type) => (
                                <div className={`p-4 border rounded-xl ${coverageTypes.includes(type) ? "border-violet-500 bg-violet-100" : "border-gray-300 bg-white"}`}>
                                    <label key={type} className="flex items-center space-x-2">
                                        <input
                                            type="checkbox"
                                            checked={coverageTypes.includes(type)}
                                            onChange={() => handleCoverageChange(type)}
                                        />{' '}
                                        <span>{type}</span>
                                    </label>
                                </div>
                            ))}
                        </div>
                        </div>  
                        {/* Section 2 */}
                        <div className="rounded-2xl shadow-md border p-6 mt-2">
                            <h2 className="text-xl font-bold">Section 2: Employee Contribution</h2>
                            <p>3. How much do you pay for insurance premiums? Please provide details for each type of insurance:</p>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Insurance Type</TableCell>
                                        <TableCell>Amount</TableCell>
                                        <TableCell>Frequency</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {employeecontribute.map((item, index) => (
                                        <TableRow key={item.type}>
                                            <TableCell>{item.type}</TableCell>
                                            <TableCell>
                                                <input
                                                    type="text"
                                                    value={item.amount}
                                                    onChange={(e) => handleemployeeContributionChange(index, "amount", e.target.value)}
                                                    placeholder="$"
                                                    className="border rounded px-2 py-1"
                                                />
                                            </TableCell>
                                            <TableCell>
                                                <select
                                                    value={item.frequency}
                                                    onChange={(e) => handleemployeeContributionChange(index, "frequency", e.target.value)}
                                                    className="border rounded px-2 py-1"
                                                >
                                                    <option value="Weekly">Weekly</option>
                                                    <option value="Monthly">Monthly</option>
                                                </select>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>

                        {/* Section 3*/}
                        <div className="rounded-2xl shadow-md border p-6 mt-2">
                            <h2 className="text-xl font-bold">Section 3: Employer Contribution</h2>
                            <p>4. For each type of insurance you have, please indicate the amount your employer contributes on your behalf:</p>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Insurance Type</TableCell>
                                        <TableCell>Amount</TableCell>
                                        <TableCell>Frequency</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {employercontribute.map((item, index) => (
                                        <TableRow key={item.type}>
                                            <TableCell>{item.type}</TableCell>
                                            <TableCell>
                                                <input
                                                    type="text"
                                                    value={item.amount}
                                                    onChange={(e) => handleemployerContributionChange(index, "amount", e.target.value)}
                                                    placeholder="$"
                                                    className="border rounded px-2 py-1"
                                                />
                                            </TableCell>
                                            <TableCell>
                                                <select
                                                    value={item.frequency}
                                                    onChange={(e) => handleemployerContributionChange(index, "frequency", e.target.value)}
                                                    className="border rounded px-2 py-1"
                                                >
                                                    <option value="Weekly">Weekly</option>
                                                    <option value="Monthly">Monthly</option>
                                                </select>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                        <div className={`p-4 border rounded-xl mt-2 ${dontKnow ? "border-violet-500 bg-violet-100" : "border-gray-300 bg-white"}`}>
                            <label className="block mb-4">
                                <input
                                    type="checkbox"
                                    checked={dontKnow}
                                    onChange={() => setDontKnow(!dontKnow)}
                                />{' '}
                                I don’t know — please complete this section with assistance from your HR/payroll department
                            </label>
                        </div>
                        </div> 
                        <div className="flex  justify-center mt-2" >
                            <button
                                type="submit"
                                className="flex  justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                            >
                                Save Insurance
                            </button>
                        </div>
                        
                        {(status === 'Success') ? (
                            <div className="text-green-600">
                                <p className="mt-10 text-center text-sm/6 text-green-500">
                                    {message}
                                </p>

                            </div>
                        ) : (
                            <div>
                                <p className="mt-10 text-center text-sm/6 text-red-500">
                                    {message}</p>
                            </div>
                        )
                        }
                        <div className="mb-6 text-center">
                            {isLoading ? (
                                <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
                            ) : null}
                        </div>
                        <ToastContainer />
                    </form>
                </div>
            </div>

        </div>


    );
}         