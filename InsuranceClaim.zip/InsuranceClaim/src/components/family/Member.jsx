import React from 'react';
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ClipLoader } from 'react-spinners'
import Footer from '../Footer';
import { SaveMember,GetRelationshipType, GetZipDatabyCode } from '../../services/api';
import moment from 'moment';
import axios from "axios";
import Avatar from '@mui/material/Avatar';


import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function Member({ paramMember, onChange }) {

    const navigate = useNavigate();
  //  const [formData, setFormData] = useState(paramMember[0]);
    

    const [message, setmessage] = useState(null);
    const [status, setstatus] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [relationship, setrelationship] = useState([]);
    const [isPrimaryMem, setisPrimaryMem] = useState(false);

    const [memberID, setmemberID] = useState("");
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [gender, setgender] = useState("M");
    const [dob, setdob] = useState({ startDate: null, endDate: null });
    const [mobileno, setmobileno] = useState("");
    const [RelationshipTypeID, setRelationshipTypeID] = useState("");
    const [EmailID, setEmailID] = useState("");
    const [State, setState] = useState(null);
    const [memberPhotoURL,setmemberPhotoURL]=useState("")
    const [Address1, setAddress1] = useState("");
    const [Address2, setAddress2] = useState("");
    const [City, setCity] = useState("");
    const [ZipCode, setZipCode] = useState(null);
    const [HasLogin, setHasLogin] = useState(false);

    const [selectedFile, setselectedFile] = useState(null);
    const [IsProfileFileType, setIsProfileFileType]=useState(true);
    

    // Get current date in YYYY-MM-DD format for input max attribute
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const day = String(today.getDate()).padStart(2, '0');
    const maxDateString = `${year}-${month}-${day}`;

    useEffect(() => {


        if (paramMember != null)
            console.log("ParamData", paramMember);
        if (paramMember?.length === 0) {
            console.log("The paramMember array is empty or undefined/null.");
            setfirstName("");
            setlastName("");
            setmemberID("00000000-0000-0000-0000-000000000000");
            setgender("M");
            setdob({ startDate: null, endDate: null });
            setRelationshipTypeID("");
            setEmailID("");
            setmobileno("");
            setAddress1("");
            setAddress2("");
            setCity("");
            setState("");
            setZipCode("");
            setHasLogin(false);
            setmemberPhotoURL("")
        } else {
            console.log("The paramMember array is not empty or it's not an array.");
            setfirstName(paramMember[0].firstName);
            setlastName(paramMember[0].lastName);
            setmemberID(paramMember[0].memberID);
            setgender(paramMember[0].gender);
            if (paramMember[0].dob != null) {
                // console.log("dob",moment(paramMember[0].dob).format('YYYY-MM-DD'));
                setdob(moment(paramMember[0].dob).format('YYYY-MM-DD'));
            }
            setRelationshipTypeID(paramMember[0].relationshipTypeID);
            setEmailID(paramMember[0].emailID);
            setmobileno(paramMember[0].mobileNo);
            setAddress1(paramMember[0].address1);
            setAddress2(paramMember[0].address2);
            setCity(paramMember[0].city);
            setState(paramMember[0].state);
            setZipCode(paramMember[0].zipCode);
            setHasLogin(paramMember[0].hasLogin);
            setisPrimaryMem(paramMember[0].isPrimaryMem);
            setmemberPhotoURL(paramMember[0].memberPhotoURL);
            console.log("haslogin", paramMember[0].hasLogin)
           
        }
      //  setFormData(paramMember);



        async function fetchRelationshipData() {
            const res = await GetRelationshipType();
            setrelationship(res);
        }

        fetchRelationshipData();

    }, [paramMember]);

    const handleBlur = async () => {
        // Update state or perform actions when the input loses focus (e.g., after Tab)
        console.log('Input lost focus (likely due to Tab or click away). Current value:', ZipCode);
        if(ZipCode!='')
        {
        const res = await GetZipDatabyCode(ZipCode);
        console.log(res);
        setState(res.stateAbbr);
        setCity(res.cityName);
        }
    };

    const handleCheckboxChange = () => {
        // Toggle the 'isChecked' state when the checkbox is clicked
        setHasLogin(!HasLogin);
    };

     const handleFileChange = (e) => {
    //setselectedFile(e.target.files[0]);
     const file = e.target.files[0];
    if (file) {
      setselectedFile(file);
      setmemberPhotoURL(URL.createObjectURL(file));
      console.log(memberPhotoURL);
    }
  };

  const handleMobilenoChange = (e) => {
    const value = e.target.value;
    setmobileno(value)
    // Validate on change (optional)
    validatePhone(value);
  };

   const validatePhone = (value) => {
    // US phone number regex: (123) 456-7890 or 123-456-7890 or 1234567890
    const phoneRegex = /^(\+1\s?)?(\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}$/;

    if (!value || !phoneRegex.test(value)) {   
       setstatus("Error");
       setmessage("Invalid US phone number");
     
    } else {
        setstatus("");
       setmessage("");    
    }
  };


    const handleSaveMemberSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true); // Show loader
        //  const MemberID = localStorage.getItem("Mid");        
        const UserID = localStorage.getItem("Mid");
        console.log("Member details:", { memberID, UserID, firstName, lastName, gender, dob, mobileno, RelationshipTypeID, EmailID, State, Address1, Address2, City, ZipCode, HasLogin });
        // Call the register function from the API service
        const res = await SaveMember({ memberID, UserID, firstName, lastName, gender, dob, mobileno, RelationshipTypeID, EmailID, State, Address1, Address2, City, ZipCode, HasLogin });
        console.log("Response from register API:", res);       
        setstatus(res.status);
        setmessage(res.message);
        setmemberID(res.memberID);
        console.log("About to call fileupload");
        console.log("new memberID",res.memberID);
          if (selectedFile) 
          {
             console.log("called fileupload");
              const formData = new FormData();
              formData.append('file', selectedFile);
              formData.append('memberID', res.memberID);
              formData.append('IsProfileFileType', IsProfileFileType);
             
              
              try {

                  const response = await axios.post('https://localhost:7233/api/Users/Uploadfile', formData, {
                      headers: { 'Content-Type': 'multipart/form-data' },
                  });
                  console.log('Upload successful: ' + response.data.fileName);
                   console.log('Upload successful-profilephoto: ' + response.data.profilephoto);
                   if(RelationshipTypeID===1)//Self profile photo
                   {
                     localStorage.setItem("profilephoto", response.data.profilephoto);                      
                   }
                  setselectedFile(null);
              } catch (error) {
                  console.log('Upload failed');
              }
          }
      
        if (res.status === 'Success') {
            toast.success(res.message);
            onChange('true');
        }
        else
            toast.error(res.message);
        setIsLoading(false); // Hide loader
    };
    return (


        <form className="space-y-6" onSubmit={handleSaveMemberSubmit}>

            <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
                <div className="bg-white shadow-lg w-full max-w-md p-6">
                    <div >
                        <h1 className="text-xl font-semibold flex-grow ">Member Details</h1>

                    </div>
                    <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">

                        <div>
                            <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                                First Name
                            </label>
                            <div className="mt-2">
                                <input
                                    id="firstName"
                                    name="firstName"
                                    type="text"
                                    value={firstName}
                                    required
                                    onChange={(e) => setfirstName(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="lastName" className="block text-sm/6 font-medium text-gray-900">
                                Last Name
                            </label>
                            <div className="mt-2">
                                <input
                                    id="lastName"
                                    name="lastName"
                                    type="text"
                                    value={lastName}
                                    required
                                    onChange={(e) => setlastName(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>

                         <div>
                            <label className="block text-sm/6 font-medium text-gray-900">
                                Profile photo </label>
                                  <Avatar alt="User Avatar" src={memberPhotoURL} />  
                           
                            <div className="mt-2">
                                <input
                                    id="txtprofile"
                                    name="txtprofile"
                                    type="file"   
                                    accept="image/*"                                                      
                                    onChange={handleFileChange}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>

                        <div>
                            <label htmlFor="genter" className="block text-sm/6 font-medium text-gray-900">
                                Gender
                            </label>
                            <div className="mt-2">
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    id="genter"
                                    name="genter"
                                    required
                                    value={gender}
                                    onChange={e => setgender(e.target.value)}
                                >
                                    <option value="M">Male</option>
                                    <option value="F">Female</option>
                                    <option value="O">Others</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <div className="flex items-center justify-between">
                                <label htmlFor="dob" className="block text-sm/6 font-medium text-gray-900">
                                    Date of Birth
                                </label>
                            </div>
                            <div className="mt-2">
                                <input
                                    id="dob"
                                    name="dob"
                                    type="date"
                                    value={dob}
                                    required
                                    min={'1975-01-01'}
                                    max={maxDateString} // Disables future dates
                                    onChange={(e) => setdob(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>


                        <div>
                            <label htmlFor="Relationship" className="block text-sm/6 font-medium text-gray-900">
                                Relationship
                            </label>
                            <div className="mt-2">
                                <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                    id="Relationship"
                                    name="Relationship"
                                    disabled={isPrimaryMem}
                                    required
                                    value={RelationshipTypeID}
                                    onChange={e => setRelationshipTypeID(e.target.value)}
                                >
                                    <option value="">-- Choose Relationship --</option>
                                    {
                                        relationship.map((relation) => (
                                            <option key={relation.id} value={relation.id}>
                                                {relation.type}
                                            </option>
                                        ))
                                    }

                                </select>
                            </div>
                        </div>

                        <div>
                            <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                                Email address
                            </label>
                            <div className="mt-2">
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    value={EmailID}
                                    required
                                    onChange={(e) => setEmailID(e.target.value)}
                                    autoComplete="email"
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>
                        <div>
                            <label htmlFor="mobileno" className="block text-sm/6 font-medium text-gray-900">
                                US Mobile #
                            </label>
                            <div className="mt-2">
                                <input
                                    id="mobileno"
                                    name="mobileno"
                                    type="text"
                                    placeholder="(555) 555-5555"
                                    value={mobileno}
                                    required
                                    onChange={handleMobilenoChange}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>



                    </div>
                </div>


                <div className="bg-white shadow-lg w-full max-w-md p-10">
                    <div >
                        <h1 className="text-xl font-semibold flex-grow ">Address Details</h1>

                    </div>
                    <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">

                        <div>
                            <label htmlFor="address1" className="block text-sm/6 font-medium text-gray-900">
                                Address Line 1
                            </label>
                            <div className="mt-2">
                                <input
                                    id="address1"
                                    name="address1"
                                    type="text"
                                    value={Address1}
                                    onChange={(e) => setAddress1(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>


                        <div>
                            <label htmlFor="address2" className="block text-sm/6 font-medium text-gray-900">
                                Address Line 2 (Apt, Suite, etc.)
                            </label>
                            <div className="mt-2">
                                <input
                                    id="address2"
                                    name="address2"
                                    type="text"
                                    value={Address2}
                                    onChange={(e) => setAddress2(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>

                        <div>
                            <label htmlFor="city" className="block text-sm/6 font-medium text-gray-900">
                                City
                            </label>
                            <div className="mt-2">
                                <input
                                    id="city"
                                    name="city"
                                    type="text"
                                    value={City}
                                    onChange={(e) => setCity(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />
                            </div>
                        </div>

                        <div>
                            <label htmlFor="txtstate" className="block text-sm/6 font-medium text-gray-900">
                                State
                            </label>
                            <div className="mt-2">
                                <input
                                    id="txtstate"
                                    name="txtstate"
                                    type="text"
                                    value={State}
                                    onChange={(e) => setState(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />

                            </div>
                        </div>

                        <div>
                            <label htmlFor="zipcode" className="block text-sm/6 font-medium text-gray-900">
                                Zip Code
                            </label>
                            <div className="mt-2">
                                <input
                                    id="zipcode"
                                    name="zipcode"
                                    type="text"
                                    value={ZipCode}
                                    onBlur={handleBlur} // This event fires when the input loses focus
                                    onChange={(e) => setZipCode(e.target.value)}
                                    className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                />

                            </div>
                        </div>
                        <div>

                            <div className="mt-2">
                                <label htmlFor="haslogin" className="block text-sm/6 font-medium text-gray-900"> Do You Need Login
                                    <input
                                        id="haslogin"
                                        name="haslogin"
                                        type="checkbox"
                                        disabled={isPrimaryMem}
                                        checked={HasLogin}
                                        onChange={handleCheckboxChange}
                                    >
                                    </input>


                                </label>
                            </div>

                        </div>


                    </div>
                </div>
                <div>
                    <button
                        type="submit"
                        className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                    >
                        Save Member
                    </button>
                </div>
                {(status === 'Success') ? (
                    <div className="text-green-600">
                        <p className="mt-10 text-center text-sm/6 text-green-500">
                            {message}
                        </p>

                    </div>
                ) : (
                    <div>
                        <p className="mt-10 text-center text-sm/6 text-red-500">
                            {message}</p>
                    </div>
                )
                }
                <div className="mb-6 text-center">
                    {isLoading ? (
                        <ClipLoader color="#36D7B7" size={50} /> // Render the spinner component
                    ) : null}
                </div>
                <ToastContainer />
            </div>
        </form>


    );
} 