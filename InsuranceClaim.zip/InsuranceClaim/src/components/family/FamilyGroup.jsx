import FamilyMemberCard from './FamilyMemberCard';

const FamilyGroup = ({ title, members,onNotifyFamilyGroup }) => {

  
  const handleNotification = (dataFromChild) => {
    //console.log(`Child says: ${dataFromChild}`);
   notifyParent();
  };

   const notifyParent = () => {
    onNotifyFamilyGroup('Call_From_FamilyMemberCard!');
  };

  return (
    <div className="bg-gray-100 p-4 rounded-lg mb-6">
      <h2 className="text-xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-4">
        {members.map(member => (
        <FamilyMemberCard
        key={member.id}
        member={member.id}
        name={member.name}
        relation={member.relation}
        imageUrl={member.imageUrl}
        onNotify={handleNotification} 
        />
        ))}
      </div>
    </div>
  );
};

export default FamilyGroup;