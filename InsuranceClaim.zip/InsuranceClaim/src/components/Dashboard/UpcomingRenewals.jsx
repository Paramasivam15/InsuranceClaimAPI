import React from 'react';


export default function UpcomingRenewals({ paramUpcomingRenewals }) {
  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Upcoming Renewal</h1>     
       <p className="mt-1text-lg/8 text-gray-900">Your Primary: Athena Medical Insurance policy is due for renewal in 25 days.</p>
       </div>
    </header>
  );
}  