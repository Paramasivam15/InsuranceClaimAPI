import React from 'react';
import { useNavigate } from "react-router-dom";
import { useAuth } from '../authContext';

export default function WelcomeModule({ paramprofile }) {
  const navigate = useNavigate();
   const { user } = useAuth();
  localStorage.setItem("profilephoto", paramprofile.imageUrl);  

   
  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h3 className="text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-3xl">Welcome, {user.fname} {user.lname}!</h3>     
      
      <p >
          {user.isPasswordlinkShow ? (
                         <a href="/changePassword" className="font-semibold text-indigo-600 hover:text-indigo-500">Change your password </a>
                    ) : null}
         
       </p>
       </div>
    </header>
  );
}  