import React from 'react';
import { useNavigate } from "react-router-dom";

export default function WelcomeModule({ paramprofile }) {
  const navigate = useNavigate();
    console.log("profile name",paramprofile.firstName);
    console.log("profile",paramprofile.imageUrl);   
     console.log("profile isPasswordlinkShow",paramprofile.isPasswordlinkShow);
     localStorage.setItem("profilephoto", paramprofile.imageUrl);  

  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h3 className="text-4xl font-semibold tracking-tight text-pretty text-gray-900 sm:text-3xl">Welcome, {paramprofile.firstName}!</h3>     
       <p className="mt-1text-lg/8 text-gray-900">This is your personal dashboard. Tap your avatar to open settings, or use the tabs below to navigate the app.</p>
      <p >
          {paramprofile.isPasswordlinkShow ? (
                         <a href="/changePassword" className="font-semibold text-indigo-600 hover:text-indigo-500">Change your password </a>
                    ) : null}
         
       </p>
       </div>
    </header>
  );
}  