import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';


export default function DueVsPaidChart({ data, width, height}) {
  
     const chartRef = useRef();
  const tooltipRef = useRef();


  useEffect(() => {
    const svg = d3.select(chartRef.current);
    const tooltip = d3.select(tooltipRef.current);
    svg.selectAll('*').remove(); // clear previous render

    
    const margin = { top: 40, right: 30, bottom: 60, left: 60 };

    svg.attr('width', width).attr('height', height);

    const x0 = d3
      .scaleBand()
      .domain(data.map(d => d.name))
      .range([margin.left, width - margin.right])
      .paddingInner(0.2);

    const x1 = d3
      .scaleBand()
      .domain(['due', 'paid'])
      .range([0, x0.bandwidth()])
      .padding(0.1);

    const y = d3
      .scaleLinear()
      .domain([0, d3.max(data, d => Math.max(d.due, d.paid))])
      .nice()
      .range([height - margin.bottom, margin.top]);

    const color = d3.scaleOrdinal().domain(['due', 'paid']).range(['#3a0effff', '#1f77b4']);

    const bars = svg
      .append('g')
      .selectAll('g')
      .data(data)
      .join('g')
      .attr('transform', d => `translate(${x0(d.name)},0)`)
      .selectAll('rect')
      .data(d => ['due', 'paid'].map(key => ({ key, value: d[key], name: d.name })))
      .join('rect')
      .attr('x', d => x1(d.key))
      .attr('y', d => y(d.value))
      .attr('width', x1.bandwidth())
      .attr('height', d => y(0) - y(d.value))
      .attr('fill', d => color(d.key))
      .on('mouseover', (event, d) => {
        tooltip
          .style('opacity', 1)
          .html(`<strong>${d.name}</strong><br/>${d.key.toUpperCase()}: $${d.value}`)
          .style('left', event.pageX + 10 + 'px')
          .style('top', event.pageY - 28 + 'px');
      })
      .on('mousemove', event => {
        tooltip
          .style('left', event.pageX + 10 + 'px')
          .style('top', event.pageY - 28 + 'px');
      })
      .on('mouseout', () => {
        tooltip.style('opacity', 0);
      });

    // X Axis
    svg
      .append('g')
      .attr('transform', `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x0))
      .selectAll('text')
      .attr('dy', '1em')
      .attr('dx', '-1em')
      .attr('transform', 'rotate(-30)')
      .style('text-anchor', 'end');

    // Y Axis
    svg
      .append('g')
      .attr('transform', `translate(${margin.left},0)`)
      .call(d3.axisLeft(y));

    // Legend
    const legend = svg
      .append('g')
      .attr('transform', `translate(${width - 100}, ${margin.top})`);

    ['due', 'paid'].forEach((key, i) => {
      const g = legend.append('g').attr('transform', `translate(0, ${i * 20})`);
      g.append('rect').attr('width', 12).attr('height', 12).attr('fill', color(key));
      g.append('text').attr('x', 20).attr('y', 10).text(key).attr('fill', '#000');
    });
  }, []);
  
    return (   
         <div className="bg-white-500 text-white p-4 rounded-3xl  shadow-md">
         <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Owed by Type</h1>    
          <div className='justify-center flex w-full '>
                <div style={{ position: 'relative' }}>
                    <svg ref={chartRef}></svg>
                    <div ref={tooltipRef} />
                </div>
          </div>
         </div>
        
      
    );
};