import React from 'react';


export default function Credit_Balances({ paramCredit_Balances}) {
  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Credit Balances</h1>     
     
       </div>
    </header>
  );
}  