import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';


export default function TotalOwedChart({ data, width, height}) {

const svgRef = useRef();

  useEffect(() => {
    const svg = d3.select(svgRef.current)
      .attr("width", width)
      .attr("height", height);

    const radius = Math.min(width, height) / 2;
    const g = svg.append("g")
      .attr("transform", `translate(${width / 2}, ${height / 2})`);

    const color = d3.scaleOrdinal(d3.schemeCategory10); // Example color scheme

    const pie = d3.pie()
      .value(d => d.value)
      .sort(null); // To maintain data order

    const arc = d3.arc()
      .innerRadius(0) // For a standard pie chart
      .outerRadius(radius);

    const arcs = g.selectAll(".arc")
      .data(pie(data))
      .enter()
      .append("g")
      .attr("class", "arc");

    arcs.append("path")
      .attr("d", arc)
      .attr("fill", d => color(d.data.label)); // Assuming data has a 'label' property

    arcs.append("text")
      .attr("transform", d => `translate(${arc.centroid(d)})`)
      .attr("text-anchor", "middle")
      .text(d => d.data.label);

  }, [data, width, height]); // Redraw when data or dimensions change

  return (   
       <div className="bg-white-500 text-white p-4 rounded-3xl shadow-md">
       <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Total Owed by Member</h1>    
        <div className='justify-center flex w-full h-full'>
        <svg ref={svgRef}></svg></div>
       </div>
      
    
  );
}  