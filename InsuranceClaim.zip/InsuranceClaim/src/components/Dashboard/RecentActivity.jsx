import React from 'react';


export default function RecentActivity({ paramRecentActivity }) {
  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Recent Activity</h1>     
       <p className="mt-1text-lg/8 text-gray-900">You added "Home_Insurance.pdf" to your Vault.</p>
       </div>
    </header>
  );
}  