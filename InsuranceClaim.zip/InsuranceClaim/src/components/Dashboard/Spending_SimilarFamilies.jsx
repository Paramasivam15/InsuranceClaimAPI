import React from 'react';


export default function Spending_SimilarFamilies({ paramSpending_SimilarFamilies}) {
  return (
    <header className="top-0 w-full bg-white shadow z-50 p-4 flex rounded-3xl ">
       <div >
       <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Spending vs. Similar Families</h1>     
     
       </div>
    </header>
  );
}  