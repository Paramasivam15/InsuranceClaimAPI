import React, { useRef } from 'react';
import CanvasJSReact from '@canvasjs/react-charts';

export default function FamilySpending() {
const CanvasJSChart = CanvasJSReact.CanvasJSChart;

 let chartRef = null;
  const options = {
    theme: 'light2', // "light1", "dark1", "dark2"
    animationEnabled: true, //Change to false
    animationDuration: 1200, //Change it to 2000
    title: {
      text: '',
    },
    data: [
      {
        //Change type to "line", "bar", "area", "pie", etc.
        type: 'column',
        dataPoints: [
          { label: 'apple', y: 10 },
          { label: 'orange', y: 15 },
          { label: 'banana', y: 25 },
          { label: 'mango', y: 30 },
          { label: 'grape', y: 28 },
        ],
      },
    ],
  };

  const containerProps = {
    width: '100%',
    height: '360px',
    border: '1px solid black',
  };

 return (   
         <div className="bg-white-500 text-white p-4 rounded-3xl  shadow-md">
         <h1 className="text-2xl tracking-tight text-pretty text-gray-900 sm:text-1xl">Family Spending</h1>    
         <div className='justify-center flex w-full h-full'>

             <CanvasJSChart
                 options={options}
                 onRef={(ref) => (chartRef = ref)} // Reference to the chart-instance
                 containerProps={containerProps}
             />
         </div>
         </div>
        
      
    );

}