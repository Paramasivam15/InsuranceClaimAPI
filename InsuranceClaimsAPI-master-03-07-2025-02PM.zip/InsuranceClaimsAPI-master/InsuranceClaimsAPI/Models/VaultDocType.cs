﻿using System.ComponentModel.DataAnnotations;
namespace InsuranceClaimsAPI.Models
{
    public class VaultDocType
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string DocType { get; set; } = string.Empty;
    }
}
