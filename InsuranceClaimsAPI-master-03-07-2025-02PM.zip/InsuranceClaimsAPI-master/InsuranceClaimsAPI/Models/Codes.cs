﻿using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimsAPI.Models
{
    public class Codes
    {
        [Key]
        public int CodeID { get; set; }

        public int IsParentLinkID { get; set; }

        [MaxLength(50)]
        public string CodeType { get; set; } = string.Empty;

        [MaxLength(50)]
        public string CodeValue { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }





    }
}
