﻿using Azure.Core;
using InsuranceClaimsAPI.Data;
using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
namespace InsuranceClaimsAPI.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _context;
        private readonly IEmailService emailService;
        private readonly IPasswordService _passwordService;
        private readonly IConfiguration _configuration;

        public UserService(ApplicationDbContext context, IEmailService emailService, IPasswordService passwordService, IConfiguration configuration)
        {
            _context = context;
            this.emailService = emailService;
            _configuration = configuration;
            _passwordService = passwordService;
        }

        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _context.User
                .FirstOrDefaultAsync(u => u.EmailID == email && u.IsActive);
        }

        public async Task<MemberDto?> GetMemberById(Guid userId)
        {
            var memberdetails= await _context.Member
                .FirstOrDefaultAsync(u => u.MemberID == userId && u.IsActive);
            if (memberdetails == null)
                return null;

                return new MemberDto
            {

                MemberID = memberdetails.MemberID,
                FirstName = memberdetails.FirstName,
                LastName = memberdetails.LastName,
                Gender = memberdetails.Gender,
                EmailID = memberdetails.EmailID,
                DOB = memberdetails.DOB,
                MobileNo = memberdetails.MobileNo,
                IsActive = true,
                EmailConfirmed= memberdetails.EmailConfirmed,
                MobileNoConfirmed = memberdetails.MobileNoConfirmed,
                EmailConfirmationToken = memberdetails.EmailConfirmationToken,
                EmailConfirmationTokenExpiry = memberdetails.EmailConfirmationTokenExpiry,
                MobileConfirmationToken= memberdetails.MobileConfirmationToken,
                MobileConfirmationTokenExpiry= memberdetails.MobileConfirmationTokenExpiry,
                AddDate = DateTime.Now,
                ModifiedDate = DateTime.Now
            };
        }

        public async Task<List<string>> GetUserRolesAsync(Guid userId)
        {
            return await _context.UserRoleAssignment
                .Where(ura => ura.UserId == userId)
                .Include(ura => ura.Role)
                .Select(ura => ura.Role.RoleName)
                .ToListAsync();
        }


        public async Task<AuthResponseDto?> LoginAsync(string email, string password)
        {
            var userdetails = await _context.User
             .SingleOrDefaultAsync(m => m.EmailID == email);

            if (userdetails == null) return null;

            // Check if account is locked
            if (userdetails.IsLocked)
                return new AuthResponseDto{ message="User Locked"};
            // Verify password

            if (!_passwordService.VerifyPassword(password, userdetails.Password, userdetails.PasswordSalt))
            {
                // Increment failed attempts
                userdetails.FaiedLoginAttempt++;
                if (userdetails.FaiedLoginAttempt >= 3)
                {
                    userdetails.IsLocked = true;
                }
                await _context.SaveChangesAsync();
                return  new AuthResponseDto { message = "User credential is not matching" }; ;
            }

            var memberdetails = await _context.Member
                 .SingleOrDefaultAsync(m => m.UserID == userdetails.UserID);

            if (memberdetails != null)
            {
                // Generate tokens
                var jwtToken = GenerateJwtToken(memberdetails);
                var refreshToken = GenerateRandomToken();
                var expiresAt = DateTime.UtcNow.AddDays(1);

                // Reset failed attempts on successful login
                userdetails.FaiedLoginAttempt = 0;
                userdetails.IsLocked = false;
                userdetails.LastLoginDate = DateTime.UtcNow;
                userdetails.SessionToken = jwtToken;
                userdetails.RefreshToken = refreshToken;
                userdetails.ExpiresAt = expiresAt;
                _context.User.Update(userdetails);
                await _context.SaveChangesAsync();


                // Get user roles
                var roles = await GetUserRolesAsync(userdetails.UserID);

                return new AuthResponseDto
                {
                    UserId = userdetails.UserID,
                    Email = memberdetails.EmailID,
                    Token = userdetails.SessionToken,
                    RefreshToken = userdetails.RefreshToken,
                    FirstName = memberdetails.LastName,
                    LastName = memberdetails.LastName,
                    ExpiresAt = userdetails.ExpiresAt,
                    Roles = roles,
                    message = "Login successful."

                };
            }
            return null;
           
        }



        public async Task<AuthResponseDto?> VerifyToken(Guid userId, Boolean IswebToken,string Token)
        {    

          
            var memberdetails = await _context.Member
            .SingleOrDefaultAsync(m => m.MemberID == userId);

            if (memberdetails != null)
            {
                var salt = _passwordService.GenerateSalt();
                var passwordHash = _passwordService.HashPassword(Token, salt);

                // Generate tokens
                var jwtToken = GenerateJwtToken(memberdetails);
                var refreshToken = GenerateRandomToken();
                var expiresAt = DateTime.UtcNow.AddDays(1);
                //Create login user

                var user = new User
                {
                    EmailID = memberdetails.EmailID,
                    Password = passwordHash,
                    PasswordSalt = salt,
                    MobileNo = memberdetails.MobileNo,
                    IsUserLinkID = userId,
                    SessionToken = jwtToken,
                    RefreshToken = refreshToken,
                    ExpiresAt = expiresAt,
                    AddDate = new DateTime(),
                    IsActive = true,
                    LastLoginDate = new DateTime()
                };

                _context.User.Add(user);
                await _context.SaveChangesAsync();

                // Assign default role
                var userRole = await _context.UserRole.FirstOrDefaultAsync(r => r.RoleName == "User");
                if (userRole != null)
                {
                    var roleAssignment = new UserRoleAssignment
                    {
                        UserId = user.UserID,
                        RoleId = userRole.Id,
                        AssignedBy= user.UserID

                    };
                    _context.UserRoleAssignment.Add(roleAssignment);
                    await _context.SaveChangesAsync();
                }


                memberdetails.UserID= user.UserID;
                memberdetails.HasLogin = true ;
                if (IswebToken)
                    memberdetails.EmailConfirmed = true;
                else
                    memberdetails.MobileNoConfirmed = true;
                _context.Member.Update(memberdetails);
                await _context.SaveChangesAsync();

                // Get user roles
                var roles = await GetUserRolesAsync(user.UserID);


                return new AuthResponseDto
                {
                    UserId = user.UserID,
                    Email= memberdetails.EmailID,
                    Token = user.SessionToken,
                    RefreshToken = user.RefreshToken,
                    FirstName = memberdetails.LastName,
                    LastName= memberdetails.LastName,
                    ExpiresAt= user.ExpiresAt,
                    Roles = roles,
                    message = IswebToken ? "Email verified successfully." : "Mobile number verified successfully."
                };
            }
                return null;
        }

        public async Task<string> ForgotPasswordAsync(string email)
        {
            string validateMsg = string.Empty;
            try
            {

                var memberdetails = await _context.Member
                   .FirstOrDefaultAsync(u => u.EmailID == email && u.IsActive);
                if (memberdetails != null)
                {
                    memberdetails.EmailConfirmationToken = PasswordGenerator.Generate();
                    memberdetails.EmailConfirmationTokenExpiry = DateTime.Now.AddMinutes(60);
                    memberdetails.MobileConfirmationToken = Generaterandomnumber();
                    memberdetails.MobileConfirmationTokenExpiry = DateTime.Now.AddMinutes(60);
                    _context.Member.Update(memberdetails);
                    await _context.SaveChangesAsync();
                    //web Token
                    await SendOtpMail(memberdetails.EmailID, memberdetails.EmailConfirmationToken, string.Format("{0} {1}", memberdetails.FirstName, memberdetails.LastName));
                    //OTP
                    await SendOtpSMS(memberdetails.EmailID, memberdetails.MobileConfirmationToken, string.Format("{0} {1}", memberdetails.FirstName, memberdetails.LastName));
                    validateMsg = "Member password reset is done. Please check your email for confirmation link or OTP for mobile verification.";

                }
                else
                    validateMsg = "Member email is not found";

            }
            catch (Exception)
            {

                validateMsg = "Member password reset is failed";
            }


            return validateMsg;
        }
        public async Task<MemberDto> RegisterMemberAsync(RegisterDto registerDto)

        {
            string validateMsg=string.Empty;
            Guid newMemberID = Guid.Empty;
            try
            {
                //create member user
                var member = new Models.Member
                {
                    FirstName = registerDto.FirstName,
                    LastName = registerDto.LastName,
                    EmailID = registerDto.Email,
                    MobileNo = registerDto.Mobileno,
                    DOB = registerDto.DOB,
                    Gender = registerDto.Gender,
                    EmailConfirmationToken = PasswordGenerator.Generate(),
                    EmailConfirmationTokenExpiry = DateTime.Now.AddMinutes(60),
                    MobileConfirmationToken = Generaterandomnumber(),
                    MobileConfirmationTokenExpiry = DateTime.Now.AddMinutes(60),
                    IsActive = true,
                    AddDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                };

                _context.Member.Add(member);
                await _context.SaveChangesAsync();
                newMemberID= member.MemberID;
                if (newMemberID == Guid.Empty)
                {
                    validateMsg = "Member registration failed";
                }
                else
                {
                    //web Token
                    await SendOtpMail(member.EmailID, member.EmailConfirmationToken, string.Format("{0} {1}", member.FirstName, member.LastName));
                    //OTP
                    await SendOtpSMS(member.EmailID, member.MobileConfirmationToken, string.Format("{0} {1}", member.FirstName, member.LastName));
                    validateMsg = "Member registered successfully. Please check your email for confirmation link or OTP for mobile verification.";
                }


            }
            catch (Exception)
            {

                validateMsg = "Member registration failed";
            }

            return new MemberDto
            {

                MemberID = newMemberID,
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName,
                Gender = registerDto.Gender,
                EmailID = registerDto.Email,
                DOB = registerDto.DOB,
                MobileNo = registerDto.Mobileno,
                IsActive = true,
                AddDate = DateTime.Now,
                ModifiedDate = DateTime.Now,
                Message = validateMsg

            };
        }


        public async Task<bool> LockUserAsync(Guid userId)
        {
            var user = await _context.User.FindAsync(userId);
            if (user == null) return false;

            user.IsLocked = true;           

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UnlockUserAsync(Guid userId)
        {
            var user = await _context.User.FindAsync(userId);
            if (user == null) return false;

            user.IsLocked = false;          
            user.FaiedLoginAttempt = 0;

            await _context.SaveChangesAsync();
            return true;
        }


        public async Task<bool> EmailExistsAsync(string email)
        {
            return await _context.User.AnyAsync(u => u.EmailID == email);
        }

        public async Task<bool> MemberEmailExistsAsync(string email)
        {
            return await _context.Member.AnyAsync(u => u.EmailID == email);
        }


        public async Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken)
        {
            var user = await _context.User
                .FirstOrDefaultAsync(s => s.RefreshToken == refreshToken && s.IsActive && s.ExpiresAt > DateTime.UtcNow);

            if (user == null) return null;


            if (!user.IsActive || user.IsLocked) return null;

            var members = await _context.Member
               .FirstOrDefaultAsync(s => s.UserID.Equals(user.UserID));

            // Generate new tokens
            var newJwtToken = GenerateJwtToken(members);
            var newRefreshToken = GenerateRandomToken();
            var newExpiresAt = DateTime.UtcNow.AddDays(1);

            // Update session
            user.SessionToken = newJwtToken;
            user.RefreshToken = newRefreshToken;
            user.ExpiresAt = newExpiresAt;

            await _context.SaveChangesAsync();

            // Get user roles
            var roles = await GetUserRolesAsync(user.UserID);

            return new AuthResponseDto
            {
                UserId = user.UserID,
                Token = newJwtToken,
                RefreshToken = newRefreshToken,
                Email = user.EmailID,
                ExpiresAt = newExpiresAt,
                Roles = roles
            };
        }

        public async Task<bool> LogoutAsync(string sessionToken)
        {
            var session = await _context.User
                .FirstOrDefaultAsync(s => s.SessionToken == sessionToken && s.IsActive);

            if (session == null) return false;

            session.IsActive = false;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> ValidateTokenAsync(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!);

                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = _configuration["Jwt:Issuer"],
                    ValidateAudience = true,
                    ValidAudience = _configuration["Jwt:Audience"],
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                // Check if session exists and is active
                var session = await _context.User
                    .FirstOrDefaultAsync(s => s.SessionToken == token && s.IsActive && s.ExpiresAt > DateTime.UtcNow);

                return session != null;
            }
            catch
            {
                return false;
            }
        }


        private async Task SendOtpMail(string useremail, string OtpText, string Name)
        {
            var mailrequest = new Mailrequest();
            mailrequest.Email = useremail;
            mailrequest.Subject = "Thanks for registering : OTP";
            mailrequest.Emailbody = GenerateEmailBody(Name, OtpText);
            await this.emailService.SendEmailAsync(mailrequest);

        }

        private async Task SendOtpSMS(string useremail, string OtpText, string Name)
        {
            var mailrequest = new Mailrequest();
            mailrequest.Email = useremail;
            mailrequest.Subject = "Thanks for registering : OTP";
            mailrequest.Emailbody = GenerateEmailBody(Name, OtpText);
            await this.emailService.SendEmailAsync(mailrequest);

        }
        private string Generaterandomnumber()
        {
            Random random = new Random();
            string randomno = random.Next(0, 1000000).ToString("D6");
            return randomno;
        }

        private string GenerateEmailBody(string name, string otptext)
        {
            string emailbody = "<div style='width:100%;background-color:grey'>";
            emailbody += "<h1>Hi " + name + ", Thanks for registering</h1>";
            emailbody += "<h2>Please enter OTP text and complete the registration</h2>";
            emailbody += "<h2>OTP Text is :" + otptext + "</h2>";
            emailbody += "</div>";

            return emailbody;
        }

        private string GenerateJwtToken(Member Member)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, Member.MemberID.ToString()),
                new Claim(ClaimTypes.Name, Member.FirstName),
                new Claim(ClaimTypes.Email, Member.EmailID),
                new Claim("FirstName", Member.FirstName),
                new Claim("LastName", Member.LastName)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(24),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public string GenerateRandomToken()
        {
            using (var rng = RandomNumberGenerator.Create())
            {
                var tokenBytes = new byte[64];
                rng.GetBytes(tokenBytes);
                return Convert.ToBase64String(tokenBytes);
            }
        }




    }

}

