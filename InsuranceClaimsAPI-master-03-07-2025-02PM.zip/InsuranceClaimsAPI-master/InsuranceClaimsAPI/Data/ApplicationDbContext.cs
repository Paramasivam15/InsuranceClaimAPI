﻿using InsuranceClaimsAPI.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;
using System.Reflection.Emit;
namespace InsuranceClaimsAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> User { get; set; }

        public DbSet<RelationshipType> RelationshipType { get; set; }
        public DbSet<PolicyType> PolicyType { get; set; }

        public DbSet<BenefitType> BenefitType { get; set; }

        public DbSet<VaultDocType> VaultDocType { get; set; }

        public DbSet<VaultReceiverType> VaultReceiverType { get; set; }

        public DbSet<Codes> Codes { get; set; }

        public DbSet<Zipcodes> Zipcodes { get; set; }


        public DbSet<PaymentType> PaymentType { get; set; }

        public DbSet<Member> Member { get; set; }

        public DbSet<UserRole> UserRole { get; set; }
        public DbSet<UserRoleAssignment> UserRoleAssignment { get; set; }




        /*

        public DbSet<MemberInsurance> MemberInsurance { get; set; }

        public DbSet<MemberInsEligibility> MemberInsEligibility { get; set; }



      

        public DbSet<MemberLedger> MemberLedger { get; set; }

        public DbSet<MemberLedgerDetails> MemberLedgerDetails { get; set; }

  
        public DbSet<MemberScoreCard> MemberScoreCard { get; set; }

            public DbSet<MemVault> MemVault { get; set; }

       */











        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure tblLogin entity
            builder.Entity<User>()
               .Property(b => b.UserID)
               .HasDefaultValueSql("NEWID()");

            // Configure tblMember entity
            builder.Entity<Member>()
                 .Property(b => b.MemberID)
               .HasDefaultValueSql("NEWID()");

            // Configure tblCodes entity
            builder.Entity<Codes>()
                .HasIndex(u => u.CodeID)
                .IsUnique();

            // Configure tblZipcodes entity
            builder.Entity<Zipcodes>()
                .HasIndex(u => u.ZipIntID)
                .IsUnique();

            // Configure tblPaymentType entity
            builder.Entity<PaymentType>()
                .HasIndex(u => u.Id)
                .IsUnique();


            // Configure TblRelationshipType entity
            builder.Entity<RelationshipType>()
                .HasIndex(u => u.Id)
                .IsUnique();

            // Configure tblPolicyType entity
            builder.Entity<PolicyType>()
                .HasIndex(u => u.Id)
                .IsUnique();

            // Configure tblPolicyType entity
            builder.Entity<BenefitType>()
                .HasIndex(u => u.Id)
                .IsUnique();

            // Configure tblDocType entity
            builder.Entity<VaultDocType>()
                .HasIndex(u => u.Id)
                .IsUnique();

            // Configure tblVaultReceiverType entity
            builder.Entity<VaultReceiverType>()
                .HasIndex(u => u.Id)
                .IsUnique();         

            // Configure UserRoleAssignment composite key
            builder.Entity<UserRoleAssignment>()
                .HasKey(ura => new { ura.UserId, ura.RoleId });

            builder.Entity<UserRoleAssignment>()
                .HasOne(ura => ura.User)
                .WithMany(u => u.UserRoleAssignments)
                .HasForeignKey(ura => ura.UserId);

            builder.Entity<UserRoleAssignment>()
                .HasOne(ura => ura.Role)
                .WithMany(r => r.UserRoleAssignments)
                .HasForeignKey(ura => ura.RoleId);

            // Seed Countries Master Data
            builder.Entity<UserRole>().HasData(
                new UserRole { Id=1, RoleName = "Admin", Description = "Admin", IsActive = true },
                new UserRole { Id=2,RoleName = "User", Description = "User", IsActive = true }
            );

            /*
                        // Configure MemberInsurance entity
                        builder.Entity<MemberInsurance>()
                            .HasIndex(u => u.MemInsID)
                            .IsUnique();

                        // Configure MemberInsurance entity
                        builder.Entity<MemberInsEligibility>()              
                            .HasIndex(u => u.MemInsEliID)
                            .IsUnique();             

                        // Configure MemberLedger entity
                        builder.Entity<MemberLedger>()
                            .HasIndex(u => u.MemLedID)
                            .IsUnique();


                        // Configure MemberLedgerDetails entity
                        builder.Entity<MemberLedgerDetails>()
                            .HasIndex(u => u.MemLDID)
                            .IsUnique();


                        // Configure MemberScoreCard entity
                        builder.Entity<MemberScoreCard>()
                            .HasIndex(u => u.MemSCID)
                            .IsUnique();

                         // Configure tblMemVault entity
                        builder.Entity<MemVault>()
                            .HasIndex(u => u.MemVaultID)
                            .IsUnique();
            */

        }


    }
    }
