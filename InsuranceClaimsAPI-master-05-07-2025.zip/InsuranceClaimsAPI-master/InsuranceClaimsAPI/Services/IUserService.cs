﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
namespace InsuranceClaimsAPI.Services
{
    public interface IUserService
    {
        Task<User?> GetUserByEmailAsync(string email);
        Task<List<string>> GetUserRolesAsync(Guid userId);

        Task<MemberDto?> GetMemberById(Guid userId);
        Task<MemberDto?> GetMemberByUserEmailAsync(Guid userId, string email);
        Task<AuthResponseDto?> LoginAsync(string email, string password);
        Task<AuthResponseDto?> VerifyToken(Guid userId, Boolean IswebToken, string Token);
        Task<MemberDto> RegisterMemberAsync(RegisterDto registerDto);

        Task<string> ForgotPasswordAsync(string email);

        Task<string> ChangePasswordAsync(Guid userId, ChangePasswordDto changePasswordDto);

        Task<bool> EmailExistsAsync(string email);
        Task<bool> MemberEmailExistsAsync(string email);

        Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken);
        Task<bool> LogoutAsync(string sessionToken);
        Task<bool> ValidateTokenAsync(string token);

        Task<bool> LockUserAsync(Guid userId);

        Task<bool> UnlockUserAsync(Guid userId);



    }

}
