﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using InsuranceClaimsAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System.Security.Claims;
namespace InsuranceClaimsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController] 
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto login)
        {
            if (string.IsNullOrEmpty(login.Email) || string.IsNullOrEmpty(login.Password))
                return BadRequest("Invalid login data");
            var result = await _userService.LoginAsync(login.Email, login.Password);
            if (result == null)
                return BadRequest("User login failed");
          
            return Ok(result);
        }

        [HttpPost("Verify-Email")]
        public async Task<ActionResult<AuthResponseDto>> VerifyEmail(Guid memberId, string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Invalid Token data");

            var memberdetails = await _userService.GetMemberById(memberId);

            if (memberdetails != null)
            {
                if (memberdetails.IsActive == false)
                {
                    return BadRequest("Member is not active");
                }
                else if (memberdetails.EmailConfirmed == true || memberdetails.MobileNoConfirmed == true)
                    return BadRequest("Already Token is registered");

                if (memberdetails.EmailConfirmationToken != token)
                    return BadRequest("Web Token is not matching");

                    if (memberdetails.EmailConfirmationTokenExpiry < DateTime.Now)
                    {
                        return BadRequest("Web Token is expired");
                    }               

            }
            else
                return BadRequest("Member is not found");

            var result = await _userService.VerifyToken(memberId, true, token);
            if (result == null)
                return BadRequest("User login Registration failed");
            return Ok(result);

        }

        [HttpPost("Verify-Mobile")]
        public async Task<ActionResult<AuthResponseDto>> VerifyMobile(Guid memberId, string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Invalid Token data");

            var memberdetails = await _userService.GetMemberById(memberId);

            if (memberdetails != null)
            {
                if (memberdetails.IsActive == false)
                {
                    return BadRequest("Member is not active");
                }
                else if (memberdetails.EmailConfirmed == true || memberdetails.MobileNoConfirmed == true)
                    return BadRequest("Already Token is registered");


                if (memberdetails.MobileConfirmationToken != token)
                {
                    return BadRequest("Mobile OTP Token is not matching");
                }
                if (memberdetails.MobileConfirmationTokenExpiry < DateTime.Now)
                {
                    return BadRequest("Mobile OTP Token is expired");
                }

            }
            else
                return BadRequest("Member is not found");

            var result = await _userService.VerifyToken(memberId, false, token);
            if (result == null)
                return BadRequest("User login Registration failed");
            return Ok(result);

        }

       [HttpPost("Register")]
        public async Task<ActionResult<MemberDto>> Register([FromBody] RegisterDto registerDto)
        {
            if (registerDto == null)
                return BadRequest("Invalid registration data");

            if (await _userService.MemberEmailExistsAsync(registerDto.Email))
                return BadRequest("Email exists"); 



            var result = await _userService.RegisterMemberAsync(registerDto);
            if (result == null)
                return BadRequest("User already exists or registration failed");

            return Ok(result);
        }

        [HttpPost("ForgotPasswordAsync")]
        public async Task<IActionResult> ForgotPasswordAsync(string email)
        {          
            var strMessage = await _userService.ForgotPasswordAsync(email);          
            return Ok(new { message = strMessage });

        }

        [HttpPost("ChangePasswordAsync")]
        public async Task<IActionResult> ChangePasswordAsync(Guid userId, ChangePasswordDto changePasswordDto)
        {
            var strMessage = await _userService.ChangePasswordAsync(userId, changePasswordDto);
            return Ok(new { message = strMessage });

        }


        [HttpPost("LockUserAsync")]
        public async Task<IActionResult> LockUserAsync(Guid userId)
        {
            string strMessage= string.Empty;
            var isValid = await _userService.LockUserAsync(userId);
            strMessage = isValid ? "User locked successfully" : "Failed to lock user";
            return Ok(new { message = strMessage });

        }

        [HttpPost("UnlockUserAsync")]
        public async Task<IActionResult> UnlockUserAsync(Guid userId)
        {
            string strMessage = string.Empty;
            var isValid = await _userService.UnlockUserAsync(userId);
            strMessage = isValid ? "User Unlocked successfully" : "Failed to Unlock user";
            return Ok(new { message = strMessage });

        }


        [HttpGet("GetMemberByIdAsync")]
        public async Task<ActionResult<MemberDto>> GetMemberById(Guid memberId)
        {
            var result = await _userService.GetMemberById(memberId);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("GetMemberByUserEmailAsync")]
    

        public async Task<ActionResult<MemberDto>> GetMemberByUserEmailAsync(Guid userId,string email)
        {
            var result = await _userService.GetMemberByUserEmailAsync(userId, email);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var memberID = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var result = await _userService.GetMemberById(newGuid);
                if (result == null)
                    return BadRequest("No Members found");
                return Ok(new { result.FirstName, result.EmailID });
            }
            return BadRequest("Invalid user ID on JWT Token");
        }


        [HttpGet("ValidateJWTToken")]
        public async Task<ActionResult<string>> ValidateJWTToken(string jWTtoken)
        {
            string strresult= string.Empty;
            if (string.IsNullOrEmpty(jWTtoken))
                return BadRequest("Invalid Token data");
            var result = await _userService.ValidateTokenAsync(jWTtoken);           
            strresult = (result) ? "JWT Token is valid" : "JWT Token is invalid";

            if (!result)
                return BadRequest("JWT Token is invalid");
            return Ok(strresult);
        }

        [HttpGet("RefreshTokenAsync")]
        public async Task<ActionResult<AuthResponseDto>> RefreshTokenAsync(string refreshToken)
        {
            if (!string.IsNullOrEmpty(refreshToken))
                return BadRequest("Invalid Token data");
            var result = await _userService.RefreshTokenAsync(refreshToken);
            if (result == null)
                return BadRequest("refreshToken is not completed successfully");
            return Ok(result);
        }

    }
}
