﻿using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimsAPI.DTO
{
    public class AuthDtos
    {

    }
    public class LoginDto
    {      
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

    }

    public class MemberDto
    {
        public string Message { get; set; } = string.Empty;
        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }
     
        public string FirstName { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public string? Gender { get; set; }


        public DateTime DOB { get; set; }

        public Boolean EmailConfirmed { get; set; }

        public string EmailConfirmationToken { get; set; } = string.Empty;

        public DateTime EmailConfirmationTokenExpiry { get; set; }


        public Boolean MobileNoConfirmed { get; set; }

        public string MobileConfirmationToken { get; set; } = string.Empty;

        public DateTime MobileConfirmationTokenExpiry { get; set; }


        public string MobileNo { get; set; } = string.Empty;

        public string EmailID { get; set; } = string.Empty;

        [MaxLength(250)]
        public string? Address1 { get; set; }

       
        public string? Address2 { get; set; }

    
        public string? City { get; set; }

    
        public string? State { get; set; }


        public string? ZipCode { get; set; }

   
        public string? Country { get; set; }

        public int? ZipIntID { get; set; }

        public int? RelationshipTypeID { get; set; }


        public Boolean IsPrimaryMem { get; set; }

        public Boolean HasLogin { get; set; }

        public string? MemberPhotoURL { get; set; }

        public DateTime AddDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? AddedBy { get; set; }
        public string? ModifiedBy { get; set; }

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }
    }

        public class RegisterDto
    {    
        public string Email { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;

        public DateTime DOB { get; set; }

        public string Gender { get; set; } = string.Empty;

        public string Mobileno { get; set; } = string.Empty;

      
    }

    public class AuthResponseDto
    {
        public Guid UserId { get; set; }
        public Guid MemberId { get; set; } 
        public string Token { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        public DateTime ExpiresAt { get; set; }

        public List<string> Roles { get; set; } = new List<string>();


        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? ProfileImageUrl { get; set; }

        public string message { get; set; } = string.Empty;


    }

    public class ChangePasswordDto
    {
        public string CurrentPassword { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class ForgotPasswordDto
    {
        public string Email { get; set; } = string.Empty;
    }

    public class ResetPasswordDto
    {
        public string Email { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
    }

}
