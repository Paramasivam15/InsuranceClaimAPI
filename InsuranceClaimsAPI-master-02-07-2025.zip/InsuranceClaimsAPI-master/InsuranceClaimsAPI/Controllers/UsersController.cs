﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using InsuranceClaimsAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
namespace InsuranceClaimsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController] 
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponseDto>> Login(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                return BadRequest("Invalid login data");
            var result = await _userService.LoginAsync(email, password);
            if (result == null)
                return BadRequest("User login failed");
          
            return Ok(result);
        }

        [HttpPost("Verify-Email")]
        public async Task<ActionResult<AuthResponseDto>> VerifyEmail(Guid memberId, string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Invalid Token data");

            var memberdetails = await _userService.GetMemberById(memberId);

            if (memberdetails != null)
            {
                if (memberdetails.IsActive == false)
                {
                    return BadRequest("Member is not active");
                }
              
                    if (memberdetails.EmailConfirmationToken != token)
                        return BadRequest("Web Token is not matching");

                    if (memberdetails.EmailConfirmationTokenExpiry < DateTime.Now)
                    {
                        return BadRequest("Web Token is expired");
                    }               

            }
            else
                return BadRequest("Member is not found");

            var result = await _userService.VerifyToken(memberId, true, token);
            if (result == null)
                return BadRequest("User login Registration failed");
            return Ok(result);

        }

        [HttpPost("Verify-Mobile")]
        public async Task<ActionResult<AuthResponseDto>> VerifyMobile(Guid memberId, string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Invalid Token data");

            var memberdetails = await _userService.GetMemberById(memberId);

            if (memberdetails != null)
            {
                if (memberdetails.IsActive == false)
                {
                    return BadRequest("Member is not active");
                }


                if (memberdetails.MobileConfirmationToken != token)
                {
                    return BadRequest("Mobile OTP Token is not matching");
                }
                if (memberdetails.MobileConfirmationTokenExpiry < DateTime.Now)
                {
                    return BadRequest("Mobile OTP Token is expired");
                }

            }
            else
                return BadRequest("Member is not found");

            var result = await _userService.VerifyToken(memberId, false, token);
            if (result == null)
                return BadRequest("User login Registration failed");
            return Ok(result);

        }

            [HttpPost("Register")]
        public async Task<ActionResult<MemberDto>> Register(RegisterDto registerDto)
        {
            if (registerDto == null)
                return BadRequest("Invalid registration data");         

            var result = await _userService.RegisterMemberAsync(registerDto);
            if (result == null)
                return BadRequest("User already exists or registration failed");

            return Ok(result);
        }

        [HttpGet("GetMemberById")]
        public async Task<ActionResult<MemberDto>> GetMemberById(Guid userId)
        {
            var result = await _userService.GetMemberById(userId);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("ValidateJWTToken")]
        public async Task<ActionResult<string>> ValidateJWTToken(string jWTtoken)
        {
            string strresult= string.Empty;
            if (string.IsNullOrEmpty(jWTtoken))
                return BadRequest("Invalid Token data");
            var result = await _userService.ValidateTokenAsync(jWTtoken);           
            strresult = (result) ? "JWT Token is valid" : "JWT Token is invalid";

            if (!result)
                return BadRequest("JWT Token is invalid");
            return Ok(strresult);
        }

        [HttpGet("GetUserByEmail")]
        public async Task<ActionResult<AuthResponseDto>> RefreshTokenAsync(string refreshToken)
        {
            if (!string.IsNullOrEmpty(refreshToken))
                return BadRequest("Invalid Token data");
            var result = await _userService.RefreshTokenAsync(refreshToken);
            if (result == null)
                return BadRequest("refreshToken is not completed successfully");
            return Ok(result);
        }

    }
}
