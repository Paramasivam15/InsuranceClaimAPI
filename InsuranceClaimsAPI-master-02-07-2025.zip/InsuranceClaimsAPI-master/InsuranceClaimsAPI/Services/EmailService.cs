﻿using AutoMapper.Internal;
using InsuranceClaimsAPI.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;

namespace InsuranceClaimsAPI.Services
{
    public class EmailService : IEmailService
    {
        private  EmailSettings emailSettings;
        public EmailService(IOptions<EmailSettings> options)
        {
            this.emailSettings = options.Value;
        }

        public async Task SendEmailAsync(Mailrequest mailrequest)
        {
            try
            {

                if (mailrequest == null || string.IsNullOrEmpty(mailrequest.Email) || string.IsNullOrEmpty(mailrequest.Subject) || string.IsNullOrEmpty(mailrequest.Emailbody))
                {
                    throw new ArgumentException("Invalid mail request");
                }
                var smtpClient = new SmtpClient(emailSettings.SmtpServer, emailSettings.SmtpPort)
                {
                    Credentials = new NetworkCredential(emailSettings.SmtpUsername, emailSettings.SmtpPassword),
                    EnableSsl = emailSettings.EnableSsl,
                    DeliveryMethod = SmtpDeliveryMethod.Network
                };

                using (var message = new MailMessage(emailSettings.SmtpUsername, mailrequest.Email)
                {

                    Subject = mailrequest.Subject,
                    Body = mailrequest.Emailbody,
                    IsBodyHtml = true // Or false if not HTML
                })
                {
                    await smtpClient.SendMailAsync(message);
                }
            }
            catch (Exception)
            {

                
            }
        }
    }
}
