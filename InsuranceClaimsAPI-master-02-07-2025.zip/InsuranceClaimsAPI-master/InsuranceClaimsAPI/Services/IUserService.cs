﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
namespace InsuranceClaimsAPI.Services
{
    public interface IUserService
    {
        Task<User?> GetUserByEmailAsync(string email);
        Task<List<string>> GetUserRolesAsync(Guid userId);

        Task<MemberDto?> GetMemberById(Guid userId);
        Task<AuthResponseDto?> LoginAsync(string email, string password);
        Task<AuthResponseDto?> VerifyToken(Guid userId, Boolean IswebToken, string Token);
        Task<MemberDto> RegisterMemberAsync(RegisterDto registerDto);

        Task<bool> EmailExistsAsync(string email);

        Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken);
        Task<bool> LogoutAsync(string sessionToken);
        Task<bool> ValidateTokenAsync(string token);




    }

}
