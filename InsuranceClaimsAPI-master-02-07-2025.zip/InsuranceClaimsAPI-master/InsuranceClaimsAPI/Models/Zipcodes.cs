﻿using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimsAPI.Models
{
    public class Zipcodes
    {

        [Key]
        public int ZipIntID { get; set; }

        [MaxLength(10)]
        public string ZIPCode { get; set; } = string.Empty;

        [MaxLength(50)]
        public string ZIPType { get; set; } = string.Empty;

        [MaxLength(50)]
        public string CityName { get; set; } = string.Empty;

        [MaxLength(50)]
        public string CityType { get; set; } = string.Empty;

        [MaxLength(50)]
        public string StateName { get; set; } = string.Empty;

        [MaxLength(10)]
        public string StateAbbr { get; set; } = string.Empty;

        [MaxLength(10)]
        public string AreaCode { get; set; } = string.Empty;

        [MaxLength(10)]
        public string Latitude { get; set; } = string.Empty;

        [MaxLength(10)]
        public string Longitude { get; set; } = string.Empty;

        [MaxLength(50)]
        public string Country { get; set; } = string.Empty;

        [MaxLength(10)]
        public string ZIPExtn { get; set; } = string.Empty;
                

    }
}
