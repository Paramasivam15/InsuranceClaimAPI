﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Emit;
namespace InsuranceClaimsAPI.Models
{
    public class MemberInsEligibility
    {

        [Key]
        public int MemInsEliID { get; set; }
        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }

        public int MemInsID { get; set; }

        public Boolean IsInsActive { get; set; }

        public DateTime InsActiveDateFrom { get; set; }

        public DateTime InsActiveDateTo { get; set; }

        [MaxLength(50)]
        public string PhyCopay { get; set; } = string.Empty;

        [MaxLength(50)]
        public string PhyDeductable { get; set; } = string.Empty;

        [MaxLength(50)]
        public string PhyCoIns { get; set; } = string.Empty;

        [MaxLength(50)]
        public string FacCopay { get; set; } = string.Empty;


        [MaxLength(50)]
        public string FacDeductable { get; set; } = string.Empty;


        [MaxLength(50)]
        public string FacCoIns { get; set; } = string.Empty;


        [MaxLength(50)]
        public string FamilyDeductable { get; set; } = string.Empty;


        [MaxLength(50)]
        public string OOPIndividual { get; set; } = string.Empty;


        [MaxLength(50)]
        public string OOPFamily { get; set; } = string.Empty;


        [MaxLength(50)]
        public string EligibilityChkDate { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("UserID")]
        public virtual User User { get; set; } = null!;

        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;


        [ForeignKey("MemInsID")]
        public virtual MemberInsurance MemberInsurance { get; set; } = null!;


    }
}
