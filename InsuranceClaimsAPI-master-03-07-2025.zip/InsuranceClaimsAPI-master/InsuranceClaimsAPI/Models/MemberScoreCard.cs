﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace InsuranceClaimsAPI.Models
{
    public class MemberScoreCard
    {

        [Key]
        public int MemSCID { get; set; }
        public int MemLedID { get; set; }
        public int MemLDID { get; set; }

        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }

        public int MemVaultID { get; set; }
       
        [MaxLength(100)]
        public string SecB { get; set; }=string.Empty;

        [MaxLength(100)]
        public string SecC { get; set; } = string.Empty;

        [MaxLength(100)]
        public string SecCProvider { get; set; } = string.Empty;


        [MaxLength(100)]
        public string SecCInsurance { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("UserID")]
        public virtual User Login { get; set; } = null!;

        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;

        [ForeignKey("MemVaultID")]
        public virtual MemVault tblMemVault { get; set; } = null!;

        [ForeignKey("MemLDID")]
        public virtual MemberLedgerDetails MemberLedgerDetails { get; set; } = null!;

        [ForeignKey("MemLedID")]
        public virtual MemberLedger MemberLedger { get; set; } = null!;


    }
}
