﻿namespace InsuranceClaimsAPI.Models
{
    public class Mailrequest
    {
        public string Email { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string Emailbody { get; set; } = string.Empty;
    }
}
