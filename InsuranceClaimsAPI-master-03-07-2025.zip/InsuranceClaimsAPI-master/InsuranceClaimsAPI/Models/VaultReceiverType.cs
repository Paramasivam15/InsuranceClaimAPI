﻿using System.ComponentModel.DataAnnotations;
namespace InsuranceClaimsAPI.Models
{
    public class VaultReceiverType
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string ReceiverType { get; set; } = string.Empty;

    }
}
