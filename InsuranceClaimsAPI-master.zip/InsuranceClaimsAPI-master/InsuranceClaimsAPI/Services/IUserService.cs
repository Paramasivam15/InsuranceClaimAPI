﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using Microsoft.AspNetCore.Mvc;
namespace InsuranceClaimsAPI.Services
{
    public interface IUserService
    {
        Task<User?> GetUserByEmailAsync(string email);
        Task<List<string>> GetUserRolesAsync(Guid userId);

        Task<MemberDto?> GetMemberById(Guid userId);
        Task<MemberDto?> GetMemberByUserEmailAsync(Guid userId, string email);
        Task<AuthResponseDto?> LoginAsync(string mobileno,string email, string password);
        Task<AuthResponseDto> VerifyToken(Guid userId, Boolean IswebToken, string Token);
        Task<MemberDto> RegisterMemberAsync(RegisterDto registerDto);
        Task<MemberDto> SaveMemberAsync(MemberDto MemberDto);
        Task<List<MemberDto>> GetFamilyDepedent(string email);

        Task<string> ForgotPasswordAsync(string email);

        Task<string> ChangePasswordAsync(ChangePasswordDto changePasswordDto);

        Task<bool> EmailExistsAsync(string email);
        Task<bool> MemberEmailExistsAsync(string email);

        Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken);
        Task<bool> LogoutAsync(string sessionToken);
        Task<bool> ValidateTokenAsync(string token);

        Task<bool> LockUserAsync(Guid userId);

        Task<bool> UnlockUserAsync(Guid userId);
        Task<List<RelationshipTypeDto>> GetRelationshipType();

        Task<List<MemberDto>> GetFamilyDepedentFormattedData(string email);




    }

}
