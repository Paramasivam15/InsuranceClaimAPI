﻿using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using Microsoft.AspNetCore.Mvc;
namespace InsuranceClaimsAPI.Services
{
    public interface IUserService
    {
        Task<User?> GetUserByEmailAsync(string email);
        Task<List<string>> GetUserRolesAsync(Guid userId);

        Task<MemberDto?> GetMemberById(Guid userId);
        Task<MemberDto?> GetMemberByUserEmailAsync(Guid userId, string email);
        Task<AuthResponseDto?> LoginAsync(string mobileno,string email, string password);
        Task<AuthResponseDto> VerifyToken(Guid userId, Boolean IswebToken, string Token);
        Task<MemberDto> RegisterMemberAsync(RegisterDto registerDto);
        Task<MemberDto> SaveMemberAsync(MemberDto MemberDto);
        Task<MemberDto> DeleteMemberAsync(Guid MemberId);
        Task<List<MemberDto>> GetFamilyDepedent(Guid memberID);
        Task<List<MemberDto>> GetFamilyDepedentFormattedData(Guid memberID);

        Task<string> ForgotPasswordAsync(string email);

        Task<ChangePasswordDto> ChangePasswordAsync(ChangePasswordDto changePasswordDto);

        Task<bool> EmailExistsAsync(string email);
        Task<bool> MemberEmailExistsAsync(string email);

        Task<AuthResponseDto?> RefreshTokenAsync(string refreshToken);
        Task<bool> LogoutAsync(string sessionToken);
        Task<bool> ValidateTokenAsync(string token);

        Task<bool> LockUserAsync(Guid userId);

        Task<bool> UnlockUserAsync(Guid userId);
        Task<List<RelationshipTypeDto>> GetRelationshipType();

      

        Task<List<string>> GetDistinctState();
        Task<List<ZipcodeDTO>> GetDistinctZipbyState(string strState);

        Task<ZipcodeDTO> GetZipDatabyCode(string zipcode);




    }

}
