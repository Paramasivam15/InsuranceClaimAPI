﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace InsuranceClaimsAPI.Models
{
    public class MemberLedgerDetails
    {

        [Key]
        public int MemLDID { get; set; }

        public int MemLedID { get; set; }

        public Guid MemberID { get; set; }

        public Guid UserID { get; set; }

        public int MemVaultID { get; set; }

        [MaxLength(100)] 
        public string CPTs { get; set; } =string.Empty;

        public int PaymentTypeID { get; set; }

        public int BilledAmt { get; set; }
        public int AllowedAmt { get; set; }
        public int Dedectable { get; set; }

        public string Copay { get; set; } = string.Empty;
        public string CoIns { get; set; } = string.Empty;
        public string PatResponsibility { get; set; } = string.Empty;

        public int InsPaidAmt { get; set; }

        public int InsAdjAmt { get; set; }

        public string PatOwe     { get; set; } = string.Empty;

        public int PatPaidAmt { get; set; }

        public string ReviewComments { get; set; } = string.Empty;

        public Boolean IsDuplicate { get; set; }

        public string AdditionalNotes { get; set; } = string.Empty;

        public DateTime AddDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string AddedBy { get; set; } = string.Empty;
        public string ModifiedBy { get; set; } = string.Empty;

        public Boolean IsActive { get; set; }
        public bool IsDelete { get; set; }



        [ForeignKey("UserID")]
        public virtual User User { get; set; } = null!;

        [ForeignKey("MemberID")]
        public virtual Member Member { get; set; } = null!;

        [ForeignKey("MemVaultID")]
        public virtual MemVault MemVault { get; set; } = null!;


        [ForeignKey("PaymentTypeID")]
        public virtual PaymentType PaymentType { get; set; } = null!;



    }
}
