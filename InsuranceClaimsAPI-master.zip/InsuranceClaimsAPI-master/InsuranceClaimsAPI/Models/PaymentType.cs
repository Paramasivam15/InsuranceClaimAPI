﻿using System.ComponentModel.DataAnnotations;
namespace InsuranceClaimsAPI.Models
{
    public class PaymentType
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Type { get; set; } = string.Empty;
    }
}
