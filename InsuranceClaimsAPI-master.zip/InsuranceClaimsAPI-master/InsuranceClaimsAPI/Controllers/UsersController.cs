﻿using AutoMapper.Execution;
using Azure.Core;
using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using InsuranceClaimsAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace InsuranceClaimsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController] 
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly string _profilestoragePath;
        private readonly string _documentstoragePath;

        public UsersController(IUserService userService, IOptions<FileStorageOptions> options)
        {
            _userService = userService;
            _profilestoragePath = Path.Combine(options.Value.ProfilePhotoPath, "Profile");
            _documentstoragePath = Path.Combine(options.Value.ProfilePhotoPath, "Documents");
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto login)
        {
            
            if (string.IsNullOrEmpty(login.memberId))
            {
                if(login.selectedTab == "web")
                {
                    if (string.IsNullOrEmpty(login.Email) || string.IsNullOrEmpty(login.Password))
                        return Ok(new AuthResponseDto { status = "Error", message = "Invalid login data" });
                }
                else
                {
                    if (string.IsNullOrEmpty(login.Mobile) || string.IsNullOrEmpty(login.OTP))
                        return Ok(new AuthResponseDto { status = "Error", message = "Invalid login data" });
                }
                var result = await _userService.LoginAsync(login.Mobile, login.Email, (login.selectedTab == "web") ? login.Password : login.OTP);
                return Ok(result);
            }
            else
            {
                //Verify the token for the member and continue login               
                if (Guid.TryParse(login.memberId, out var newGuid))
                {
                   var verifyTokenResult = await _userService.VerifyToken(newGuid, (login.selectedTab == "web")?true:false, (login.selectedTab == "web") ? login.Password : login.OTP);
                   return Ok(verifyTokenResult);
                }
            }
            return null;
        }

        [HttpPost("VerifyEmail")]
        public async Task<ActionResult<AuthResponseDto>> VerifyEmail([FromBody] TokenDto tokenDTO)
        {
            string validationMessage  = string.Empty;string status = "Error";
            if (tokenDTO == null)
                return BadRequest("Invalid Token data");
            else if (string.IsNullOrEmpty(tokenDTO.memberId))
                return BadRequest(" MemberId is required");
            else if (string.IsNullOrEmpty(tokenDTO.token))
                return BadRequest("Token is required");

            //Verify the token for the member and continue login               
            if (Guid.TryParse(tokenDTO.memberId, out var newGuid))
            {
                var verifyTokenResult = await _userService.VerifyToken(newGuid,true , tokenDTO.token);
                return Ok(verifyTokenResult);
            }
            return null;
        }

        [HttpPost("VerifyMobile")]
        public async Task<ActionResult<AuthResponseDto>> VerifyMobile([FromBody] TokenDto tokenDTO)
        {
            string validationMessage = string.Empty; string status = "Error";
            if (tokenDTO == null)
                return BadRequest("Invalid Token data");
            else if (string.IsNullOrEmpty(tokenDTO.memberId))
                return BadRequest(" MemberId is required");
            else if (string.IsNullOrEmpty(tokenDTO.token))
                return BadRequest("Token is required");

            //Verify the token for the member and continue login               
            if (Guid.TryParse(tokenDTO.memberId, out var newGuid))
            {
                var verifyTokenResult = await _userService.VerifyToken(newGuid, false, tokenDTO.token);
                return Ok(verifyTokenResult);
            }
            return null;
        }

        private bool validateDateFormat(DateTime date)
        {
            return Regex.IsMatch(date.ToString(), @"(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$");
        }


        [HttpPost("SaveMember")]
       
        public async Task<IActionResult> SaveMemberAsync([FromBody] MemberDto MemberDto)
        {
            string validationMessage = "Member is not stored"; string status = "Error";
            if (MemberDto == null)
                return Ok(new { status = status, message = "Invalid member data" });

            if(string.IsNullOrEmpty(MemberDto.FirstName.Trim()))
                return Ok(new { status = status, message = "Member's First Name is required" });

            if (string.IsNullOrEmpty(MemberDto.LastName.Trim() ))
                return Ok(new { status = status, message = "Member's Last Name is required" });

      
           if (MemberDto.DOB !=new DateTime() && MemberDto.DOB.Year < 1970)
                return Ok(new { status = status, message = "Member DOB's Year must be 1970 or later" });
            


                var result = await _userService.SaveMemberAsync(MemberDto);
            if (result != null)
                return Ok(new { status = result.Status, message = result.Message , MemberID = result.MemberID});

            return Ok(new { status = status, message = validationMessage });
        }

        [HttpPost("DeleteMember")]
        public async Task<IActionResult> DeleteMemberAsync(string MemberId)
        {
            string validationMessage = "Member is not stored"; string status = "Error";
            if (Guid.TryParse(MemberId, out var newGuid))
            {               
                var result = await _userService.DeleteMemberAsync(newGuid);
                if (result != null)
                    return Ok(new { status = result.Status, message = result.Message });
               
            }
            return Ok(new { status = status, message = validationMessage });
        }


        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto registerDto)
        {
            string validationMessage = "Member registration failed"; string status = "Error";
            if (registerDto == null)
               return  Ok(new { status = status, message = "Invalid registration data" });  

            if (await _userService.MemberEmailExistsAsync(registerDto.Email))
                return Ok(new { status = status, message = "Memeber Email exists" });  


            var result = await _userService.RegisterMemberAsync(registerDto);
            if (result != null)
                return Ok(new { status = result.Status, message = result.Message });


            return Ok(new { status = status, message = validationMessage });
        }

        [HttpPost("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword(string email)
        {          
            var strMessage = await _userService.ForgotPasswordAsync(email);          
            return Ok(new { message = strMessage });

        }

        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
        {
            string validationMessage = "Member Password functionality is failed"; string status = "Error";
            var result = await _userService.ChangePasswordAsync(changePasswordDto);
            if (result != null)
                return Ok(new { status = result.status, message = result.message });

            return Ok(new { status = status, message = validationMessage });
        }


        [HttpPost("LockUserAsync")]
        public async Task<IActionResult> LockUserAsync(Guid userId)
        {
            string strMessage= string.Empty;
            var isValid = await _userService.LockUserAsync(userId);
            strMessage = isValid ? "User locked successfully" : "Failed to lock user";
            return Ok(new { message = strMessage });

        }

        [HttpPost("UnlockUserAsync")]
        public async Task<IActionResult> UnlockUserAsync(Guid userId)
        {
            string strMessage = string.Empty;
            var isValid = await _userService.UnlockUserAsync(userId);
            strMessage = isValid ? "User Unlocked successfully" : "Failed to Unlock user";
            return Ok(new { message = strMessage });

        }

        [HttpGet("GetRelationshipType")]
        public async Task<IActionResult> GetRelationshipType()
        {
            var result = await _userService.GetRelationshipType();
            if (result == null)
                return BadRequest("No Relationship records");
            return Ok(result);

        }


        [HttpGet("GetDistinctState")]
        public async Task<IActionResult> GetDistinctState()
        {
            var result = await _userService.GetDistinctState();
            if (result == null)
                return BadRequest("No State records");
            
            return Ok(result);

        }

        [HttpGet("GetDistinctZipbyState")]
        public async Task<IActionResult> GetDistinctZipbyState(string State)
        {
            var result = await _userService.GetDistinctZipbyState(State);
            if (result == null)
                return BadRequest("No Zip records");
            return Ok(result.Select(x => x.ZIPCode).Distinct().ToArray());

        }

        [HttpGet("GetZipDatabyCode")]
        public async Task<IActionResult> GetZipDatabyCode(string zipcode)
        {
            var result = await _userService.GetZipDatabyCode(zipcode);
            if (result == null)
                return BadRequest("No Zip records");
            return Ok(result);
        }

        [HttpGet("GetMemberByIdAsync")]
        public async Task<IActionResult> GetMemberById(Guid memberId)
        {
            var result = await _userService.GetMemberById(memberId);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("GetMemberByUserEmailAsync")]
    

        public async Task<ActionResult<MemberDto>> GetMemberByUserEmailAsync(Guid userId,string email)
        {
            var result = await _userService.GetMemberByUserEmailAsync(userId, email);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var memberID = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var result = await _userService.GetMemberById(newGuid);
                if (result == null)
                    return BadRequest("No Members found");
                return Ok(new { result.FirstName, result.EmailID, imageUrl = string.IsNullOrEmpty(result.MemberPhotoURL) ? "https://i.pravatar.cc/150?u=oliviagreen" : string.Format("{0}://{1}{2}photo/{3}", Request.Scheme, Request.Host, Request.Path.ToString().Replace("profile", ""), result.MemberPhotoURL) });
            }
            return BadRequest("Invalid user ID on JWT Token");
        }

        

        [HttpGet("GetFamilyDepedent")]
        [Authorize]
        public async Task<IActionResult> GetFamilyDepedent()
        {
            var memberID = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var result = await _userService.GetFamilyDepedent(newGuid);
                if (result == null)
                    return BadRequest("No Members found");
                return Ok(result);
            }
            return BadRequest("Invalid user ID on JWT Token");

        }

        [HttpGet("GetFamilyDepedentFormattedData")]
        [Authorize]
        public async Task<IActionResult> GetFamilyDepedentFormattedData()
        {
            var memberID = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                
                var result = await _userService.GetFamilyDepedentFormattedData(newGuid);

                var final= result.Select(b => new
                {
                    id = b.MemberID,
                    name = string.Format("{0},{1}", b.FirstName, b.LastName),
                    relation = b.RelationshipType,
                    imageUrl = (string.IsNullOrEmpty(b.MemberPhotoURL)? "https://i.pravatar.cc/150?u=oliviagreen" : string.Format("{0}://{1}{2}photo/{3}", Request.Scheme, Request.Host,Request.Path.ToString().Replace("GetFamilyDepedentFormattedData", ""),b.MemberPhotoURL))
                }).ToList();

                if (result == null)
                    return BadRequest("No Members found");               
                return Ok(final);
            }
            return BadRequest("Invalid user ID on JWT Token");

        }

        [HttpPost("TestUploadfile")]
        public async Task<IActionResult> TestUploadfile(IFormFile file)
        {
            return null;
        }

            [HttpPost("uploadfile")]
        public async Task<IActionResult> Uploadfile([FromForm] FileUploadDto model)
        {
            string storagepath= (model.IsProfileFileType) ? _profilestoragePath : _documentstoragePath;
            if (model.File == null || model.File.Length == 0)
                return BadRequest("No file uploaded.");
            try
            {
                if (!Directory.Exists(storagepath))
                    Directory.CreateDirectory(storagepath); // Ensure it exists

                var uniqueFileName = model.memberID + Path.GetExtension(model.File.FileName);
                var filePath = Path.Combine(storagepath, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.File.CopyToAsync(stream);
                }

                return Ok(new { message = "file uploaded successfully", Status = "Success", filename= uniqueFileName });

            }
            catch (Exception)
            {

                return Ok(new { message = "file is not uploaded", Status = "Error" });
            }

            return Ok(new { message = "file is not uploaded", Status = "Error" });

        }

        [HttpGet("photo/{fileName}")]
        public IActionResult GetProfilePhoto(string fileName)
        {
            var filePath = Path.Combine(_profilestoragePath, fileName);
            if (!System.IO.File.Exists(filePath))
                return NotFound("File not found.");

            var contentType = "image/jpeg"; // Change based on file extension if needed
            return PhysicalFile(filePath, contentType);
        }


        [HttpGet("ValidateJWTToken")]
        public async Task<ActionResult<string>> ValidateJWTToken(string jWTtoken)
        {
            string strresult= string.Empty;
            if (string.IsNullOrEmpty(jWTtoken))
                return BadRequest("Invalid Token data");
            var result = await _userService.ValidateTokenAsync(jWTtoken);           
            strresult = (result) ? "JWT Token is valid" : "JWT Token is invalid";

            if (!result)
                return BadRequest("JWT Token is invalid");
            return Ok(strresult);
        }

        [HttpGet("RefreshTokenAsync")]
        public async Task<ActionResult<AuthResponseDto>> RefreshTokenAsync(string refreshToken)
        {
            if (!string.IsNullOrEmpty(refreshToken))
                return BadRequest("Invalid Token data");
            var result = await _userService.RefreshTokenAsync(refreshToken);
            if (result == null)
                return BadRequest("refreshToken is not completed successfully");
            return Ok(result);
        }

    }
}
