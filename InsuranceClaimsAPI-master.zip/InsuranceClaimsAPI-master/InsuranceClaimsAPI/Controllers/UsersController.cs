﻿using AutoMapper.Execution;
using InsuranceClaimsAPI.DTO;
using InsuranceClaimsAPI.Models;
using InsuranceClaimsAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using System.Security.Claims;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace InsuranceClaimsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController] 
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto login)
        {
                if (string.IsNullOrEmpty(login.Email) || string.IsNullOrEmpty(login.Password))
                return Ok( new AuthResponseDto{ status = "Error", message = "Invalid login data" });
           
            var result = await _userService.LoginAsync(login.Email, login.Password);       
            return Ok(result);
        }

        [HttpPost("Verify-Email")]
        public async Task<IActionResult> VerifyEmail([FromBody] TokenDto tokenDTO)
        {
            string validationMessage  = string.Empty;string status = "Error";
            if (tokenDTO == null)
                return BadRequest("Invalid Token data");
            else if (string.IsNullOrEmpty(tokenDTO.memberId))
                return BadRequest(" MemberId is required");
            else if (string.IsNullOrEmpty(tokenDTO.token))
                return BadRequest("Token is required");

            var memberID = tokenDTO.memberId;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var memberdetails = await _userService.GetMemberById(newGuid);

                if (memberdetails != null)
                {
                    if (memberdetails.IsActive == false)
                    {
                        validationMessage = "Member is not active";
                    }
                    else if (memberdetails.EmailConfirmed == true || memberdetails.MobileNoConfirmed == true)
                        validationMessage = "Already Email Token is registered";

                    if (memberdetails.EmailConfirmationToken != tokenDTO.token)
                        validationMessage = "Web Token is not matching";

                    if (memberdetails.EmailConfirmationTokenExpiry < DateTime.Now)
                    {
                        validationMessage = "Web Token is expired";
                    }
                }
                else
                    validationMessage = "Member is not found";
                if (!string.IsNullOrEmpty(validationMessage))
                    return Ok(new { status = status, message = validationMessage });
                else
                {
                    bool result= await _userService.VerifyToken(newGuid, true, tokenDTO.token);
                    if (result)
                    {
                        validationMessage = (result) ? "Email verified successfully." : "Email is not verified successfully.";
                        status = (result) ? "Success":"Error";
                    }                   
                }
            }
            return Ok(new { status= status,message = validationMessage });

        }

        [HttpPost("Verify-Mobile")]
        public async Task<IActionResult> VerifyMobile([FromBody] TokenDto tokenDTO)
        {
            string validationMessage = string.Empty; string status = "Error";
            if (tokenDTO == null)
                return BadRequest("Invalid Token data");
            else if (string.IsNullOrEmpty(tokenDTO.memberId))
                return BadRequest(" MemberId is required");
            else if (string.IsNullOrEmpty(tokenDTO.token))
                return BadRequest("Token is required");

            var memberID = tokenDTO.memberId;
        
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var memberdetails = await _userService.GetMemberById(newGuid);

                if (memberdetails != null)
                {
                    if (memberdetails.IsActive == false)
                    {
                        validationMessage = "Member is not active";
                    }
                    else if (memberdetails.EmailConfirmed == true || memberdetails.MobileNoConfirmed == true)
                        validationMessage = "Already OTP Token is registered";

                    if (memberdetails.MobileConfirmationToken != tokenDTO.token)
                        validationMessage = "Mobile OTP Token is not matching";

                    if (memberdetails.MobileConfirmationTokenExpiry < DateTime.Now)
                    {
                        validationMessage = "Mobile OTP Token is expired";
                    }
                }
                else
                    validationMessage = "Member is not found";
                if (!string.IsNullOrEmpty(validationMessage))
                    return Ok(new { status = status, message = validationMessage });
                else
                {
                    bool result = await _userService.VerifyToken(newGuid, false, tokenDTO.token);
                    if (result)
                    {
                        validationMessage = (result) ? "Mobile number is verified successfully." : "Mobile number is not verified successfully.";
                        status = (result) ? "Success" : "Error";
                    }

                }
            }
            return Ok(new { status = status, message = validationMessage });
        }      
          


       [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto registerDto)
        {
            string validationMessage = "Member registration failed"; string status = "Error";
            if (registerDto == null)
               return  Ok(new { status = status, message = "Invalid registration data" });  

            if (await _userService.MemberEmailExistsAsync(registerDto.Email))
                return Ok(new { status = status, message = "Memeber Email exists" });  

            var result = await _userService.RegisterMemberAsync(registerDto);
            if (result != null)
                return Ok(new { status = result.Status, message = result.Message });


            return Ok(new { status = status, message = validationMessage });
        }

        [HttpPost("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword(string email)
        {          
            var strMessage = await _userService.ForgotPasswordAsync(email);          
            return Ok(new { message = strMessage });

        }

        [HttpPost("ChangePassword")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
        {
            var strMessage = await _userService.ChangePasswordAsync(changePasswordDto);
            return Ok(new { message = strMessage });

        }


        [HttpPost("LockUserAsync")]
        public async Task<IActionResult> LockUserAsync(Guid userId)
        {
            string strMessage= string.Empty;
            var isValid = await _userService.LockUserAsync(userId);
            strMessage = isValid ? "User locked successfully" : "Failed to lock user";
            return Ok(new { message = strMessage });

        }

        [HttpPost("UnlockUserAsync")]
        public async Task<IActionResult> UnlockUserAsync(Guid userId)
        {
            string strMessage = string.Empty;
            var isValid = await _userService.UnlockUserAsync(userId);
            strMessage = isValid ? "User Unlocked successfully" : "Failed to Unlock user";
            return Ok(new { message = strMessage });

        }


        [HttpGet("GetMemberByIdAsync")]
        public async Task<ActionResult<MemberDto>> GetMemberById(Guid memberId)
        {
            var result = await _userService.GetMemberById(memberId);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("GetMemberByUserEmailAsync")]
    

        public async Task<ActionResult<MemberDto>> GetMemberByUserEmailAsync(Guid userId,string email)
        {
            var result = await _userService.GetMemberByUserEmailAsync(userId, email);
            if (result == null)
                return BadRequest("No Members found");
            return Ok(result);

        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var memberID = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (Guid.TryParse(memberID, out var newGuid))
            {
                var result = await _userService.GetMemberById(newGuid);
                if (result == null)
                    return BadRequest("No Members found");
                return Ok(new { result.FirstName, result.EmailID });
            }
            return BadRequest("Invalid user ID on JWT Token");
        }


        [HttpGet("ValidateJWTToken")]
        public async Task<ActionResult<string>> ValidateJWTToken(string jWTtoken)
        {
            string strresult= string.Empty;
            if (string.IsNullOrEmpty(jWTtoken))
                return BadRequest("Invalid Token data");
            var result = await _userService.ValidateTokenAsync(jWTtoken);           
            strresult = (result) ? "JWT Token is valid" : "JWT Token is invalid";

            if (!result)
                return BadRequest("JWT Token is invalid");
            return Ok(strresult);
        }

        [HttpGet("RefreshTokenAsync")]
        public async Task<ActionResult<AuthResponseDto>> RefreshTokenAsync(string refreshToken)
        {
            if (!string.IsNullOrEmpty(refreshToken))
                return BadRequest("Invalid Token data");
            var result = await _userService.RefreshTokenAsync(refreshToken);
            if (result == null)
                return BadRequest("refreshToken is not completed successfully");
            return Ok(result);
        }

    }
}
