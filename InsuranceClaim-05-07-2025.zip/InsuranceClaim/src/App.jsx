import AdminLayout from './components/layouts/AdminLayout';

const App = () => {
  return <AdminLayout />;
};

export default App;
