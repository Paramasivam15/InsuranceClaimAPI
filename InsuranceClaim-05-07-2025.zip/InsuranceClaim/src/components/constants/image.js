import Close from '../assets/images/icons/close.svg';
import Menu from '../assets/images/icons/menu.svg';
import DropdownArrow from '../assets/images/icons/dropdownArrow.svg';
import User from '../assets/images/icons/user.svg';
import Bell from '../assets/images/icons/bell.svg';
import LeftArrow from '../assets/images/icons/leftArrow.svg';
import RightArrow from '../assets/images/icons/rightArrow.svg';
import Widget from '../assets/images/icons/widget.svg';
import Search from '../assets/images/icons/search.svg';

export const AllImages = {
  close: Close,
  menu: Menu,
  dropdownArrow: DropdownArrow,
  user: User,
  bell: Bell,
  leftArrow: LeftArrow,
  rightArrow: RightArrow,
  widget: Widget,
  search: Search,
};

export default AllImages;