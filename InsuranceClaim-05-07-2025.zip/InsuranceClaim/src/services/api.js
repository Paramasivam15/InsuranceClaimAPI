const API_URL = "https://localhost:7233/api";
//const API_URL = process.env.REACT_APP_API_URL;

export async function login(data) {
  const res = await fetch(`${API_URL}/Users/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
}

export async function register(data) {
  const res = await fetch(`${API_URL}/Users/Register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
}

export async function getProfile(token) {
  const res = await fetch(`${API_URL}/Users/profile`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return await res.json();
}