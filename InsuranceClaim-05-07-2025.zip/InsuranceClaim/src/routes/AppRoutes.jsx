import { createBrowserRouter } from 'react-router-dom';
import App from '../App';
import MyInsurance from '../pages/MyInsurance';
import BillReview from '../pages/BillReview';
import Dashboard from '../pages/Dashboard';
import TimeLine from '../pages/Time-line';
import Vault from '../pages/Vault';
import NewStatements from '../pages/New-Statements';

import Login from '../pages/Login';
import Register from '../pages/Register';



const router = createBrowserRouter([
  {
    path: '/',
    element: <Login />,
  },
  {
        path: '/login',
        element: <Login />,
  },
  {
        path: '/register',
        element: <Register />,
  },
  {
    path: '/admin',
    element: <App />,
    children: [
      {
        path: 'home',
        element: <Dashboard />,
      },
      {
        path: 'MyInsurance',
        element: <MyInsurance />,
      },
      {
        path: 'BillReview',
        element: <BillReview />,
      },
      {
        path: 'Time-line',
        element: <TimeLine />,
      },
      {
        path: 'Vault',
        element: <Vault />,
      },
      {
        path: 'New-Statements',
        element: <NewStatements />,
      },
    ],
  },
]);

export default router;
