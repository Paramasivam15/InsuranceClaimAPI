const TimeLine = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Time line</h1>
      <p>Welcome to the Time line Module.</p>
    </div>
  );
};

export default TimeLine;
