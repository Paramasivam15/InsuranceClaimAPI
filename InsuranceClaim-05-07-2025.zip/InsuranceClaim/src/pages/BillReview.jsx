const UserManagement = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Bill Review</h1>
    
    </div>
  );
};
export default UserManagement;
