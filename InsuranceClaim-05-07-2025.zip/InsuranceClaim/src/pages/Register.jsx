import { useState } from "react";
import { register } from "../services/api";
import { useNavigate } from "react-router-dom";


export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setfirstName] = useState("");
   const [lastName, setlastName] = useState("");
  const [dob, setdob] = useState({ startDate: null, endDate: null });
  const [mobileno, setmobileno] = useState("");
  const [gender, setgender] = useState("M"); 
  const [successMessage, setSuccessMessage] = useState('');
  const [name, setName] = useState("");
  const navigate = useNavigate();

 const handleSubmit = async (e) => {
        e.preventDefault();
        console.log("Registering user:", { email, firstName, lastName, dob, mobileno,gender});
        // Call the register function from the API service
       const res = await register({ email, firstName, lastName, dob, mobileno, gender });
        if (res.message === "Member registered successfully. Please check your email for confirmation link or OTP for mobile verification.") {
            alert("Member Registration successful");  
             setSuccessMessage(message);  
        } else {
            alert("Member Registration failed");
            setSuccessMessage('');
        }           
     
    };

  return (

      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">         
          <h2 className="mt-10 text-center text-2xl/9 font-bold tracking-tight text-gray-900">
            Register in to Active Patient account
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form className="space-y-6" onSubmit={handleSubmit}>
             <div>
              <label htmlFor="firstName" className="block text-sm/6 font-medium text-gray-900">
                First Name
              </label>
              <div className="mt-2">
                <input
                  id="firstName"
                  name="firstName"
                  type="text"                 
                  required
                   onChange={(e) => setfirstName(e.target.value)}                 
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>
            <div>
              <label htmlFor="lastName" className="block text-sm/6 font-medium text-gray-900">
                Last Name
              </label>
              <div className="mt-2">
                <input
                  id="lastName"
                  name="lastName"
                  type="text"                 
                  required
                   onChange={(e) => setlastName(e.target.value)}                 
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm/6 font-medium text-gray-900">
                Email address
              </label>
              <div className="mt-2">
                <input
                  id="email"
                  name="email"
                  type="email"                 
                  required
                   onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="dob" className="block text-sm/6 font-medium text-gray-900">
                  Date of Birth
                </label>                
              </div>
              <div className="mt-2">
                <input
                  id="dob"
                  name="dob"
                  type="date"
                  required
                  onChange={(e) => setdob(e.target.value)}                   
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />              
              </div>
            </div>

              <div>
              <label htmlFor="genter" className="block text-sm/6 font-medium text-gray-900">
               Genter
              </label>
              <div className="mt-2">                
                 <select className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                  id="genter" 
                  name="genter"
                  required
                  value={gender} 
                  onChange={e => setgender(e.target.value)} 
                >
                <option value="M">Male</option>
                <option value="F">Female</option>
                <option value="O">Others</option>
                 </select>
              </div>
            </div>

               <div>
              <label htmlFor="mobileno" className="block text-sm/6 font-medium text-gray-900">
                Mobile Number
              </label>
              <div className="mt-2">
                <input
                  id="mobileno"
                  name="mobileno"
                  type="text"                 
                  required
                   onChange={(e) => setmobileno(e.target.value)}                 
                  className="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                />
              </div>
            </div>
            

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Register
              </button>
            </div>
          </form>

          <p className="mt-10 text-center text-sm/6 text-gray-500">
            Not a member?{' '}
           
              <a href="/login" className="font-semibold text-indigo-600 hover:text-indigo-500">Sign In </a>                   
          </p>

          {successMessage && <div className="flex w-full justify-center rounded-md bg-green-600 px-3 py-1.5 text-sm/6 font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">{successMessage}</div>}
        </div>
      </div>
  );
}