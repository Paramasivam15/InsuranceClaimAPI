import { useEffect, useState } from "react";
import { getProfile } from "../services/api";

export default function Dashboard() {
  const [profile, setProfile] = useState({});

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;
    getProfile(token).then(setProfile);
  }, []);

  return (
   
            <div className="container mx-auto mt-12">
                <div className="grid grid-cols-1 gap-6 mb-6 lg:grid-cols-3">
                    <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                        <div className="text-sm font-medium text-gray-500 truncate">
                            Member
                        </div>
                        <div className="mt-1 text-3xl font-semibold text-gray-900">
                           Welcome, {profile.firstName}
                        </div>
                    </div>
                    <div className="w-full px-4 py-5 bg-white rounded-lg shadow">
                        <div className="text-sm font-medium text-gray-500 truncate">
                            Email
                        </div>
                        <div className="mt-1 text-3xl font-semibold text-gray-900">
                           Email: {profile.emailID}
                        </div>
                    </div>
                  
                </div>
            </div>      
  );
}