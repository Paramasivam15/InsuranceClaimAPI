const Vault = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Vault</h1>
      <p>Welcome to the Vault Module..</p>
    </div>
  );
};

export default Vault;
