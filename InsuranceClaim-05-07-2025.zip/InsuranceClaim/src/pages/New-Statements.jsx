const NewStatements = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">New-Statements</h1>
      <p>Welcome to the admin New-Statements.</p>
    </div>
  );
};

export default NewStatements;
