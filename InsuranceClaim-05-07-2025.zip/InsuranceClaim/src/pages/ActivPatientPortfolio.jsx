import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Upload, 
  Shield, 
  TrendingUp, 
  Calendar,
  FileText,
  DollarSign,
  Users,
  X,
  Eye,
  EyeOff,
  CheckCircle,
  ArrowRight,
  Play,
  Star,
  Award,
  Clock,
  Smartphone,
  Brain,
  Zap,
  ChevronLeft,
  ChevronRight,
  Facebook, 
  Instagram,
  Twitter

} from 'lucide-react';

function ActivPatientPortfolio() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: ''
  });

   const socialLinks = [
    { icon:Facebook, href: "#", label: "Facebook" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Play, href: "#", label: "Vimeo" },
  ];

  // Auto-scroll for testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStoryIndex(prev => (prev + 1) % 4);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleInputChange = (e) => {
console.log(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setShowAuthModal(false);
    alert(isLogin ? 'Welcome back to ActivPatient!' : 'Welcome to ActivPatient! Your account has been created.');
  };

  const openAuthModal = (loginMode = true) => {
    setIsLogin(loginMode);
    setShowAuthModal(true);
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      firstName: '',
      lastName: ''
    });
  };

  const stories = [
    {
      name: "Sarah Chen",
      role: "Working Mother",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      story: "ActivPatient helped me save $3,200 on my family's medical bills last year. The AI caught billing errors I never would have noticed.",
      savings: "$3,200",
      rating: 5
    },
    {
      name: "Marcus Johnson",
      role: "Insurance Analyst",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      story: "As someone who works in insurance, I'm impressed by ActivPatient's accuracy. It caught a $1,800 duplicate charge that even I missed.",
      savings: "$1,800",
      rating: 5
    },
    {
      name: "Dr. Emily Rodriguez",
      role: "Pediatrician & Mom",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      story: "Even as a doctor, medical billing is complex. ActivPatient gives me peace of mind and has saved my family over $2,500.",
      savings: "$2,500",
      rating: 5
    },
    {
      name: "James Thompson",
      role: "Small Business Owner",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      story: "Managing healthcare costs for my employees was overwhelming. ActivPatient streamlined everything and reduced our expenses by 15%.",
      savings: "$12,000",
      rating: 5
    }
  ];

  const AuthModal = () => (
    showAuthModal && (
      <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 relative transform transition-all">
          <button
            onClick={() => setShowAuthModal(false)}
            className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {isLogin ? 'Welcome Back' : 'Join ActivPatient'}
            </h2>
            <p className="text-gray-600">
              {isLogin ? 'Continue your healthcare journey' : 'Start saving on healthcare today'}
            </p>
          </div>

          <div className="flex mb-8 bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 text-center rounded-lg transition-all font-medium ${
                isLogin ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 text-center rounded-lg transition-all font-medium ${
                !isLogin ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
              }`}
            >
              Create Account
            </button>
          </div>

          <div className="space-y-5">
            {!isLogin && (
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  name="firstName"
                  placeholder="First Name"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  className="px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
                <input
                  type="text"
                  name="lastName"
                  placeholder="Last Name"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  className="px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
              </div>
            )}
            
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleInputChange}
              className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            />
            
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all pr-12"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            {!isLogin && (
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm Password"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                className="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            )}

            <button
              onClick={handleSubmit}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              {isLogin ? 'Sign In to ActivPatient' : 'Create My Account'}
            </button>
          </div>

          {isLogin && (
            <div className="text-center mt-6">
              <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                Forgot your password?
              </button>
            </div>
          )}
        </div>
      </div>
    )
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Modern Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 text-white min-h-screen flex items-center overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
          <div className="absolute top-40 right-20 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
          <div className="absolute bottom-20 left-1/2 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-2000"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center mr-4">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-4xl font-bold">ActivPatient</h1>
              </div>
              
              <h2 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent leading-tight">
                Take Control of Your Healthcare
              </h2>
              
              <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
                AI-powered healthcare management that saves families an average of <span className="text-yellow-400 font-bold">$2,400 annually</span> on medical expenses
              </p>
              
              <div className="flex items-center mb-8">
                <div className="flex -space-x-3 mr-4">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-12 h-12 rounded-full border-4 border-white bg-gradient-to-r from-blue-400 to-purple-400"></div>
                  ))}
                </div>
                <div className="text-sm">
                  <div className="flex items-center mb-1">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                    <span className="ml-2 font-semibold">4.9/5</span>
                  </div>
                  <p className="text-gray-300">Trusted by 50,000+ families</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => openAuthModal(false)}
                  className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-semibold text-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center"
                >
                  New Account
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
                <button 
                  onClick={() => openAuthModal(true)}
                  className="px-8 py-4 border-2 border-white/30 backdrop-blur-sm rounded-xl font-semibold text-lg hover:bg-white/10 transition-all flex items-center justify-center"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Sign In
                </button>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20">
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-white/10 rounded-2xl">
                    <div className="flex items-center">
                      <CheckCircle className="w-6 h-6 text-green-400 mr-3" />
                      <span>Medical Bill Analyzed</span>
                    </div>
                    <span className="text-green-400 font-bold">-$847</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/10 rounded-2xl">
                    <div className="flex items-center">
                      <Shield className="w-6 h-6 text-blue-400 mr-3" />
                      <span>Insurance Claim Filed</span>
                    </div>
                    <span className="text-blue-400 font-bold">$2,150</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/10 rounded-2xl">
                    <div className="flex items-center">
                      <TrendingUp className="w-6 h-6 text-purple-400 mr-3" />
                      <span>Annual Savings</span>
                    </div>
                    <span className="text-purple-400 font-bold">$3,247</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Modern How It Works */}
      <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              How It <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Works</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform simplifies healthcare management with intelligent automation
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Smartphone,
                title: "Smart Upload",
                description: "Snap photos or upload digital bills. Our AI instantly extracts and categorizes all data.",
                color: "from-blue-500 to-cyan-500"
              },
              {
                icon: Brain,
                title: "AI Analysis",
                description: "Advanced algorithms detect billing errors, duplicate charges, and optimization opportunities.",
                color: "from-purple-500 to-pink-500"
              },
              {
                icon: Shield,
                title: "Automated Claims",
                description: "We handle insurance claims, appeals, and follow-ups automatically on your behalf.",
                color: "from-green-500 to-teal-500"
              },
              {
                icon: Zap,
                title: "Instant Savings",
                description: "Get real-time notifications about savings, refunds, and personalized health insights.",
                color: "from-yellow-500 to-orange-500"
              }
            ].map((step, index) => (
              <div key={index} className="relative group">
                <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
                  <div className={`w-16 h-16 bg-gradient-to-r ${step.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="w-8 h-8 text-gray-300" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Statistics */}
      <section className="py-24 bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Healthcare by the Numbers</h2>
            <p className="text-xl text-blue-100">The healthcare industry's hidden costs revealed</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="text-8xl md:text-9xl font-bold mb-4 bg-gradient-to-b from-white to-blue-200 bg-clip-text text-transparent">
                50%
              </div>
              <p className="text-2xl font-semibold mb-2">Medical Billing Error Rate</p>
              <p className="text-blue-200">1 in 2 medical bills contain errors costing families thousands</p>
            </div>
            
            <div className="text-center">
              <div className="text-8xl md:text-9xl font-bold mb-4 bg-gradient-to-b from-white to-purple-200 bg-clip-text text-transparent">
                $2.4K
              </div>
              <p className="text-2xl font-semibold mb-2">Average Annual Savings</p>
              <p className="text-purple-200">ActivPatient users save thousands on healthcare costs yearly</p>
            </div>
            
            <div className="text-center">
              <div className="text-8xl md:text-9xl font-bold mb-4 bg-gradient-to-b from-white to-cyan-200 bg-clip-text text-transparent">
                24/7
              </div>
              <p className="text-2xl font-semibold mb-2">AI Monitoring</p>
              <p className="text-cyan-200">Continuous protection and optimization of your healthcare finances</p>
            </div>
          </div>
          
          <div className="text-center mt-16">
            <button 
              onClick={() => openAuthModal(false)}
              className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Start Saving Today
            </button>
          </div>
        </div>
      </section>

      {/* Modern Insights */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Smart <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Insights</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get actionable insights that transform how you manage your family's health
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              {[
                {
                  icon: FileText,
                  title: "Comprehensive Health Records",
                  description: "AI-organized vaccination history, medical records, and treatment timelines for your entire family",
                  color: "blue"
                },
                {
                  icon: Calendar,
                  title: "Predictive Care Scheduling",
                  description: "Smart reminders for preventive care, screenings, and checkups based on medical guidelines and insurance coverage",
                  color: "green"
                },
                {
                  icon: TrendingUp,
                  title: "Health Analytics Dashboard",
                  description: "Visual insights into health trends, spending patterns, and opportunities for cost optimization",
                  color: "purple"
                },
                {
                  icon: DollarSign,
                  title: "Financial Health Tracking",
                  description: "Real-time monitoring of healthcare expenses, insurance utilization, and potential savings opportunities",
                  color: "yellow"
                }
              ].map((insight, index) => (
                <div key={index} className="flex items-start space-x-4 group">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    insight.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                    insight.color === 'green' ? 'bg-green-100 text-green-600' :
                    insight.color === 'purple' ? 'bg-purple-100 text-purple-600' :
                    'bg-yellow-100 text-yellow-600'
                  } group-hover:scale-110 transition-transform`}>
                    <insight.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{insight.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{insight.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 shadow-2xl">
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-gray-900">Monthly Health Summary</h4>
                      <Award className="w-6 h-6 text-yellow-500" />
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Bills Reviewed</span>
                        <span className="font-bold">12</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Errors Found</span>
                        <span className="font-bold text-red-600">6</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Money Saved</span>
                        <span className="font-bold text-green-600">$847</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-2xl p-6 shadow-lg">
                    <h4 className="font-bold text-gray-900 mb-4">Upcoming Care</h4>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 text-blue-600 mr-3" />
                        <span className="text-sm">Annual checkup due in 2 weeks</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 text-green-600 mr-3" />
                        <span className="text-sm">Flu shot recommended</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Horizontal Real Life Stories */}
      <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Real Life <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Success Stories</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See how ActivPatient is transforming healthcare for families nationwide
            </p>
          </div>
          
          <div className="relative">
            {/* Story Cards Container */}
            <div className="overflow-hidden rounded-3xl">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentStoryIndex * 100}%)` }}
              >
                {stories.map((story, index) => (
                  <div key={index} className="w-full flex-shrink-0">
                    <div className="bg-white rounded-3xl shadow-2xl mx-4 overflow-hidden">
                      <div className="grid grid-cols-1 lg:grid-cols-2">
                        {/* Image Side */}
                        <div className="relative h-96 lg:h-auto">
                          <img 
                            src={story.image}
                            alt={story.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                          <div className="absolute bottom-6 left-6 text-white">
                            <div className="flex items-center mb-2">
                              {[...Array(story.rating)].map((_, i) => (
                                <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                              ))}
                            </div>
                            <p className="text-2xl font-bold">{story.name}</p>
                            <p className="text-lg opacity-90">{story.role}</p>
                          </div>
                        </div>
                        
                        {/* Content Side */}
                        <div className="p-12 flex flex-col justify-center">
                          <div className="mb-8">
                            <div className="text-6xl font-bold text-green-600 mb-4">
                              {story.savings}
                            </div>
                            <p className="text-lg text-gray-600 mb-2">Annual Savings</p>
                          </div>
                          
                          <blockquote className="text-2xl text-gray-800 leading-relaxed mb-8 font-medium">
                            "{story.story}"
                          </blockquote>
                          
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mr-4">
                              <CheckCircle className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <p className="font-bold text-gray-900">Verified Savings</p>
                              <p className="text-gray-600">Confirmed by ActivPatient Analytics</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Navigation */}
            <div className="flex items-center justify-center mt-8 space-x-4">
              <button
                onClick={() => setCurrentStoryIndex(prev => prev === 0 ? stories.length - 1 : prev - 1)}
                className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
              >
                <ChevronLeft className="w-6 h-6 text-gray-600" />
              </button>
              
              <div className="flex space-x-2">
                {stories.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentStoryIndex(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentStoryIndex ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
              
              <button
                onClick={() => setCurrentStoryIndex(prev => (prev + 1) % stories.length)}
                className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
              >
                <ChevronRight className="w-6 h-6 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Modern CTA Section */}
      <section className="py-24 bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-600 text-white relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-40 h-40 bg-white rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-60 h-60 bg-white rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-8">
            Ready to Transform Your Healthcare?
          </h2>
          <p className="text-2xl text-blue-100 mb-12 leading-relaxed">
            Join thousands of families who are saving money and taking control of their health with ActivPatient
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button 
              onClick={() => openAuthModal(false)}
              className="px-10 py-5 bg-white text-blue-600 rounded-2xl font-bold text-xl hover:bg-gray-100 transition-all shadow-2xl hover:shadow-3xl transform hover:-translate-y-1"
            >
              New Account
            </button>
            <button 
              onClick={() => openAuthModal(true)}
              className="px-10 py-5 border-2 border-white/30 backdrop-blur-sm rounded-2xl font-bold text-xl hover:bg-white/10 transition-all"
            >
              Sign In
            </button>
          </div>          
         
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">        
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>


          
          <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
            <p>&copy; Copyright 2016-17 ActivPatient - All Rights Reserved</p>         
          </div>
                    <div className="flex justify-center space-x-6">
          {socialLinks.map((social, index) => {
            const IconComponent = social.icon;
            return (
              <a
                key={index}
                href={social.href}
                aria-label={social.label}
                className="text-gray-600 hover:text-blue-600 transition-colors duration-200 p-2 rounded-full hover:bg-white hover:shadow-md"
              >
                <IconComponent size={24} />
              </a>
            );
          })}
        </div>
         
        </div>
      </footer>

      <AuthModal />
    </div>
  )
}

export default ActivPatientPortfolio