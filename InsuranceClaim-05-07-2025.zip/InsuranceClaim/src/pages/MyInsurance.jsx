const MyInsurance = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">MY Insurance</h1>
      <p>Manage MY Insurance here.</p>
    </div>
  );
};
export default MyInsurance;
